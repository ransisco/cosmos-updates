# -*- coding: utf-8 -*-
"""Datos de demostracion para verificacion visual sin cuentas reales (CORREO_DEMO=1)."""
import time

NEWSLETTER_HTML = """
<html><body style="font-family:Segoe UI,Arial">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0b5cad"><tr><td>
<h1 style="color:#ffffff">Unicaja Baloncesto</h1>
<p style="color:#dceefc">Tu resumen semanal de Liga Endesa y Euroliga</p>
</td></tr></table>
<img src="https://img.unicaja.example/banner-semana.jpg?utmid=9911" width="600" height="240" alt="banner">
<h2>Jornada 9: previa del partido en Carpena</h2>
<p>Hola Juan, esta semana el equipo recibe al <b>Baskonia</b> en el Mart&iacute;n Carpena.
Puedes ver <a href="https://entradas.example/unicaja?utm_source=news&utm_medium=email&fbclid=IwAR3xyz&id=55">las entradas disponibles aqu&iacute;</a>
o consultar <a href="https://unicaja.example/calendario">el calendario completo</a>.</p>
<img src="https://track.unicaja.example/o.gif?id=55&u=juan" width="1" height="1">
<ul><li>Viernes 20:30 - Carpena</li><li>Domingo 12:30 - Euroliga en casa</li></ul>
<p style="color:#767676;font-size:12px">Recibes este correo por tu suscripci&oacute;n.
<a href="https://unicaja.example/baja?e=fm_92_lu%40hotmail.com&utm_campaign=baja">Darse de baja</a></p>
<img src="https://img.unicaja.example/pie.jpg" width="600" height="80" alt="pie">
</body></html>
"""

AMAZON_HTML = """
<html><body>
<h2>Pedido enviado</h2>
<p>Tu pedido <b>#402-9918273-1133907</b> va camino de Lucena (14900).</p>
<p>Llegada estimada: <b>ma&ntilde;ana antes de las 21:00</b>.</p>
<table><tr><td><img src="https://imgs.amazon.example/p/P41.jpg" width="120" height="120"></td>
<td><p><b>Protector de pantalla Retroid Pocket (2 unidades)</b></p>
<p>12,99 &euro; &middot; <a href="https://www.amazon.example/gp/css/order-details?orderID=402-9918273-1133907&gclid=CjwKCAjw&ref_=pe_1">Ver pedido</a></p></td></tr></table>
<img src="https://amazon.example/px/open.gif?m=At31" width="1" height="1">
</body></html>
"""

SIMPLE_TEXT = """Hola Juan,

¿Has podido mirar lo de las fotocopias para el B1 del martes? Si no, las hago yo por la mañana.

Por cierto, la reunión de departamento se mueve al jueves a las 15:30, aula 3.

Un saludo,
Encarni
"""

DEMO_MESSAGES = [
    dict(special="inbox", uid=101, ago=900, frm=("Unicaja Baloncesto", "newsletter@unicaja.example"),
         subject="Previa J9: Unicaja - Baskonia en Carpena", html=NEWSLETTER_HTML,
         preview="Hola Juan, esta semana el equipo recibe al Baskonia en el Martín Carpena...", read=False,
         attach=[]),
    dict(special="inbox", uid=102, ago=3600, frm=("Encarni Ruiz", "encarni.ruiz@example.com"),
         subject="Fotocopias B1 y reunión", text=SIMPLE_TEXT,
         preview="¿Has podido mirar lo de las fotocopias para el B1 del martes? Si no...", read=False, attach=[]),
    dict(special="inbox", uid=103, ago=7200, frm=("Amazon", "confirmacion@amazon.example"),
         subject="Tu pedido ha sido enviado", html=AMAZON_HTML,
         preview="Tu pedido #402-9918273-1133907 va camino de Lucena (14900)...", read=True,
         attach=[("albaran.pdf", "application/pdf", 48213)]),
    dict(special="inbox", uid=104, ago=19000, frm=("Miguel Ángel", "miguelangel.tor@example.com"),
         subject="Padre de Lucía - recuperación", text="Buenas Juan,\n\nLucía se pierde la clase del jueves por un médico. ¿Me pasas los deberes por aquí?\n\nGracias,\nMiguel Ángel",
         preview="Lucía se pierde la clase del jueves por un médico...", read=True, attach=[]),
    dict(special="inbox", uid=105, ago=84000, frm=("GOAL", "alerts@goal.example"),
         subject="Betis 2 - 1 Sevilla: crónica del derbi", text="El Betis se lleva el derbi con gol en el 92. Lee la crónica completa en la web.",
         preview="El Betis se lleva el derbi con gol en el 92...", read=True, flagged=True, attach=[]),
    dict(special="inbox", uid=106, ago=100000, frm=("Banco Unicaja", "avisos@banco.example"),
         subject="Aviso de seguridad: nuevo inicio de sesión", text="Hemos detectado un inicio de sesión desde un nuevo dispositivo. Si has sido tú, ignora este mensaje.",
         preview="Hemos detectado un inicio de sesión desde un nuevo dispositivo...", read=True, attach=[]),
    dict(special="inbox", uid=107, ago=150000, frm=("Retroid Store", "orders@retroid.example"),
         subject="Order #8812 confirmed - Pocket Nova", text="Thanks for your order! Your Retroid Pocket Nova will ship within 5 days. Tracking will follow by email.",
         preview="Thanks for your order! Your Retroid Pocket Nova will ship within 5 days...", read=True, attach=[]),
    dict(special="inbox", uid=108, ago=200000, frm=("Cambridge English", "noreply@cambridge.example"),
         subject="B1 Preliminary - new sample papers available", text="Dear teacher, new sample papers for B1 Preliminary for Schools are now available in the resources area.",
         preview="New sample papers for B1 Preliminary for Schools are now available...", read=True, attach=[]),
    dict(special="sent", uid=201, ago=5000, frm=("Juan", "fm_92_lu@hotmail.com"),
         subject="RE: Fotocopias B1 y reunión", text="Perfecto Encarni, las fotocopias las haces tú y yo llevo los listening. El jueves allí estoy.",
         preview="Perfecto Encarni, las fotocopias las haces tú...", read=True, attach=[]),
    dict(special="drafts", uid=301, ago=8000, frm=("Juan", "fm_92_lu@hotmail.com"),
         subject="(borrador) Horarios diciembre", text="B1 lunes y miércoles 18:00\nB2 martes y jueves 19:30\nC1...",
         preview="B1 lunes y miércoles 18:00, B2 martes y jueves 19:30...", read=True, attach=[]),
    dict(special="junk", uid=401, ago=40000, frm=("Crypto King", "win@crypto.example"),
         subject="DUPLICA tus BTC HOY", text="Invierte ya y gana 500% garantizado. Pulsa aquí: http://crypto.example/scam",
         preview="Invierte ya y gana 500% garantizado...", read=False, attach=[]),
]

def seed(db):
    if db.accounts():
        return False
    acc_id = db.add_account("outlook", "fm_92_lu@hotmail.com", "Juan")
    folder_ids = {}
    for special, name in [("inbox", "Bandeja de entrada"), ("drafts", "Borradores"),
                          ("sent", "Elementos enviados"), ("archive", "Archivados"),
                          ("junk", "Correo no deseado"), ("trash", "Papelera")]:
        db.run("INSERT INTO folders(account_id,name,remote,special) VALUES(?,?,?,?)",
               (acc_id, name, {"inbox": "INBOX", "drafts": "Drafts", "sent": "Sent",
                               "archive": "Archive", "junk": "Junk", "trash": "Deleted"}[special], special))
        folder_ids[special] = db.folder_by_special(acc_id, special)["id"]
    now = time.time()
    for m in DEMO_MESSAGES:
        flags = 1 if m.get("read") else 0
        if m.get("flagged"):
            flags |= 2
        name, addr = m["frm"]
        body_html = m.get("html")
        body_text = m.get("text") or ""
        cur = db.run("""INSERT INTO messages(account_id,folder_id,uid,msgid,ts,from_name,from_addr,to_addrs,
                        subject,preview,flags,has_attach,body_text,body_html,blocked)
                        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                     (acc_id, folder_ids[m["special"]], m["uid"], "<demo-%d@correo>" % m["uid"],
                      now - m["ago"], name, addr, "fm_92_lu@hotmail.com", m["subject"], m["preview"],
                      flags, 1 if m["attach"] else 0, body_text, body_html or "", 0))
        mid = cur.lastrowid
        for fn, mime, size in m["attach"]:
            db.run("INSERT INTO attachments(message_id,filename,mime,size,part_index) VALUES(?,?,?,?,1)",
                   (mid, fn, mime, size))
    for special in folder_ids:
        unseen = db.one("SELECT COUNT(*) c FROM messages WHERE folder_id=? AND (flags&1)=0",
                        (folder_ids[special],))["c"]
        db.run("UPDATE folders SET unseen=? WHERE id=?", (unseen, folder_ids[special]))
    return True
