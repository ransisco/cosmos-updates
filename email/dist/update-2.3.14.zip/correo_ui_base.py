# -*- coding: utf-8 -*-
"""Base visual: CSS estilo Correo de Windows, iconos dibujados con cairo, avatares."""
import math, zlib
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GdkPixbuf, Pango
import cairo

ACCENT = "#0078D4"
ACCENT_DARK = "#106EBE"
NAV_BG = "#F3F3F3"
NAV_HOVER = "#E5E5E5"
NAV_SEL = "#E1E1E1"
LIST_HOVER = "#E5F1FB"
LIST_SEL = "#CCE4F7"
BORDER = "#E1DFDD"
TEXT = "#1B1A19"
TEXT_DIM = "#605E5C"

CSS = ("""
window { background-color: #FFFFFF; }
.correo-title { font-size: 19px; font-weight: 600; }
.nav-pane { background-color: %(NAV_BG)s; border-right: 1px solid %(BORDER)s; }
.nav-section { font-size: 10px; font-weight: 600; color: #8A8886; padding: 6px 10px 2px 10px; }
.nav-flat { background: none; border: none; box-shadow: none; border-radius: 0; padding: 0; }
.nav-flat:hover { background-color: %(NAV_HOVER)s; }
.nav-row { background: none; border: none; box-shadow: none; border-radius: 0;
           padding: 4px 8px; border-left: 3px solid transparent; }
.nav-row:hover { background-color: %(NAV_HOVER)s; }
.nav-row:selected, .nav-row-selected { background-color: %(NAV_SEL)s; border-left: 3px solid %(ACCENT)s; }
.nav-label { font-size: 12.5px; color: %(TEXT)s; }
.nav-count { font-size: 11px; color: %(ACCENT)s; font-weight: 600; }
.nav-account { font-size: 12px; color: %(TEXT)s; }
.new-mail { background: %(ACCENT)s; background-image: none; color: #FFFFFF; border: none; border-radius: 3px;
            padding: 8px 12px; font-size: 13.5px; font-weight: 600; }
.new-mail:hover { background: %(ACCENT_DARK)s; background-image: none; }
.list-pane { background-color: #FFFFFF; border-right: 1px solid %(BORDER)s; }
.msg-row { border-bottom: 1px solid #F0EFEE; border-left: 4px solid transparent; padding: 4px 0; }
.msg-row:hover { background-color: %(LIST_HOVER)s; }
.msg-row:selected, .msg-row-selected { background-color: %(LIST_SEL)s; }
.msg-row-unread { border-left: 4px solid %(ACCENT)s; }
.msg-row-urgent { border-left: 4px solid #D83B01; }
.msg-sender { font-size: 14px; color: %(TEXT)s; }
.msg-sender-unread { font-size: 14px; font-weight: 700; color: %(TEXT)s; }
.msg-subject { font-size: 13px; color: %(TEXT)s; }
.msg-subject-unread { font-size: 13px; font-weight: 700; color: %(TEXT)s; }
.msg-preview { font-size: 12px; color: %(TEXT_DIM)s; }
.msg-time { font-size: 11.5px; color: %(TEXT_DIM)s; }
.msg-flagged { color: #D83B01; font-size: 13px; }
.search-entry { border: 1px solid %(BORDER)s; border-radius: 3px; padding: 6px 10px; font-size: 13px;
                background: #FFFFFF; }
.search-entry:focus { border-color: %(ACCENT)s; }
.reader-subject { font-size: 20px; font-weight: 600; color: %(TEXT)s; }
.reader-from { font-size: 14px; font-weight: 600; color: %(TEXT)s; }
.reader-addr { font-size: 12.5px; color: %(TEXT_DIM)s; }
.reader-date { font-size: 12.5px; color: %(TEXT_DIM)s; }
.action-btn { background: none; border: none; box-shadow: none; border-radius: 3px; padding: 3px; }
.action-btn:hover { background-color: #F0F0F0; }
.infobar { background-color: #FFF4CE; border: none; border-radius: 0; padding: 5px 10px; }
.infobar-text { font-size: 13px; color: #323130; }
.infobar-btn { background: #FFFFFF; border: 1px solid #C8C6C4; border-radius: 3px;
               box-shadow: none; color: #323130; font-size: 12px; padding: 1px 8px; }
.infobar-btn:hover { background: #F5F5F5; border-color: #8A8886; }
.att-chip { border: 1px solid %(BORDER)s; border-radius: 3px; background: #FAF9F8; padding: 4px 10px; }
.att-chip:hover { background: #F0EFEE; }
.att-name { font-size: 12.5px; color: %(TEXT)s; }
.att-size { font-size: 11px; color: %(TEXT_DIM)s; }
.status-bar { background-color: #FAF9F8; border-top: 1px solid %(BORDER)s; }
.status-label { font-size: 12px; color: %(TEXT_DIM)s; padding: 4px 12px; }
.avatar { border-radius: 999px; color: #FFFFFF; font-weight: 600; }
.compose-field { border: none; border-bottom: 1px solid %(BORDER)s; border-radius: 0;
                 padding: 8px 4px; font-size: 13.5px; background: #FFFFFF; box-shadow: none; }
.compose-field:focus { border-bottom: 2px solid %(ACCENT)s; box-shadow: none; }
.send-btn { background: %(ACCENT)s; background-image: none; color: #FFFFFF; border: none; border-radius: 3px;
            padding: 7px 22px; font-size: 13.5px; font-weight: 600; }
.send-btn:hover { background: %(ACCENT_DARK)s; background-image: none; }
.tool-btn { background: none; border: none; box-shadow: none; border-radius: 3px;
            padding: 6px 10px; font-size: 14px; }
.tool-btn:hover { background-color: #F0F0F0; }
.tool-btn:checked { background-color: #E5F1FB; color: %(ACCENT)s; font-weight: 600; }
.provider-btn { border: 1px solid %(BORDER)s; border-radius: 4px; background: #FFFFFF;
                padding: 12px 16px; font-size: 14px; }
.provider-btn:hover { background: #F5F5F5; border-color: #C8C6C4; }
.welcome-title { font-size: 26px; font-weight: 600; color: %(TEXT)s; }
.welcome-sub { font-size: 14px; color: %(TEXT_DIM)s; }
.body-view { font-size: 13.5px; }
.img-placeholder { border: 1px dashed #C8C6C4; border-radius: 3px; background: #FAF9F8; }
.img-placeholder-label { font-size: 12px; color: %(TEXT_DIM)s; }
.error-bar { background-color: #FDE7E9; padding: 8px 14px; }
.error-bar-text { font-size: 13px; color: #A4262C; }
.update-bar { background-color: #EFF6FC; padding: 8px 14px; }
.update-bar-text { font-size: 13px; color: #004578; }
/* look Outlook web */
.top-bar { background-color: #0078D4; background-image: none; border: none; padding: 0 4px; min-height: 0; }
.top-bar:backdrop { background-color: #0078D4; background-image: none; }
.top-title { color: #FFFFFF; font-size: 11.5px; font-weight: 600; padding: 0 2px 0 4px; }
.top-version { color: #B3D7F2; font-size: 9.5px; padding-bottom: 1px; }
.top-btn { background: none; border: none; box-shadow: none; border-radius: 3px; padding: 1px; }
.top-btn:hover { background-color: rgba(255,255,255,0.18); }
.top-bar button.titlebutton { background: none; border: none; box-shadow: none; color: #FFFFFF; padding: 1px; min-height: 0; min-width: 0; }
.top-bar button.titlebutton:hover { background-color: rgba(255,255,255,0.18); }
.top-search { background-color: rgba(255,255,255,0.92); background-image: none; border: none;
              border-radius: 3px; padding: 1px 6px; font-size: 11.5px; min-height: 0; }
.top-search:focus { background-color: #FFFFFF; }
.top-sync { background-color: #FFFFFF; background-image: none;
            border: none; border-radius: 999px; box-shadow: none;
            padding: 1px 7px; min-height: 0; color: #0078D4; }
.top-sync:hover { background-color: #E8F2FC; }
.top-spinner { color: #0078D4; }
.top-sync:active { background-color: #D6E8FA; }
.nav-settings { background-color: #FAF9F8; background-image: none; border: none;
                border-top: 1px solid #E1DFDD; border-radius: 0; box-shadow: none; padding: 5px 8px; }
.nav-settings:hover { background-color: #EDEBE9; }
.nav-settings label { color: #0078D4; font-weight: 600; }
.command-bar { background-color: #FFFFFF; border-bottom: 1px solid #E1DFDD; padding: 1px 4px; }
.compose-bar { padding: 0 2px; }
.compose-bar button { padding: 0 5px; min-height: 0; font-size: 12px; }
.compose-bar .send-btn { padding: 0 10px; font-size: 12px; }
.compose-bar .tool-btn { min-height: 0; padding: 0 4px; font-size: 12px; }
.cmd-btn { background: none; border: none; box-shadow: none; border-radius: 3px;
           padding: 4px 7px; font-size: 12.5px; color: #323130; }
.cmd-btn:hover { background-color: #F0F0F0; }
.cmd-btn:disabled { color: #A19F9D; }
.cmd-new { color: #0078D4; font-weight: 600; }
.cmd-sep { background-color: #E1DFDD; margin: 5px 4px; }
.pill-tab { background: none; border: none; box-shadow: none; border-radius: 0;
            padding: 6px 12px 4px 12px; font-size: 13.5px; color: #605E5C;
            border-bottom: 2px solid transparent; }
.pill-tab:hover { color: #0078D4; }
.pill-tab-active { color: #0078D4; font-weight: 700; border-bottom: 2px solid #0078D4; }
.pill-filter { background: none; border: none; box-shadow: none; border-radius: 3px;
               padding: 4px 8px; font-size: 12.5px; color: #0078D4; }
.pill-filter:hover { background-color: #F0F0F0; }
.more-btn { background: none; border: none; box-shadow: none; color: %(ACCENT)s;
            font-size: 13px; padding: 10px; }
.more-btn:hover { background-color: %(LIST_HOVER)s; }
.msg-group-row { background-color: #FAF9F8; }
.group-header { font-size: 11.5px; font-weight: 600; color: #605E5C; padding: 7px 14px 3px 14px; }
""" % {"ACCENT": ACCENT, "ACCENT_DARK": ACCENT_DARK, "NAV_BG": NAV_BG, "NAV_HOVER": NAV_HOVER,
       "NAV_SEL": NAV_SEL, "LIST_HOVER": LIST_HOVER, "LIST_SEL": LIST_SEL, "BORDER": BORDER,
       "TEXT": TEXT, "TEXT_DIM": TEXT_DIM})

def apply_css():
    prov = Gtk.CssProvider()
    prov.load_from_data(CSS.encode())
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)

# ---------- iconos cairo (linea, estilo Windows/Fluent) ----------
def _surface(size=16):
    s = cairo.ImageSurface(cairo.FORMAT_ARGB32, size, size)
    return s, cairo.Context(s)

def _pix(surface):
    return Gdk.pixbuf_get_from_surface(surface, 0, 0, surface.get_width(), surface.get_height())

def _stroke(ctx, color="#323130", width=1.4):
    r, g, b = _rgb(color)
    ctx.set_source_rgb(r, g, b)
    ctx.set_line_width(width)
    ctx.set_line_cap(cairo.LINE_CAP_ROUND)
    ctx.set_line_join(cairo.LINE_JOIN_ROUND)
    ctx.stroke()

def _rgb(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i+2], 16) / 255.0 for i in (0, 2, 4))

def _fill(ctx, color):
    r, g, b = _rgb(color)
    ctx.set_source_rgb(r, g, b)
    ctx.fill()

def icon_pixbuf(name, size=16, color="#323130", width=1.0):
    s, c = _surface(size)
    k = size / 16.0
    c.scale(k, k)
    c.set_line_cap(cairo.LINE_CAP_ROUND)
    c.set_line_join(cairo.LINE_JOIN_ROUND)
    c.set_line_width(width)
    r, g, b = _rgb(color)
    c.set_source_rgb(r, g, b)
    if name == "inbox":          # bandeja
        c.move_to(2, 10); c.line_to(4.5, 3.5); c.line_to(11.5, 3.5); c.line_to(14, 10)
        c.line_to(11, 10); c.line_to(10, 12); c.line_to(6, 12); c.line_to(5, 10); c.close_path()
        c.stroke()
    elif name == "drafts":       # lapiz
        c.move_to(10.8, 2.4); c.line_to(13.6, 5.2); c.line_to(6, 12.8); c.line_to(2.8, 13.6)
        c.line_to(3.5, 10.4); c.close_path(); c.stroke()
        c.move_to(9.6, 3.6); c.line_to(12.4, 6.4); c.stroke()
    elif name == "sent":         # avion de papel
        c.move_to(2, 8); c.line_to(14, 2); c.line_to(10, 14); c.line_to(7.5, 10.5); c.close_path()
        c.stroke()
        c.move_to(14, 2); c.line_to(7.5, 10.5); c.stroke()
    elif name == "archive":      # caja
        c.rectangle(2, 3, 12, 3.4); c.stroke()
        c.move_to(2.8, 6.4); c.line_to(2.8, 13); c.line_to(13.2, 13); c.line_to(13.2, 6.4); c.stroke()
        c.move_to(6.4, 8.4); c.line_to(9.6, 8.4); c.stroke()
    elif name == "junk":         # circulo !
        c.arc(8, 8, 5.8, 0, 2 * math.pi); c.stroke()
        c.move_to(8, 5); c.line_to(8, 9); c.stroke()
        c.arc(8, 11.3, 0.35, 0, 2 * math.pi); c.fill()
    elif name == "trash":        # papelera
        c.move_to(3, 4.6); c.line_to(13, 4.6); c.stroke()
        c.move_to(6.2, 4.6); c.line_to(6.2, 3); c.line_to(9.8, 3); c.line_to(9.8, 4.6); c.stroke()
        c.move_to(4.4, 4.6); c.line_to(5.2, 13); c.line_to(10.8, 13); c.line_to(11.6, 4.6); c.stroke()
        c.move_to(7, 6.6); c.line_to(7, 11); c.move_to(9, 6.6); c.line_to(9, 11); c.stroke()
    elif name == "reply":
        c.move_to(6.5, 3); c.line_to(2.5, 7); c.line_to(6.5, 11); c.stroke()
        c.move_to(2.5, 7); c.line_to(10, 7)
        c.arc_negative(8.5, 12.5, 5.5, 0, -math.pi / 2); c.stroke()
    elif name == "reply_all":
        c.move_to(5.5, 3); c.line_to(1.5, 7); c.line_to(5.5, 11); c.stroke()
        c.move_to(9, 3); c.line_to(5, 7); c.line_to(9, 11); c.stroke()
        c.move_to(5, 7); c.line_to(11, 7)
        c.arc_negative(9.5, 12.5, 5.5, 0, -math.pi / 2); c.stroke()
    elif name == "forward":
        c.move_to(9.5, 3); c.line_to(13.5, 7); c.line_to(9.5, 11); c.stroke()
        c.move_to(13.5, 7); c.line_to(6, 7)
        c.arc(7.5, 12.5, 5.5, math.pi, 3 * math.pi / 2); c.stroke()
    elif name == "compose":
        c.move_to(10.8, 2.4); c.line_to(13.6, 5.2); c.line_to(6, 12.8); c.line_to(2.8, 13.6)
        c.line_to(3.5, 10.4); c.close_path(); c.stroke()
    elif name == "refresh":
        c.arc(8, 8, 5.5, 0.6, 5.0); c.stroke()
        c.move_to(13.8, 6.8); c.line_to(13.5, 3.2); c.line_to(10.6, 5.4); c.stroke()
    elif name == "gear":
        c.arc(8, 8, 2.1, 0, 2 * math.pi); c.stroke()
        for i in range(8):
            a = i * math.pi / 4
            x1, y1 = 8 + 3.6 * math.cos(a), 8 + 3.6 * math.sin(a)
            x2, y2 = 8 + 5.6 * math.cos(a), 8 + 5.6 * math.sin(a)
            c.move_to(x1, y1); c.line_to(x2, y2); c.stroke()
    elif name == "hamburger":
        for y in (4, 8, 12):
            c.move_to(3, y); c.line_to(13, y); c.stroke()
    elif name == "search":
        c.arc(7, 7, 4.4, 0, 2 * math.pi); c.stroke()
        c.move_to(10.3, 10.3); c.line_to(14, 14); c.stroke()
    elif name == "clip":
        c.move_to(11.5, 6.5); c.line_to(6, 12); 
        c.arc_negative(4.9, 10.9, 1.6, math.pi * 0.25, math.pi * 1.75)
        c.line_to(10.4, 5.4)
        c.arc_negative(9.3, 4.3, 1.6, math.pi * 0.75, math.pi * 2.25)
        c.line_to(4.2, 9.4); c.stroke()
    elif name == "flag":
        c.move_to(4, 14); c.line_to(4, 2.4); c.stroke()
        c.move_to(4, 3); c.line_to(12.5, 3); c.line_to(10, 6); c.line_to(12.5, 9); c.line_to(4, 9); c.stroke()
    elif name == "more":
        for x in (3.5, 8, 12.5):
            c.arc(x, 8, 0.9, 0, 2 * math.pi); c.fill()
    elif name == "unread":       # sobre con punto
        c.rectangle(2, 4, 12, 8.6); c.stroke()
        c.move_to(2, 4.5); c.line_to(8, 9); c.line_to(14, 4.5); c.stroke()
    elif name == "envelope":
        c.rectangle(2, 4, 12, 8.6); c.stroke()
        c.move_to(2, 4.5); c.line_to(8, 9); c.line_to(14, 4.5); c.stroke()
    elif name == "attach-dl":
        c.move_to(8, 2.5); c.line_to(8, 10); c.stroke()
        c.move_to(4.8, 6.8); c.line_to(8, 10); c.line_to(11.2, 6.8); c.stroke()
        c.move_to(3, 13); c.line_to(13, 13); c.stroke()
    elif name == "close":
        c.move_to(4, 4); c.line_to(12, 12); c.move_to(12, 4); c.line_to(4, 12); c.stroke()
    elif name == "account":
        c.arc(8, 5.4, 2.8, 0, 2 * math.pi); c.stroke()
        c.arc(8, 15.5, 5.6, math.pi * 1.15, math.pi * 1.85); c.stroke()
    elif name == "plus":
        c.move_to(8, 3.5); c.line_to(8, 12.5)
        c.move_to(3.5, 8); c.line_to(12.5, 8); c.stroke()
    elif name == "filter":          # embudo
        c.move_to(3, 4); c.line_to(13, 4); c.line_to(9.2, 9); c.line_to(9.2, 12.5)
        c.line_to(6.8, 11.3); c.line_to(6.8, 9); c.close_path(); c.stroke()
    elif name == "move":            # carpeta con flecha
        c.move_to(2.5, 5.5); c.line_to(6, 5.5); c.line_to(7.2, 3.8); c.line_to(13.5, 3.8)
        c.line_to(13.5, 12.3); c.line_to(2.5, 12.3); c.close_path(); c.stroke()
        c.move_to(6.2, 8.6); c.line_to(10.8, 8.6)
        c.move_to(9.3, 7.1); c.line_to(10.8, 8.6); c.line_to(9.3, 10.1); c.stroke()
    elif name == "tag":             # etiqueta
        c.move_to(2.8, 3); c.line_to(8.5, 3); c.line_to(13.2, 7.8); c.line_to(8, 13); c.close_path()
        c.stroke()
        c.arc(6, 5.4, 1.1, 0, 2 * math.pi); c.fill()
    elif name == "chevron-down":
        c.move_to(4.5, 6.5); c.line_to(8, 10); c.line_to(11.5, 6.5); c.stroke()
    elif name == "send":          # avion de papel
        c.move_to(2, 8.6); c.line_to(14, 2.2); c.line_to(9.4, 13.8); c.line_to(7.1, 9.9)
        c.close_path(); c.stroke()
        c.move_to(7.1, 9.9); c.line_to(14, 2.2); c.stroke()
    elif name == "save":          # disquete
        c.move_to(2.8, 2.6); c.line_to(11, 2.6); c.line_to(13.4, 5); c.line_to(13.4, 13.4)
        c.line_to(2.8, 13.4); c.close_path(); c.stroke()
        c.rectangle(5.2, 2.6, 5.4, 3.4); c.stroke()
        c.rectangle(5.2, 8.2, 5.6, 5.2); c.stroke()
    elif name == "getmail":       # sobre con flecha abajo (recibir)
        c.rectangle(1.2, 2.2, 10, 7); c.stroke()
        c.move_to(1.7, 2.8); c.line_to(6.2, 6.6); c.line_to(10.7, 2.8); c.stroke()
        c.move_to(13.2, 7.6); c.line_to(13.2, 13.4); c.stroke()
        c.move_to(11.2, 11.4); c.line_to(13.2, 13.4); c.line_to(15.2, 11.4); c.stroke()
    elif name == "check":
        c.move_to(3, 8.5); c.line_to(6.8, 12); c.line_to(13, 4.5); c.stroke()
    else:
        c.arc(8, 8, 5.5, 0, 2 * math.pi); c.stroke()
    return _pix(s)

def icon_image(name, size=16, color="#323130", width=1.0):
    pb = icon_pixbuf(name, size * 2, color, width)
    img = Gtk.Image.new_from_pixbuf(pb)
    img.set_size_request(size, size)
    return img

AVATAR_COLORS = ["#0078D4", "#5C2E91", "#B4009E", "#E3008C", "#C239B3", "#498205",
                 "#0B6A0B", "#038387", "#CA5010", "#986F0B", "#A4262C"]

def initials(name_or_addr):
    s = (name_or_addr or "?").strip()
    if "@" in s and " " not in s:
        s = s.split("@")[0]
    parts = [p for p in re_split_words(s) if p]
    if not parts:
        return "?"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][0] + parts[-1][0]).upper()

def re_split_words(s):
    import re
    return re.split(r"[\s._\-]+", s)

_avatar_css_done = set()
def _ensure_avatar_css(size):
    if size in _avatar_css_done:
        return
    rules = "".join(".avatar-%d-%d { background-color: %s; border-radius: 999px; color: white; }"
                    % (size, i, col) for i, col in enumerate(AVATAR_COLORS))
    prov = Gtk.CssProvider()
    prov.load_from_data(rules.encode())
    Gtk.StyleContext.add_provider_for_screen(
        Gdk.Screen.get_default(), prov, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION + 1)
    _avatar_css_done.add(size)

def avatar_widget(name_or_addr, size=32):
    idx = zlib.crc32((name_or_addr or "?").encode("utf-8")) % len(AVATAR_COLORS)
    _ensure_avatar_css(size)
    lbl = Gtk.Label(label=initials(name_or_addr))
    lbl.get_style_context().add_class("avatar")
    lbl.get_style_context().add_class("avatar-%d-%d" % (size, idx))
    lbl.set_size_request(size, size)
    lbl.set_halign(Gtk.Align.CENTER)
    lbl.set_valign(Gtk.Align.CENTER)
    return lbl
