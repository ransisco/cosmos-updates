# -*- coding: utf-8 -*-
"""OAuth2 (authorization code + PKCE) para Outlook.com/Hotmail y Gmail,
con client_ids publicos de Thunderbird. Sin registro de apps ni cuentas nuevas.
Los refresh tokens y contrasenas de aplicacion se guardan cifrados con
AES-256 en archivos locales (sin libsecret ni llaveros); nunca en texto plano."""
import base64, hashlib, json, os, secrets, socket, ssl, stat, subprocess, threading, urllib.parse, urllib.request

OUTLOOK = {
    "auth": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
    "token": "https://login.microsoftonline.com/common/oauth2/v2.0/token",
    "client_id": "9e5f94bc-e8a4-4e73-b8be-63364c29d753",
    "scope": "https://outlook.office.com/IMAP.AccessAsUser.All https://outlook.office.com/SMTP.Send offline_access",
    "redirect_host": "localhost",
    "imap_host": "outlook.office365.com", "imap_port": 993,
    "smtp_host": "smtp-mail.outlook.com", "smtp_port": 587,
}
GMAIL = {
    "auth": "https://accounts.google.com/o/oauth2/auth",
    "token": "https://www.googleapis.com/oauth2/v3/token",
    "client_id": "406964657835-aq8lmia8j95dhl1a2bvharmfk3t1hgqj.apps.googleusercontent.com",
    "client_secret": "kSmqreRr0qwBWJgbf5Y-PjSU",
    "scope": "https://mail.google.com/",
    "redirect_host": "127.0.0.1",
    "imap_host": "imap.gmail.com", "imap_port": 993,
    "smtp_host": "smtp.gmail.com", "smtp_port": 587,
}
PROVIDERS = {"outlook": OUTLOOK, "gmail": GMAIL}

class OAuthError(Exception):
    pass

# ---------- almacenamiento cifrado local (sin libsecret) ----------
# Cada token/contrasena de aplicacion se guarda en ~/.config/correo/tok-<cuenta>.enc
# cifrado con AES-256-CBC (openssl, presente en cualquier Mint) usando una clave
# aleatoria de 256 bits generada en el primer uso (~/.config/correo/.k, permisos 600).
# Sin libsecret, sin secret-tool, sin llaveros ni cuentas de terceros.

def _conf_dir():
    d = os.path.join(os.path.expanduser("~"), ".config", "email")
    os.makedirs(d, exist_ok=True)
    os.chmod(d, 0o700)
    return d

def _token_file(email):
    safe = email.replace("/", "_")
    return os.path.join(_conf_dir(), "tok-" + safe + ".enc")

def _key_file():
    k = os.path.join(_conf_dir(), ".k")
    if not os.path.exists(k):
        with open(k, "wb") as f:
            f.write(secrets.token_bytes(32))
        os.chmod(k, stat.S_IRUSR | stat.S_IWUSR)
    return k

def token_store(email, token_json):
    p = subprocess.run(["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-pass", "file:" + _key_file(),
        "-out", _token_file(email)], input=token_json.encode(), timeout=15)
    if p.returncode != 0:
        raise OAuthError("No se pudo guardar el token de forma segura")
    os.chmod(_token_file(email), stat.S_IRUSR | stat.S_IWUSR)

def token_load(email):
    f = _token_file(email)
    if not os.path.exists(f):
        return None
    p = subprocess.run(["openssl", "enc", "-d", "-aes-256-cbc", "-pbkdf2", "-pass", "file:" + _key_file(),
        "-in", f], capture_output=True, timeout=15)
    if p.returncode != 0:
        return None
    return p.stdout.decode()

def token_clear(email):
    try:
        os.remove(_token_file(email))
    except OSError:
        pass

# ---------- flujo authorization code + PKCE ----------
def _pkce():
    verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode()
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge

def build_auth_url(provider_key, redirect_uri, challenge, state, login_hint=None):
    p = PROVIDERS[provider_key]
    q = {"response_type": "code", "client_id": p["client_id"], "redirect_uri": redirect_uri,
         "scope": p["scope"], "state": state, "code_challenge": challenge, "code_challenge_method": "S256"}
    if login_hint:
        q["login_hint"] = login_hint
    if provider_key == "gmail":
        q["access_type"] = "offline"
        q["prompt"] = "consent"
    else:
        q["response_mode"] = "query"
    return p["auth"] + "?" + urllib.parse.urlencode(q)

def exchange_code(provider_key, code, redirect_uri, verifier):
    p = PROVIDERS[provider_key]
    data = {"client_id": p["client_id"], "grant_type": "authorization_code", "code": code,
            "redirect_uri": redirect_uri, "code_verifier": verifier}
    if p.get("client_secret"):
        data["client_secret"] = p["client_secret"]
    return _post_token(p["token"], data)

def refresh_token(provider_key, refresh):
    p = PROVIDERS[provider_key]
    data = {"client_id": p["client_id"], "grant_type": "refresh_token", "refresh_token": refresh}
    if p.get("client_secret"):
        data["client_secret"] = p["client_secret"]
    if provider_key == "outlook":
        data["scope"] = p["scope"]
    return _post_token(p["token"], data)

def _post_token(url, data):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body, headers={"Content-Type": "application/x-www-form-urlencoded"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        try:
            err = json.loads(e.read().decode() or "{}")
        except Exception:
            err = {}
        desc = err.get("error_description") or err.get("error") or ("HTTP " + str(e.code))
        raise OAuthError(desc)
    except Exception as e:
        raise OAuthError(str(e))

class LoopbackServer:
    """Servidor HTTP local efimero para capturar el codigo de autorizacion."""
    def __init__(self, provider_key):
        self.provider_key = provider_key
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.bind(("127.0.0.1", 0))
        self.sock.listen(1)
        self.sock.settimeout(300)
        self.port = self.sock.getsockname()[1]
        host = PROVIDERS[provider_key]["redirect_host"]
        self.redirect_uri = "http://%s:%d/" % (host, self.port)
        self.result = None
        self.thread = None

    def start(self):
        self.thread = threading.Thread(target=self._serve, daemon=True)
        self.thread.start()

    def _serve(self):
        try:
            conn, _ = self.sock.accept()
            conn.settimeout(30)
            data = b""
            while b"\r\n\r\n" not in data:
                chunk = conn.recv(4096)
                if not chunk:
                    break
                data += chunk
            line = data.split(b"\r\n", 1)[0].decode("latin1")
            path = line.split(" ")[1] if " " in line else "/"
            params = urllib.parse.parse_qs(urllib.parse.urlparse(path).query)
            self.result = {k: v[0] for k, v in params.items()}
            page = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n"
                "<html><head><title>Email</title></head><body style='font-family:sans-serif;text-align:center;padding:60px'>"
                "<h2>Sesi&oacute;n iniciada</h2><p>Ya puedes cerrar esta pesta&ntilde;a y volver a <b>Email</b>.</p></body></html>")
            if "error" in self.result:
                page = page.replace("Sesi&oacute;n iniciada", "No se pudo iniciar sesi&oacute;n").replace(
                    "Ya puedes cerrar", "Se ha producido un error. Cierra esta pesta&ntilde;a y vuelve a Email.")
            conn.sendall(page.encode())
            conn.close()
        except Exception as e:
            self.result = {"error": str(e)}
        finally:
            try:
                self.sock.close()
            except Exception:
                pass

def run_auth_flow(provider_key, email_hint, open_url, on_progress=None):
    """Devuelve dict de tokens. open_url(url) abre el navegador.
    Devuelve (server, url, verifier) para flujo manual: el llamador gestiona la espera."""
    server = LoopbackServer(provider_key)
    verifier, challenge = _pkce()
    state = secrets.token_urlsafe(16)
    url = build_auth_url(provider_key, server.redirect_uri, challenge, state, login_hint=email_hint)
    return server, url, verifier, state

def complete_manual(provider_key, pasted, redirect_uri, verifier):
    """Extrae el codigo de una URL pegada por el usuario y lo canjea."""
    parsed = urllib.parse.urlparse(pasted.strip())
    params = urllib.parse.parse_qs(parsed.query)
    if not params:
        # quizas pego solo el codigo
        if pasted.strip() and " " not in pasted.strip():
            return exchange_code(provider_key, pasted.strip(), redirect_uri, verifier)
        raise OAuthError("No se encontró ningún código en la dirección pegada")
    if "error" in params:
        raise OAuthError(params.get("error_description", params["error"])[0])
    code = params.get("code", [None])[0]
    if not code:
        raise OAuthError("No se encontró ningún código en la dirección pegada")
    return exchange_code(provider_key, code, redirect_uri, verifier)
