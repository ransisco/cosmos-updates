# -*- coding: utf-8 -*-
"""Motor de correo: cache local sqlite, IMAP/SMTP con XOAUTH2, analisis de mensajes."""
import base64, contextlib, email, email.header, email.policy, email.utils, html, imaplib, json, os, re, smtplib, sqlite3, ssl, threading, time

import oauth_flow

DATA_DIR = os.path.join(os.path.expanduser("~"), ".local", "share", "email")
DB_PATH = os.path.join(DATA_DIR, "correo.db")
ATT_DIR = os.path.join(DATA_DIR, "adjuntos")

LOG_PATH = os.path.join(DATA_DIR, "sync.log")

def log(msg):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        line = "%s %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg)
        with open(LOG_PATH, "a") as f:
            f.write(line)
        # recorte: conserva las ultimas ~2000 lineas
        try:
            if os.path.getsize(LOG_PATH) > 300000:
                with open(LOG_PATH) as f:
                    lines = f.readlines()[-1000:]
                with open(LOG_PATH, "w") as f:
                    f.writelines(lines)
        except OSError:
            pass
    except OSError:
        pass

FLAG_READ = 1
FLAG_FLAGGED = 2
FLAG_ANSWERED = 4

FOLDER_DEFS = [
    ("inbox",   "Bandeja de entrada"),
    ("drafts",  "Borradores"),
    ("sent",    "Elementos enviados"),
    ("archive", "Archivados"),
    ("junk",    "Correo no deseado"),
    ("trash",   "Papelera"),
]
SPECIAL_USE = {
    "\\sent": "sent", "\\drafts": "drafts", "\\junk": "junk", "\\spam": "junk",
    "\\trash": "trash", "\\archive": "archive", "\\all": "archive",
}
REMOTE_CREATE = {"archive": "Archivados", "trash": "Papelera"}

REMOTE_FALLBACK = {
    "inbox": ["INBOX"],
    "sent": ["Sent", "Sent Items", "Elementos enviados", "Enviados", "[Gmail]/Sent Mail", "&A4U-,", "Gesendet"],
    "drafts": ["Drafts", "Borradores", "[Gmail]/Drafts", "[Gmail]/Borradores", "Entw&APw-rfe"],
    "archive": ["Archive", "Archivados", "[Gmail]/All Mail", "[Gmail]/Todos"],
    "junk": ["Junk", "Junk Email", "Spam", "Correo no deseado", "[Gmail]/Spam", "[Gmail]/Correo no deseado"],
    "trash": ["Trash", "Deleted", "Deleted Items", "Papelera", "Elementos eliminados", "[Gmail]/Trash", "[Gmail]/Bin", "[Gmail]/Papelera"],
}

def imap_utf7_encode(s):
    out = []
    buf = []
    def flush():
        if buf:
            raw = "".join(buf).encode("utf-16-be")
            out.append("&" + base64.b64encode(raw).decode().rstrip("=").replace("/", ",") + "-")
            buf.clear()
    for ch in s:
        o = ord(ch)
        if 0x20 <= o <= 0x7E:
            flush()
            out.append("&-" if ch == "&" else ch)
        else:
            buf.append(ch)
    flush()
    return "".join(out)

def imap_utf7_decode(s):
    def rep(m):
        t = m.group(1).replace(",", "/")
        t += "=" * (-len(t) % 4)
        try:
            return base64.b64decode(t).decode("utf-16-be")
        except Exception:
            return m.group(0)
    return re.sub(r"&([^-]*)-", rep, s)

def decode_header_value(v):
    if v is None:
        return ""
    try:
        parts = email.header.decode_header(v)
        out = []
        for txt, enc in parts:
            if isinstance(txt, bytes):
                out.append(txt.decode(enc or "utf-8", "replace"))
            else:
                out.append(txt)
        return "".join(out)
    except Exception:
        return str(v)

def parse_address_list(v):
    if not v:
        return []
    out = []
    try:
        for name, addr in email.utils.getaddresses([decode_header_value(v)]):
            if addr:
                out.append((name, addr))
    except Exception:
        pass
    return out

def html_to_text(s):
    s = re.sub(r"(?is)<(script|style).*?</\1>", " ", s)
    s = re.sub(r"(?is)<br\s*/?>", "\n", s)
    s = re.sub(r"(?is)</(p|div|tr|li|h[1-6]|blockquote|table)>", "\n", s)
    s = re.sub(r"(?is)<li[^>]*>", "  - ", s)
    s = re.sub(r"(?is)</t[dh]>", "  |  ", s)
    s = re.sub(r"(?is)<[^>]+>", "", s)
    s = html.unescape(s)
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n\s*\n\s*\n+", "\n\n", s)
    return s.strip()

def extract_bodies(msg):
    """Devuelve (texto, html, adjuntos[(filename,mime,size,part_index)])."""
    text_parts, html_parts, atts = [], [], []
    idx = [0]
    def walk(part):
        ctype = part.get_content_type()
        disp = (part.get("Content-Disposition") or "").lower()
        if part.is_multipart():
            for sub in part.iter_parts() if hasattr(part, "iter_parts") else part.get_payload():
                walk(sub)
            return
        if ctype.startswith("multipart/"):
            return
        filename = part.get_filename()
        if filename:
            filename = decode_header_value(filename)
        is_att = "attachment" in disp or (filename and ctype != "text/plain" and ctype != "text/html") or \
                 ("inline" in disp and filename and not ctype.startswith("text/"))
        if is_att:
            idx[0] += 1
            try:
                size = len(part.get_payload(decode=True) or b"")
            except Exception:
                size = 0
            atts.append((filename or ("adjunto-%d" % idx[0]), ctype, size, idx[0]))
            return
        if ctype == "text/plain" and "attachment" not in disp:
            try:
                payload = part.get_payload(decode=True) or b""
                cs = part.get_content_charset() or "utf-8"
                text_parts.append(payload.decode(cs, "replace"))
            except Exception:
                pass
        elif ctype == "text/html" and "attachment" not in disp:
            try:
                payload = part.get_payload(decode=True) or b""
                cs = part.get_content_charset() or "utf-8"
                html_parts.append(payload.decode(cs, "replace"))
            except Exception:
                pass
    walk(msg)
    text = "\n".join(t for t in text_parts if t).strip()
    body_html = "\n".join(h for h in html_parts if h).strip()
    if not text and body_html:
        text = html_to_text(body_html)
    return text, body_html, atts

def make_preview(text, limit=180):
    t = re.sub(r"\s+", " ", text or "").strip()
    return t[:limit]

def xoauth2_string(user, token):
    return "user=%s\x01auth=Bearer %s\x01\x01" % (user, token)


FETCH_ITEMS = "(UID FLAGS INTERNALDATE RFC822.SIZE ENVELOPE BODYSTRUCTURE)"
FETCH_ITEMS_MIN = "(UID FLAGS INTERNALDATE RFC822.SIZE)"

def _quote_literal(b):
    return b'"' + b.replace(b"\\", b"\\\\").replace(b'"', b'\\"') + b'"'

def _iter_fetch_responses(data):
    """Reensambla la respuesta FETCH de imaplib: cada mensaje llega como una o
    varias tuplas (texto, literal) mas bytes de continuacion. Se unen en una
    sola linea por mensaje; los literales se entrecomillan y se decodifican
    (ascii, luego utf-8, luego latin1) para que ENVELOPE/BODYSTRUCTURE no se
    rompan ni salgan caracteres corruptos."""
    bufs = []
    cur = None
    def feed(s):
        nonlocal cur
        if cur is None:
            cur = ""
        cur += s
    def as_text(b):
        if isinstance(b, str):
            return b
        try:
            return b.decode("ascii")
        except UnicodeDecodeError:
            try:
                return b.decode("utf-8")
            except UnicodeDecodeError:
                return b.decode("latin1")
    for raw in data or []:
        if isinstance(raw, tuple):
            parts = [el for el in raw if isinstance(el, (bytes, str))]
            if not parts:
                continue
            text = re.sub(r"\{\d+\}$", "", as_text(parts[0]))
            if re.match(r"^\d+ \(", text):
                if cur is not None:
                    bufs.append(cur)
                cur = None
            feed(text)
            for lit in parts[1:]:
                s = as_text(lit).replace("\\", "\\\\").replace('"', '\\"')
                feed('"' + s + '"')
        elif isinstance(raw, (bytes, str)):
            s = as_text(raw)
            if re.match(r"^\d+ \(", s):
                if cur is not None:
                    bufs.append(cur)
                cur = None
            feed(s)
    if cur is not None:
        bufs.append(cur)
    return bufs

class AccountState:
    def __init__(self, row):
        self.id, self.provider, self.email, self.name, self.signature, self.state = row
        self._token = None
        self._token_exp = 0

    def conf(self):
        if self.provider == "gmailpass":
            return oauth_flow.GMAIL
        return oauth_flow.PROVIDERS[self.provider]

    def is_app_password(self):
        return self.provider == "gmailpass"

    def get_access_token(self, force_refresh=False):
        if self.is_app_password():
            raw = oauth_flow.token_load(self.email)
            if not raw:
                raise oauth_flow.OAuthError("Sin sesión guardada para " + self.email)
            data = json.loads(raw)
            pw = data.get("app_password")
            if not pw:
                raise oauth_flow.OAuthError("Falta la contraseña de aplicación")
            return pw
        if self._token and time.time() < self._token_exp - 60 and not force_refresh:
            return self._token
        raw = oauth_flow.token_load(self.email)
        if not raw:
            raise oauth_flow.OAuthError("Sin sesión guardada para " + self.email)
        data = json.loads(raw)
        rt = data.get("refresh_token")
        if not rt:
            raise oauth_flow.OAuthError("Falta el token de actualización")
        out = oauth_flow.refresh_token(self.provider, rt)
        if "refresh_token" not in out:
            out["refresh_token"] = rt
        oauth_flow.token_store(self.email, json.dumps(out))
        self._token = out["access_token"]
        self._token_exp = time.time() + int(out.get("expires_in", 3600))
        return self._token

class CorreoDB:
    def __init__(self, path=DB_PATH):
        os.makedirs(DATA_DIR, exist_ok=True)
        os.makedirs(ATT_DIR, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self._batch = 0
        self._lock = threading.RLock()
        self._create()

    def _create(self):
        c = self.conn
        c.execute("""CREATE TABLE IF NOT EXISTS accounts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, provider TEXT, email TEXT UNIQUE,
            name TEXT, signature TEXT DEFAULT '', state TEXT DEFAULT 'ok')""")
        c.execute("""CREATE TABLE IF NOT EXISTS folders(
            id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INT, name TEXT, remote TEXT,
            special TEXT, unseen INT DEFAULT 0, uidvalidity INT, last_uid INT DEFAULT 0,
            UNIQUE(account_id, remote))""")
        c.execute("""CREATE TABLE IF NOT EXISTS messages(
            id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INT, folder_id INT, uid INT,
            msgid TEXT, ts INT, from_name TEXT, from_addr TEXT, to_addrs TEXT, cc_addrs TEXT,
            subject TEXT, preview TEXT, flags INT DEFAULT 0, has_attach INT DEFAULT 0,
            size INT DEFAULT 0, body_text TEXT, body_html TEXT, blocked INT DEFAULT 0,
            categories TEXT DEFAULT '',
            UNIQUE(folder_id, uid))""")
        c.execute("""CREATE TABLE IF NOT EXISTS attachments(
            id INTEGER PRIMARY KEY AUTOINCREMENT, message_id INT, filename TEXT, mime TEXT,
            size INT, part_index INT, path TEXT)""")
        c.execute("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT)")
        c.execute("""CREATE TABLE IF NOT EXISTS trusted_senders(
            account_id INT, addr TEXT, UNIQUE(account_id, addr))""")
        c.execute("""CREATE TABLE IF NOT EXISTS blocked_senders(
            account_id INT, addr TEXT, UNIQUE(account_id, addr))""")
        try:
            c.execute("ALTER TABLE messages ADD COLUMN categories TEXT DEFAULT ''")
        except Exception:
            pass
        try:
            c.execute("ALTER TABLE messages ADD COLUMN urgent INT DEFAULT 0")
        except Exception:
            pass
        c.execute("CREATE INDEX IF NOT EXISTS idx_msg_folder ON messages(folder_id, ts DESC)")
        # carpetas creadas por ensure_folder_remote llevaban el nombre remoto en ingles
        for sp, en in (("archive", "Archive"), ("trash", "Trash")):
            c.execute("UPDATE folders SET name=? WHERE special=? AND name=?",
                      (dict(FOLDER_DEFS)[sp], sp, en))
        c.commit()

    def q(self, sql, args=()):
        with self._lock:
            return self.conn.execute(sql, args).fetchall()

    def one(self, sql, args=()):
        with self._lock:
            return self.conn.execute(sql, args).fetchone()

    def run(self, sql, args=()):
        with self._lock:
            cur = self.conn.execute(sql, args)
            # los lotes pertenecen al hilo que los abrio: escrituras de otros
            # hilos (p.ej. la UI) confirman de inmediato y no quedan atrapadas
            # en la transaccion del sincronizador
            if not self._batch or threading.get_ident() != getattr(self, "_batch_owner", None):
                self.conn.commit()
            return cur

    def batch_begin(self):
        self._batch += 1
        self._batch_owner = threading.get_ident()

    def batch_end(self):
        with self._lock:
            self._batch = max(0, self._batch - 1)
            if not self._batch:
                self._batch_owner = None
                self.conn.commit()

    def set_categories(self, msg_id, cats):
        self.run("UPDATE messages SET categories=? WHERE id=?", (",".join(cats), msg_id))

    def accounts(self):
        return [AccountState((r["id"], r["provider"], r["email"], r["name"], r["signature"], r["state"]))
                for r in self.q("SELECT * FROM accounts ORDER BY id")]

    def add_account(self, provider, email_addr, name=""):
        self.run("INSERT OR IGNORE INTO accounts(provider,email,name) VALUES(?,?,?)",
                 (provider, email_addr, name))
        return self.one("SELECT * FROM accounts WHERE email=?", (email_addr,))["id"]

    def remove_account(self, account_id):
        acc = self.one("SELECT email FROM accounts WHERE id=?", (account_id,))
        if acc:
            oauth_flow.token_clear(acc["email"])
        mids = [r["id"] for r in self.q("SELECT id FROM messages WHERE account_id=?", (account_id,))]
        for m in mids:
            for a in self.q("SELECT path FROM attachments WHERE message_id=?", (m,)):
                if a["path"]:
                    try:
                        os.remove(a["path"])
                    except OSError:
                        pass
        self.run("DELETE FROM attachments WHERE message_id IN (SELECT id FROM messages WHERE account_id=?)", (account_id,))
        self.run("DELETE FROM messages WHERE account_id=?", (account_id,))
        self.run("DELETE FROM folders WHERE account_id=?", (account_id,))
        self.run("DELETE FROM trusted_senders WHERE account_id=?", (account_id,))
        self.run("DELETE FROM accounts WHERE id=?", (account_id,))

    def folders(self, account_id):
        return self.q("SELECT * FROM folders WHERE account_id=? ORDER BY CASE special "
                      "WHEN 'inbox' THEN 0 WHEN 'drafts' THEN 1 WHEN 'sent' THEN 2 "
                      "WHEN 'archive' THEN 3 WHEN 'junk' THEN 4 WHEN 'trash' THEN 5 ELSE 6 END, name", (account_id,))

    def folder_by_special(self, account_id, special):
        return self.one("SELECT * FROM folders WHERE account_id=? AND special=?", (account_id, special))

    def get_setting(self, key, default=None):
        r = self.one("SELECT value FROM settings WHERE key=?", (key,))
        return r["value"] if r else default

    def set_setting(self, key, value):
        self.run("INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)", (key, value))

    def trusted(self, account_id, addr):
        return self.one("SELECT 1 FROM trusted_senders WHERE account_id=? AND addr=?",
                        (account_id, addr.lower())) is not None

    def trust(self, account_id, addr):
        self.run("INSERT OR IGNORE INTO trusted_senders(account_id,addr) VALUES(?,?)",
                 (account_id, addr.lower()))

    def block(self, account_id, addr):
        self.run("INSERT OR IGNORE INTO blocked_senders(account_id,addr) VALUES(?,?)",
                 (account_id, addr.lower()))

    def unblock(self, account_id, addr):
        self.run("DELETE FROM blocked_senders WHERE account_id=? AND addr=?", (account_id, addr.lower()))

    def is_blocked(self, account_id, addr):
        return addr and self.one("SELECT 1 FROM blocked_senders WHERE account_id=? AND addr=?",
                                 (account_id, addr.lower())) is not None

    def blocked_list(self, account_id):
        return [r["addr"] for r in self.q("SELECT addr FROM blocked_senders WHERE account_id=? ORDER BY addr",
                                          (account_id,))]

    def trusted_list(self, account_id):
        return [r["addr"] for r in self.q("SELECT addr FROM trusted_senders WHERE account_id=? ORDER BY addr",
                                          (account_id,))]
    def untrust(self, account_id, addr):
        self.run("DELETE FROM trusted_senders WHERE account_id=? AND addr=?", (account_id, addr))

class MailBackend:
    def __init__(self, db):
        self.db = db
        self.on_new_mail = None      # fn(account, count)
        self.on_error = None         # fn(account, message)
        self.last_errors = {}
        self._reader_lock = threading.Lock()
        self._reader_im = {}         # account.id -> (imap, carpeta_seleccionada, ts)

    # ---- conexion ----
    def _imap_connect(self, account):
        conf = account.conf()
        ctx = ssl.create_default_context()
        im = imaplib.IMAP4_SSL(conf["imap_host"], conf["imap_port"], ssl_context=ctx, timeout=25)
        if account.is_app_password():
            im.login(account.email, account.get_access_token())
            return im
        token = account.get_access_token()
        auth = xoauth2_string(account.email, token)
        try:
            im.authenticate("XOAUTH2", lambda _: auth.encode())
        except imaplib.IMAP4.error:
            token = account.get_access_token(force_refresh=True)
            auth = xoauth2_string(account.email, token)
            im.authenticate("XOAUTH2", lambda _: auth.encode())
        return im

    @contextlib.contextmanager
    def _reader_session(self, account, folder_remote):
        """Conexion IMAP reutilizada para las lecturas de la UI (abrir mensajes,
        bajar adjuntos): evita TCP+TLS+LOGIN por mensaje (1-3 s cada uno)."""
        with self._reader_lock:
            im = None
            try:
                ent = self._reader_im.get(account.id)
                sel = None
                if ent:
                    im, sel, ts = ent
                    if time.time() - ts > 90:
                        try:
                            im.logout()
                        except Exception:
                            pass
                        im = None
                if im is None:
                    im = self._imap_connect(account)
                    sel = None
                if sel != folder_remote:
                    im.select('"%s"' % folder_remote.replace('"', '\\"'), readonly=False)
                    sel = folder_remote
                self._reader_im[account.id] = (im, sel, time.time())
                yield im
            except Exception:
                self._reader_im.pop(account.id, None)
                try:
                    if im:
                        im.logout()
                except Exception:
                    pass
                raise

    def _smtp_connect(self, account):
        conf = account.conf()
        sm = smtplib.SMTP(conf["smtp_host"], conf["smtp_port"], timeout=60)
        sm.ehlo()
        sm.starttls(context=ssl.create_default_context())
        sm.ehlo()
        if account.is_app_password():
            sm.login(account.email, account.get_access_token())
            return sm
        token = account.get_access_token()
        code, resp = sm.docmd("AUTH", "XOAUTH2 " + base64.b64encode(
            xoauth2_string(account.email, token).encode()).decode())
        if code != 235:
            token = account.get_access_token(force_refresh=True)
            code, resp = sm.docmd("AUTH", "XOAUTH2 " + base64.b64encode(
                xoauth2_string(account.email, token).encode()).decode())
            if code != 235:
                raise oauth_flow.OAuthError("SMTP rechazó la autenticación: %s" % resp)
        return sm

    # ---- carpetas ----
    def sync_folders(self, account, _im=None):
        im = _im or self._imap_connect(account)
        own = _im is None
        try:
            typ, data = im.list()
            if typ != "OK":
                return
            seen_special = {}
            for raw in data:
                if not raw:
                    continue
                line = raw.decode("latin1") if isinstance(raw, bytes) else raw
                m = re.match(r'\(([^)]*)\)\s+"([^"]+)"\s+"?(.+?)"?$', line)
                if not m:
                    m = re.match(r'\(([^)]*)\)\s+(\S+)\s+"?(.+?)"?$', line)
                if not m:
                    continue
                flags, delim, name = m.group(1).lower(), m.group(2), m.group(3)
                if "\\noselect" in flags:
                    continue
                name = name.strip('"')
                decoded = imap_utf7_decode(name)
                special = None
                for f in flags.split():
                    if f in SPECIAL_USE:
                        special = SPECIAL_USE[f]
                        break
                base = decoded.split("/")[-1].split(".")[-1].split(delim)[-1] if delim in decoded else decoded
                if special is None:
                    low = decoded.lower()
                    for spec, names in REMOTE_FALLBACK.items():
                        for cand in names:
                            if low == cand.lower() or base.lower() == cand.lower():
                                special = spec
                                break
                        if special:
                            break
                if special == "inbox" or decoded.upper() == "INBOX":
                    special = "inbox"
                if special and special in seen_special:
                    special = None  # duplicado: dejalo como carpeta normal
                display = dict(FOLDER_DEFS).get(special, base) if special else decoded
                if special:
                    seen_special[special] = name
                self.db.run("""INSERT INTO folders(account_id,name,remote,special) VALUES(?,?,?,?)
                               ON CONFLICT(account_id,remote) DO UPDATE SET name=excluded.name, special=excluded.special""",
                            (account.id, display, name, special))
        finally:
            if own:
                try:
                    im.logout()
                except Exception:
                    pass

    def ensure_folder_remote(self, account, special, create=False):
        f = self.db.folder_by_special(account.id, special)
        if f:
            return f["remote"]
        for cand in REMOTE_FALLBACK.get(special, []):
            f2 = self.db.one("SELECT remote FROM folders WHERE account_id=? AND remote=?", (account.id, cand))
            if f2:
                return f2["remote"]
        if create:
            name = REMOTE_CREATE.get(special)
            if name:
                im = self._imap_connect(account)
                try:
                    typ, _ = im.create(name)
                except Exception:
                    typ = "NO"
                finally:
                    try:
                        im.logout()
                    except Exception:
                        pass
                if typ == "OK":
                    disp = dict(FOLDER_DEFS).get(special, name)
                    self.db.run("INSERT INTO folders(account_id,name,remote,special) VALUES(?,?,?,?)",
                                (account.id, disp, name, special))
                    return name
        return None

    # ---- sincronizacion de mensajes ----
    def _fetch_envelopes(self, im, uids):
        """FETCH de sobres en lotes de 50. Si un lote falla se bisecciona para
        aislar el mensaje que rompe al servidor (un FETCH con NO/BAD no debe
        impedir que entre el resto del correo nuevo); el UID rebelde se
        reintenta con datos minimos y, si ni asi, se devuelve None para ese UID
        (la app inserta un marcador y el buzon no se queda atascado)."""
        out = {}
        cola = [uids[i:i + 50] for i in range(0, len(uids), 50)]
        while cola:
            chunk = cola.pop(0)
            try:
                typ, data = im.uid("FETCH", ",".join(str(u) for u in chunk), FETCH_ITEMS)
            except Exception:
                typ, data = "EXC", None
            if typ != "OK":
                if len(chunk) > 1:
                    mitad = len(chunk) // 2
                    cola.insert(0, chunk[mitad:])
                    cola.insert(0, chunk[:mitad])
                    log("FETCH falla para %d UIDs; biseccion" % len(chunk))
                    continue
                uid = chunk[0]
                log("FETCH falla para UID %s; reintento con datos minimos" % uid)
                try:
                    typ, data = im.uid("FETCH", str(uid), FETCH_ITEMS_MIN)
                except Exception:
                    typ, data = "EXC", None
                if typ != "OK":
                    log("FETCH minimo falla para UID %s; marcador de posicion" % uid)
                    out[uid] = None
                    continue
            for info in _iter_fetch_responses(data):
                m = re.search(r"\bUID (\d+)", info)
                if m:
                    out[int(m.group(1))] = info
        return out

    def sync_folder(self, account, folder, _im=None):
        im = _im or self._imap_connect(account)
        own = _im is None
        new_count = 0
        self.db.batch_begin()
        try:
            typ, _ = im.select('"%s"' % folder["remote"].replace('"', '\\"'), readonly=False)
            if typ != "OK":
                return 0
            typ, data = im.uid("SEARCH", None, "ALL")
            if typ != "OK":
                return 0
            remote_uids = set(int(u) for u in data[0].split()) if data and data[0] else set()
            local = {r["uid"]: r["id"] for r in self.db.q(
                "SELECT id,uid FROM messages WHERE folder_id=?", (folder["id"],))}
            for gone in set(local) - remote_uids:
                self.db.run("DELETE FROM attachments WHERE message_id=?", (local[gone],))
                self.db.run("DELETE FROM messages WHERE id=?", (local[gone],))
            missing = sorted(remote_uids - set(local))
            batch = missing[-150:]
            if batch:
                fetched = self._fetch_envelopes(im, batch)
                known_flags = {}
                for uid in batch:
                    info = fetched.get(uid)
                    if info is None:
                        # el servidor no entrega este mensaje: marcador para que
                        # no bloquee la entrada del resto del correo nuevo
                        known_flags[uid] = (0, time.time(), "(mensaje no disponible)",
                                            "", "", "", "", "", 0)
                        continue
                    fl = re.search(r"FLAGS \(([^)]*)\)", info)
                    flags = 0
                    if fl:
                        if "\\Seen" in fl.group(1):
                            flags |= FLAG_READ
                        if "\\Flagged" in fl.group(1):
                            flags |= FLAG_FLAGGED
                        if "\\Answered" in fl.group(1):
                            flags |= FLAG_ANSWERED
                    dm = re.search(r'INTERNALDATE "([^"]+)"', info)
                    ts = time.time()
                    if dm:
                        try:
                            ts = email.utils.mktime_tz(email.utils.parsedate_tz(dm.group(1)))
                        except Exception:
                            pass
                    env_m = re.search(r"ENVELOPE \((.*?)\)\s+BODYSTRUCTURE", info)
                    if not env_m:
                        env_m = re.search(r"ENVELOPE \((.*)\)\s*$", info)
                    has_att = 0
                    bs_m = re.search(r"BODYSTRUCTURE \((.*)\)\s*$", info)
                    if bs_m:
                        bs = bs_m.group(1).lower()
                        if '"attachment"' in bs or re.search(r'"(?:name|filename)" "[^"]+"', bs):
                            has_att = 1
                    subject = from_name = from_addr = msgid = ""
                    to_s = cc_s = ""
                    if env_m:
                        env = _parse_envelope(env_m.group(1))
                        if env:
                            subject = decode_header_value(env[0])
                            msgid = env[9] if len(env) > 9 else ""
                            fl_from = env[2] if len(env) > 2 else []
                            if fl_from:
                                nm, ad = fl_from[0]
                                from_name, from_addr = decode_header_value(nm), ad
                            to_s = ", ".join(a for _, a in (env[5] if len(env) > 5 else []) if a)
                            cc_s = ", ".join(a for _, a in (env[6] if len(env) > 6 else []) if a)
                    known_flags[uid] = (flags, ts, subject, from_name, from_addr,
                                        to_s, cc_s, msgid, has_att)

                junk = self.db.folder_by_special(account.id, "junk")
                moved_blocked = []
                for uid, (flags, ts, subject, from_name, from_addr, to_s, cc_s, msgid, has_att) in known_flags.items():
                    if (folder["special"] == "inbox" and junk and
                            self.db.is_blocked(account.id, from_addr)):
                        # remitente bloqueado: a correo no deseado, tambien en el servidor
                        try:
                            im.uid("COPY", str(uid), '"%s"' % junk["remote"].replace('"', '\\"'))
                            im.uid("STORE", str(uid), "+FLAGS", "(\\Deleted)")
                            moved_blocked.append(uid)
                        except Exception:
                            pass
                        self.db.run("""INSERT OR REPLACE INTO messages(account_id,folder_id,uid,msgid,ts,from_name,from_addr,
                                       to_addrs,cc_addrs,subject,preview,flags,has_attach) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                                    (account.id, junk["id"], uid, msgid, ts, from_name, from_addr,
                                     to_s, cc_s, subject, "", flags, has_att))
                        continue
                    existing = self.db.one("SELECT id,flags FROM messages WHERE folder_id=? AND uid=?",
                                           (folder["id"], uid))
                    if existing:
                        self.db.run("UPDATE messages SET flags=?, has_attach=MAX(has_attach,?) WHERE id=?",
                                    (flags, has_att, existing["id"]))
                    else:
                        self.db.run("""INSERT INTO messages(account_id,folder_id,uid,msgid,ts,from_name,from_addr,
                                       to_addrs,cc_addrs,subject,preview,flags,has_attach) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                                    (account.id, folder["id"], uid, msgid, ts, from_name, from_addr,
                                     to_s, cc_s, subject, "", flags, has_att))
                        if not (flags & FLAG_READ):
                            new_count += 1
            # refresco de flags de los que ya estaban: leido/destacado en otros
            # clientes debe reflejarse aqui (delta por UID, sin bajar sobres)
            keep = sorted(set(local) & remote_uids)
            cola = [keep[off:off + 500] for off in range(0, len(keep), 500)]
            while cola:
                chunk = cola.pop(0)
                try:
                    typ, fdata = im.uid("FETCH", ",".join(str(u) for u in chunk), "(FLAGS)")
                except Exception:
                    typ, fdata = "EXC", None
                if typ != "OK" or not fdata:
                    if len(chunk) > 1:
                        mitad = len(chunk) // 2
                        cola.insert(0, chunk[mitad:])
                        cola.insert(0, chunk[:mitad])
                    else:
                        log("FLAGS falla para UID %s; se conserva su estado local" % chunk[0])
                    continue
                for info in _iter_fetch_responses(fdata):
                    uid_m = re.search(r"\bUID (\d+)", info)
                    fl = re.search(r"FLAGS \(([^)]*)\)", info)
                    if not uid_m or not fl:
                        continue
                    uid = int(uid_m.group(1))
                    sflags = 0
                    if "\\Seen" in fl.group(1):
                        sflags |= FLAG_READ
                    if "\\Flagged" in fl.group(1):
                        sflags |= FLAG_FLAGGED
                    if "\\Answered" in fl.group(1):
                        sflags |= FLAG_ANSWERED
                    self.db.run("UPDATE messages SET flags=? WHERE folder_id=? AND uid=? AND flags!=?",
                                (sflags, folder["id"], uid, sflags))
                try:
                    im.expunge()
                except Exception:
                    pass
                self.db.run("UPDATE folders SET last_uid=? WHERE id=?",
                            (max(remote_uids) if remote_uids else 0, folder["id"]))
            unseen = self.db.one("SELECT COUNT(*) c FROM messages WHERE folder_id=? AND (flags & 1)=0",
                                 (folder["id"],))["c"]
            self.db.run("UPDATE folders SET unseen=? WHERE id=?", (unseen, folder["id"]))
        finally:
            self.db.batch_end()
            if own:
                try:
                    im.close()
                    im.logout()
                except Exception:
                    pass
        return new_count

    def sync_account(self, account, only_inbox=False):
        log("SINCRONIZAR %s (%s)" % (account.email, account.provider))
        try:
            im = self._imap_connect(account)
            try:
                self.sync_folders(account, _im=im)
                folders = self.db.folders(account.id)
                total_new = 0
                for f in folders:
                    if only_inbox and f["special"] != "inbox":
                        continue
                    total_new += self.sync_folder(account, f, _im=im)
                # precarga de los cuerpos recientes de la bandeja (en segundo
                # plano, misma conexion): abrir un mensaje es instantaneo
                try:
                    inbox = self.db.folder_by_special(account.id, "inbox")
                    if inbox:
                        pend = self.db.q("""SELECT id,uid,size FROM messages WHERE folder_id=?
                                            AND body_text IS NULL AND body_html IS NULL
                                            AND COALESCE(size,0) < 3000000
                                            ORDER BY ts DESC LIMIT 12""", (inbox["id"],))
                        if pend:
                            im.select('"%s"' % inbox["remote"].replace('"', '\\"'), readonly=False)
                            for r in pend:
                                try:
                                    typ, data = im.uid("FETCH", str(r["uid"]), "(BODY.PEEK[])")
                                    if typ == "OK" and data and isinstance(data[0], tuple):
                                        self._store_body(account, inbox, r, data[0][1])
                                except Exception:
                                    break
                except Exception:
                    pass
            finally:
                try:
                    im.logout()
                except Exception:
                    pass
            self.db.run("UPDATE accounts SET state='ok' WHERE id=?", (account.id,))
            log("OK %s: %d carpetas, %d nuevos" % (account.email, len(folders), total_new))
            if total_new and self.on_new_mail:
                self.on_new_mail(account, total_new)
            return True
        except oauth_flow.OAuthError as e:
            self.db.run("UPDATE accounts SET state='login' WHERE id=?", (account.id,))
            self.last_errors[account.id] = str(e)
            log("ERROR-LOGIN %s: %s" % (account.email, e))
            if self.on_error:
                self.on_error(account, str(e))
            return False
        except Exception as e:
            self.db.run("UPDATE accounts SET state='error' WHERE id=?", (account.id,))
            self.last_errors[account.id] = str(e)
            log("ERROR %s: %s: %s" % (account.email, type(e).__name__, e))
            if self.on_error:
                self.on_error(account, str(e))
            return False

    # ---- mensaje completo ----
    def _store_body(self, account, folder, msg_row, raw):
        msg = email.message_from_bytes(raw, policy=email.policy.compat32)
        text, body_html, atts = extract_bodies(msg)
        has_att = 1 if atts else 0
        # imagenes en linea (cid:): se incrustan como data: URI si son pequenas;
        # contenido local, sin red, se ven como en Thunderbird
        if body_html and "cid:" in body_html:
            cid_map = {}
            for part in msg.walk():
                if part.is_multipart():
                    continue
                cid = (part.get("Content-ID") or "").strip().strip("<>")
                ctype = part.get_content_type()
                if cid and ctype.startswith("image/"):
                    try:
                        payload = part.get_payload(decode=True) or b""
                    except Exception:
                        continue
                    if 0 < len(payload) <= 300 * 1024:
                        cid_map[cid] = "data:%s;base64,%s" % (
                            ctype, base64.b64encode(payload).decode())
            if cid_map:
                body_html = re.sub(r'cid:([^"\'>\s)]+)',
                                   lambda mo: cid_map.get(mo.group(1), mo.group(0)), body_html)
        self.db.run("""UPDATE messages SET body_text=?, body_html=?, has_attach=?, preview=?,
                       from_name=COALESCE(NULLIF(from_name,''),?), from_addr=COALESCE(NULLIF(from_addr,''),?),
                       subject=CASE WHEN subject='' OR subject='(mensaje no disponible)' THEN ? ELSE subject END
                       WHERE id=?""",
                    (text, body_html, has_att, make_preview(text),
                     decode_header_value(msg.get("From", "")) and parse_address_list(msg.get("From"))[0][0] if parse_address_list(msg.get("From")) else "",
                     parse_address_list(msg.get("From"))[0][1] if parse_address_list(msg.get("From")) else "",
                     decode_header_value(msg.get("Subject", "")), msg_row["id"]))
        self.db.run("DELETE FROM attachments WHERE message_id=?", (msg_row["id"],))
        for fn, mime, size, pidx in atts:
            self.db.run("INSERT INTO attachments(message_id,filename,mime,size,part_index) VALUES(?,?,?,?,?)",
                        (msg_row["id"], fn, mime, size, pidx))

    def fetch_message(self, account, folder, msg_row):
        for attempt in (0, 1):
            try:
                with self._reader_session(account, folder["remote"]) as im:
                    typ, data = im.uid("FETCH", str(msg_row["uid"]), "(BODY.PEEK[])")
                    if typ != "OK" or not data or not isinstance(data[0], tuple):
                        return None
                    self._store_body(account, folder, msg_row, data[0][1])
                    self.set_flags(account, folder, msg_row["uid"], add=["\\Seen"], _im=im)
                    self.db.run("UPDATE messages SET flags=flags|1 WHERE id=?", (msg_row["id"],))
                    unseen = self.db.one("SELECT COUNT(*) c FROM messages WHERE folder_id=? AND (flags & 1)=0",
                                         (folder["id"],))["c"]
                    self.db.run("UPDATE folders SET unseen=? WHERE id=?", (unseen, folder["id"]))
                    return self.db.one("SELECT * FROM messages WHERE id=?", (msg_row["id"],))
            except imaplib.IMAP4.abort:
                if attempt:
                    raise
        return None

    def download_attachment(self, account, folder, msg_row, att_row):
        with self._reader_session(account, folder["remote"]) as im:
            typ, data = im.uid("FETCH", str(msg_row["uid"]), "(BODY.PEEK[])")
            if typ != "OK" or not data or not isinstance(data[0], tuple):
                return None
            msg = email.message_from_bytes(data[0][1], policy=email.policy.compat32)
            idx = 0
            for part in msg.walk():
                if part.is_multipart():
                    continue
                ctype = part.get_content_type()
                disp = (part.get("Content-Disposition") or "").lower()
                filename = part.get_filename()
                is_att = "attachment" in disp or (filename and ctype not in ("text/plain", "text/html"))
                if is_att:
                    idx += 1
                    if idx == att_row["part_index"]:
                        payload = part.get_payload(decode=True) or b""
                        safe = re.sub(r"[^\w.\- ()]", "_", att_row["filename"])[:120]
                        dest = os.path.join(ATT_DIR, "%d-%d-%s" % (msg_row["id"], idx, safe))
                        with open(dest, "wb") as f:
                            f.write(payload)
                        self.db.run("UPDATE attachments SET path=? WHERE id=?", (dest, att_row["id"]))
                        return dest
            return None

    # ---- acciones ----
    def set_flags(self, account, folder, uid, add=None, remove=None, _im=None):
        im = _im or self._imap_connect(account)
        own = _im is None
        try:
            if own:
                im.select('"%s"' % folder["remote"].replace('"', '\\"'), readonly=False)
            if add:
                im.uid("STORE", str(uid), "+FLAGS", "(%s)" % " ".join(add))
            if remove:
                im.uid("STORE", str(uid), "-FLAGS", "(%s)" % " ".join(remove))
        finally:
            if own:
                try:
                    im.close()
                    im.logout()
                except Exception:
                    pass

    def move_message(self, account, folder, uid, dest_remote):
        im = self._imap_connect(account)
        try:
            im.select('"%s"' % folder["remote"].replace('"', '\\"'), readonly=False)
            typ, _ = im.uid("COPY", str(uid), '"%s"' % dest_remote.replace('"', '\\"'))
            if typ != "OK":
                raise RuntimeError("el servidor rechazó la copia a la carpeta de destino")
            im.uid("STORE", str(uid), "+FLAGS", "(\\Deleted)")
            im.expunge()
        finally:
            try:
                im.close()
                im.logout()
            except Exception:
                pass

    @staticmethod
    def _expand_uidset(s):
        out = []
        for part in (s or "").split(","):
            part = part.strip()
            if not part:
                continue
            if ":" in part:
                a, b = part.split(":", 1)
                out.extend(str(i) for i in range(int(a), int(b) + 1))
            else:
                out.append(part)
        return out

    def _preserve_seen_on_copy(self, im, trash, origin_remote, msg_rows):
        """Tras UID COPY, re-aplica \Seen en el destino si el servidor da COPYUID (UIDPLUS).
        Vuelve a seleccionar la carpeta de origen al terminar."""
        try:
            cu = im.untagged_responses.get("COPYUID")
            if not cu:
                return
            last = cu[-1]
            last = last.decode() if isinstance(last, bytes) else str(last)
            m0 = re.match(r"\s*(\d+)\s+(\S+)\s+(\S+)", last)
            if not m0:
                return
            src = self._expand_uidset(m0.group(2))
            dst = self._expand_uidset(m0.group(3))
            if not src or len(src) != len(dst):
                return
            seen = {str(m["uid"]) for m in msg_rows if m and m["uid"] and (m["flags"] & 1)}
            dst_seen = [d for s, d in zip(src, dst) if s in seen]
            if not dst_seen:
                return
            im.select('"%s"' % trash.replace('"', '\\"'), readonly=False)
            im.uid("STORE", ",".join(dst_seen), "+FLAGS.SILENT", "(\\Seen)")
            im.select('"%s"' % origin_remote.replace('"', '\\"'), readonly=False)
        except Exception:
            try:
                im.select('"%s"' % origin_remote.replace('"', '\\"'), readonly=False)
            except Exception:
                pass

    def delete_messages_remote(self, account, folder, msg_rows, permanent=False):
        """Borrado/movido en lote: una sola conexion y un solo expunge."""
        uids = [str(m["uid"]) for m in msg_rows if m and m["uid"]]
        if not uids:
            return
        trash = self.ensure_folder_remote(account, "trash", create=True)
        im = self._imap_connect(account)
        try:
            im.select('"%s"' % folder["remote"].replace('"', '\\"'), readonly=False)
            uidset = ",".join(uids)
            if permanent or folder["special"] == "trash" or not trash:
                im.uid("STORE", uidset, "+FLAGS", "(\\Deleted)")
            else:
                typ, _ = im.uid("COPY", uidset, '"%s"' % trash.replace('"', '\\"'))
                if typ != "OK":
                    raise RuntimeError("el servidor rechazó la copia a la carpeta de destino")
                self._preserve_seen_on_copy(im, trash, folder["remote"], msg_rows)
                im.uid("STORE", uidset, "+FLAGS", "(\\Deleted)")
            im.expunge()
        finally:
            try:
                im.close()
                im.logout()
            except Exception:
                pass

    def delete_message_remote(self, account, folder, msg_row, permanent=False):
        """Solo la parte de red; el borrado local ya se hizo (borrado optimista)."""
        trash = self.ensure_folder_remote(account, "trash", create=True)
        if permanent or folder["special"] == "trash" or not trash:
            im = self._imap_connect(account)
            try:
                im.select('"%s"' % folder["remote"].replace('"', '\\"'), readonly=False)
                im.uid("STORE", str(msg_row["uid"]), "+FLAGS", "(\\Deleted)")
                im.expunge()
            finally:
                try:
                    im.close()
                    im.logout()
                except Exception:
                    pass
        else:
            self.move_message(account, folder, msg_row["uid"], trash)

    def delete_message(self, account, folder, msg_row, permanent=False):
        trash = self.ensure_folder_remote(account, "trash", create=True)
        if permanent or folder["special"] == "trash" or not trash:
            im = self._imap_connect(account)
            try:
                im.select('"%s"' % folder["remote"].replace('"', '\\"'), readonly=False)
                im.uid("STORE", str(msg_row["uid"]), "+FLAGS", "(\\Deleted)")
                im.expunge()
            finally:
                try:
                    im.close()
                    im.logout()
                except Exception:
                    pass
        else:
            self.move_message(account, folder, msg_row["uid"], trash)
        self.db.run("DELETE FROM attachments WHERE message_id=?", (msg_row["id"],))
        self.db.run("DELETE FROM messages WHERE id=?", (msg_row["id"],))

    def archive_message(self, account, folder, msg_row):
        arch = self.ensure_folder_remote(account, "archive", create=True)
        if not arch:
            raise RuntimeError("esta cuenta no tiene carpeta de archivo")
        if arch:
            self.move_message(account, folder, msg_row["uid"], arch)
            self.db.run("DELETE FROM messages WHERE id=?", (msg_row["id"],))

    def save_draft(self, account, raw_mime):
        drafts = self.ensure_folder_remote(account, "drafts")
        if not drafts:
            return False
        im = self._imap_connect(account)
        try:
            im.append('"%s"' % drafts.replace('"', '\\"'), "(\\Seen \\Draft)", None, raw_mime)
            return True
        finally:
            try:
                im.logout()
            except Exception:
                pass

    def send_message(self, account, msg):
        sm = self._smtp_connect(account)
        try:
            sm.send_message(msg)
        finally:
            try:
                sm.quit()
            except Exception:
                pass
        sent = self.ensure_folder_remote(account, "sent")
        if sent:
            try:
                im = self._imap_connect(account)
                try:
                    im.append('"%s"' % sent.replace('"', '\\"'), "(\\Seen)", None, msg.as_bytes())
                finally:
                    try:
                        im.logout()
                    except Exception:
                        pass
            except Exception:
                pass

def _parse_envelope(s):
    """Analizador minimo de ENVELOPE (lista IMAP parentizada)."""
    toks = []
    i, n = 0, len(s)
    def parse(i):
        items = []
        while i < n:
            ch = s[i]
            if ch == "(":
                sub, i = parse(i + 1)
                items.append(sub)
            elif ch == ")":
                return items, i + 1
            elif ch == '"':
                j = i + 1
                buf = []
                while j < n:
                    if s[j] == "\\" and j + 1 < n:
                        buf.append(s[j + 1])
                        j += 2
                    elif s[j] == '"':
                        break
                    else:
                        buf.append(s[j])
                        j += 1
                items.append("".join(buf))
                i = j + 1
            elif ch == " ":
                i += 1
            else:
                j = i
                while j < n and s[j] not in " ()":
                    j += 1
                tok = s[i:j]
                items.append(None if tok.upper() == "NIL" else tok)
                i = j
        return items, i
    try:
        items, _ = parse(0)
        # [date, subject, from, sender, reply-to, to, cc, bcc, in-reply-to, message-id]
        def addrs(v):
            out = []
            if isinstance(v, list):
                for a in v:
                    if isinstance(a, list) and len(a) >= 4:
                        name = a[0] or ""
                        mailbox, host = a[2] or "", a[3] or ""
                        addr = (mailbox + "@" + host) if mailbox and host else ""
                        out.append((name, addr))
            return out
        return [items[1] or "", items[0] or "", addrs(items[2]) if len(items) > 2 else [],
                addrs(items[3]) if len(items) > 3 else [], addrs(items[4]) if len(items) > 4 else [],
                addrs(items[5]) if len(items) > 5 else [], addrs(items[6]) if len(items) > 6 else [],
                addrs(items[7]) if len(items) > 7 else [], items[8] if len(items) > 8 else "",
                items[9] if len(items) > 9 else ""]
    except Exception:
        return None
