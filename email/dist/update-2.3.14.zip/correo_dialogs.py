# -*- coding: utf-8 -*-
"""Ventanas y dialogos: redactar, agregar cuenta (OAuth2/contraseña de aplicacion), configuracion."""
import json, os, re, subprocess, threading, time
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, Pango

import oauth_flow, mail_sync, htmlview
from correo_ui_base import icon_image, avatar_widget, ACCENT, TEXT_DIM

def human_size(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n / 1.0, unit))
        n /= 1024.0
    return "%d B" % n

# ---------------- redactar ----------------
class ComposeWindow(Gtk.Window):
    def __init__(self, app, backend, db, account, reply_to=None, reply_all=False, forward=False,
                 draft=None, on_sent=None):
        Gtk.Window.__init__(self, title="Mensaje nuevo")
        self.set_default_size(720, 560)
        self.app = app
        self.backend = backend
        self.db = db
        self.account = account
        self.on_sent = on_sent
        self.attachments = []
        self._dirty = False
        self.msg = draft
        self._draft_origin = draft
        self._reply_msgid = (reply_to["msgid"] or "") if reply_to else ""
        self._draft_folder = None
        if draft is not None:
            self._draft_folder = db.one("SELECT * FROM folders WHERE id=?", (draft["folder_id"],))

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(outer)

        hb = Gtk.HeaderBar(title="Mensaje nuevo")
        hb.set_show_close_button(True)
        self.set_titlebar(hb)

        # barra de acciones, a la izquierda como la barra principal
        cmd = Gtk.Box(spacing=2)
        cmd.get_style_context().add_class("command-bar")
        cmd.get_style_context().add_class("compose-bar")
        self.send_btn = Gtk.Button(label="Enviar")
        self.send_btn.set_image(icon_image("send", 12, "#FFFFFF", 0.75))
        self.send_btn.set_always_show_image(True)
        self.send_btn.get_style_context().add_class("send-btn")
        self.send_btn.connect("clicked", self.on_send)
        cmd.pack_start(self.send_btn, False, False, 0)
        draft_btn = Gtk.Button(label="Guardar borrador")
        draft_btn.set_image(icon_image("save", 12, "#323130", 0.75))
        draft_btn.set_always_show_image(True)
        draft_btn.get_style_context().add_class("cmd-btn")
        draft_btn.connect("clicked", self.on_save_draft)
        cmd.pack_start(draft_btn, False, False, 0)
        discard = Gtk.Button(label="Descartar")
        discard.set_image(icon_image("trash", 12, "#323130", 0.75))
        discard.set_always_show_image(True)
        discard.get_style_context().add_class("cmd-btn")
        discard.connect("clicked", self.on_discard)
        cmd.pack_start(discard, False, False, 0)
        sep = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        sep.get_style_context().add_class("cmd-sep")
        cmd.pack_start(sep, False, False, 4)
        outer.pack_start(cmd, False, False, 0)

        fields = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        fields.set_margin_start(14)
        fields.set_margin_end(14)
        fields.set_margin_top(4)
        outer.pack_start(fields, False, False, 0)

        from_row = Gtk.Box(spacing=10)
        from_row.set_margin_top(4)
        from_row.set_margin_bottom(4)
        from_lbl = self._field_label("De:")
        from_val = Gtk.Label(label=account.email)
        from_val.set_xalign(0)

        from_val.get_style_context().add_class("reader-addr")
        from_row.pack_start(from_lbl, False, False, 0)
        from_row.pack_start(from_val, False, False, 0)
        fields.pack_start(from_row, False, False, 0)
        fields.pack_start(Gtk.Separator(), False, False, 0)
        rowsg = Gtk.SizeGroup(mode=Gtk.SizeGroupMode.VERTICAL)
        rowsg.add_widget(from_row)

        self._to_row, self.to_entry = self._field(fields, "Para:")
        rowsg.add_widget(self._to_row)
        self.cc_btn = Gtk.Button(label="Cc")
        self.cc_btn.get_style_context().add_class("tool-btn")
        self.cc_btn.connect("clicked", self._toggle_cc)
        self._to_row.pack_end(self.cc_btn, False, False, 0)
        fields.pack_start(Gtk.Separator(), False, False, 0)
        self.cc_row, self.cc_entry = self._field(fields, "Cc:", pack=False)
        self._subj_row, self.subject_entry = self._field(fields, "Asunto:", entry_cls="compose-field")
        rowsg.add_widget(self.cc_row)
        rowsg.add_widget(self._subj_row)
        self._setup_completion(self.to_entry)
        self._setup_completion(self.cc_entry)

        tb = Gtk.Box(spacing=2)
        tb.set_margin_start(10)
        tb.set_margin_end(10)
        tb.get_style_context().add_class("compose-bar")
        outer.pack_start(tb, False, False, 0)
        for name, label, tag in (("B", "b", "b"), ("I", "i", "i"), ("U", "u", "u")):
            b = Gtk.ToggleButton(label=name)
            b.get_style_context().add_class("tool-btn")
            b.set_size_request(30, 24)
            b.connect("toggled", self.on_fmt_toggled, tag)
            tb.pack_start(b, False, False, 0)
        bullet = Gtk.Button(label="• Lista")
        bullet.get_style_context().add_class("tool-btn")
        bullet.connect("clicked", self.on_bullet)
        tb.pack_start(bullet, False, False, 0)
        link = Gtk.Button(label="Vínculo")
        link.get_style_context().add_class("tool-btn")
        link.connect("clicked", self.on_link)
        tb.pack_start(link, False, False, 0)
        att = Gtk.Button()
        att.add(icon_image("clip", 12, "#323130", 0.75))
        att.get_style_context().add_class("tool-btn")
        att.set_tooltip_text("Adjuntar archivo")
        att.connect("clicked", self.on_attach)
        tb.pack_start(att, False, False, 0)

        self.att_box = Gtk.Box(spacing=6)
        self.att_box.set_margin_start(14)
        self.att_box.set_margin_end(14)
        outer.pack_start(self.att_box, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        scroll.set_vexpand(True)
        self.body = Gtk.TextView()
        self.body.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.body.set_margin_start(18)
        self.body.set_margin_end(18)
        self.body.set_margin_top(10)
        self.body.get_style_context().add_class("body-view")
        buf = self.body.get_buffer()
        buf.create_tag("b", weight=Pango.Weight.BOLD)
        buf.create_tag("i", style=Pango.Style.ITALIC)
        buf.create_tag("u", underline=Pango.Underline.SINGLE)
        scroll.add(self.body)
        outer.pack_start(scroll, True, True, 0)

        self.status = Gtk.Label(label="")
        self.status.get_style_context().add_class("status-label")
        self.status.set_xalign(0)
        outer.pack_end(self.status, False, False, 0)

        if reply_to is not None:
            self._prefill_reply(reply_to, reply_all, forward)
        elif draft is not None:
            self._prefill_draft(draft)
        self._dirty = False
        for e in (self.to_entry, self.cc_entry, self.subject_entry):
            e.connect("changed", lambda *_: setattr(self, "_dirty", True))
        self.body.get_buffer().connect("changed", lambda *_: setattr(self, "_dirty", True))
        self.show_all()
        self.cc_row.hide()

    def _field_label(self, text):
        lbl = Gtk.Label(label=text)
        lbl.get_style_context().add_class("reader-addr")
        lbl.set_size_request(64, -1)
        lbl.set_xalign(1)
        return lbl

    def _field(self, parent, label, pack=True, entry_cls="compose-field"):
        row = Gtk.Box(spacing=10)
        row.set_margin_top(4)
        row.set_margin_bottom(4)
        lbl = self._field_label(label)
        entry = Gtk.Entry()
        entry.get_style_context().add_class(entry_cls)
        if label == "Asunto:":
            entry.set_placeholder_text("Agregar un asunto")
        row.pack_start(lbl, False, False, 0)
        row.pack_start(entry, True, True, 0)
        if pack:
            parent.pack_start(row, False, False, 0)
        return row, entry

    # ----- autocompletado de destinatarios (historial local) -----
    def _setup_completion(self, entry):
        store = Gtk.ListStore(str)
        seen = set()
        own = {a.email.lower() for a in self.app.backend.db.accounts()} if hasattr(self.app, "backend") else set()
        def add(name, addr):
            addr = (addr or "").strip().strip("<>")
            if not addr or "@" not in addr or addr.lower() in own or addr.lower() in seen:
                return
            seen.add(addr.lower())
            label = ("%s <%s>" % (name, addr)) if (name or "").strip() else addr
            store.append([label])
        try:
            rows = self.db.q("SELECT from_name, from_addr, to_addrs, cc_addrs FROM messages "
                             "ORDER BY ts DESC LIMIT 1500")
            for r in rows:
                add(r["from_name"], r["from_addr"])
                for part in (r["to_addrs"] or "").split(","):
                    add("", part)
                for part in (r["cc_addrs"] or "").split(","):
                    add("", part)
                if len(seen) >= 600:
                    break
        except Exception:
            pass
        comp = Gtk.EntryCompletion()
        comp.set_model(store)
        comp.set_text_column(0)
        comp.set_minimum_key_length(1)
        comp.set_popup_set_width(True)
        def match_func(c, key, it, store=store):
            token = re.split(r"[,;]", key)[-1].strip().lower()
            return bool(token) and token in store[it][0].lower()
        comp.set_match_func(match_func)
        def on_match(c, model, it, entry=entry):
            text = entry.get_text()
            pos = entry.get_position()
            head = text[:pos]
            m = re.search(r"[^,;]*$", head)
            prefix = head[:pos - len(m.group(0))].rstrip()
            if prefix and prefix.endswith((",", ";")):
                prefix += " "
            value = model[it][0]
            entry.set_text(prefix + value + text[pos:])
            entry.set_position(len(prefix) + len(value))
            return True
        comp.connect("match-selected", on_match)
        entry.set_completion(comp)

    def _toggle_cc(self, btn):
        if self.cc_row.get_parent():
            self.cc_row.get_parent().remove(self.cc_row)
        else:
            parent = self._to_row.get_parent()
            children = parent.get_children()
            idx = children.index(self._to_row) + 1
            parent.pack_start(self.cc_row, False, False, 0)
            parent.reorder_child(self.cc_row, idx)
            self.cc_row.show_all()
            self.cc_entry.grab_focus()

    def _has_content(self):
        txt = self.body.get_buffer().get_text(self.body.get_buffer().get_start_iter(),
                                              self.body.get_buffer().get_end_iter(), False)
        return bool(txt.strip() or self.to_entry.get_text().strip()
                    or self.subject_entry.get_text().strip())

    def on_discard(self, btn):
        if self._dirty and self._has_content():
            dlg = Gtk.MessageDialog(transient_for=self, modal=True,
                                    message_type=Gtk.MessageType.QUESTION,
                                    buttons=Gtk.ButtonsType.NONE,
                                    text="¿Descartar este mensaje?")
            dlg.format_secondary_text("Lo que has escrito se perderá.")
            dlg.add_button("Seguir escribiendo", Gtk.ResponseType.CANCEL)
            dlg.add_button("Descartar", Gtk.ResponseType.YES)
            ok = dlg.run() == Gtk.ResponseType.YES
            dlg.destroy()
            if not ok:
                return
        self.destroy()

    def on_fmt_toggled(self, btn, tag):
        buf = self.body.get_buffer()
        sel = buf.get_selection_bounds()
        if sel:
            t = buf.get_tag_table().lookup(tag)
            if btn.get_active():
                buf.apply_tag(t, sel[0], sel[1])
            else:
                buf.remove_tag(t, sel[0], sel[1])

    def on_bullet(self, btn):
        buf = self.body.get_buffer()
        buf.insert_at_cursor("• ")

    def on_link(self, btn):
        d = Gtk.Dialog(title="Insertar vínculo", transient_for=self, modal=True)
        d.add_button("Cancelar", Gtk.ResponseType.CANCEL)
        d.add_button("Insertar", Gtk.ResponseType.OK)
        box = d.get_content_area()
        box.set_margin_start(18); box.set_margin_end(18); box.set_margin_top(14); box.set_margin_bottom(14)
        box.set_spacing(8)
        txt = Gtk.Entry(); txt.set_placeholder_text("Texto visible")
        url = Gtk.Entry(); url.set_placeholder_text("https://...")
        box.pack_start(txt, False, False, 0)
        box.pack_start(url, False, False, 0)
        d.show_all()
        if d.run() == Gtk.ResponseType.OK and url.get_text().strip():
            buf = self.body.get_buffer()
            tag = buf.create_tag(None, foreground="#0067b8", underline=Pango.Underline.SINGLE)
            tag._url = htmlview.strip_tracking(url.get_text().strip())
            buf.insert_with_tags(buf.get_iter_at_mark(buf.get_insert()),
                                 txt.get_text() or url.get_text(), tag)
        d.destroy()

    def on_attach(self, btn):
        d = Gtk.FileChooserNative.new("Adjuntar archivo", self, Gtk.FileChooserAction.OPEN, "Adjuntar", "Cancelar")
        d.set_select_multiple(True)
        if d.run() == Gtk.ResponseType.ACCEPT:
            for path in d.get_filenames():
                self.attachments.append(path)
                chip = Gtk.Box(spacing=4)
                chip.get_style_context().add_class("att-chip")
                chip.pack_start(icon_image("clip", 14), False, False, 0)
                nm = Gtk.Label(label=os.path.basename(path))
                nm.get_style_context().add_class("att-name")
                chip.pack_start(nm, False, False, 0)
                x = Gtk.Button()
                x.add(icon_image("close", 12, "#8A8886"))
                x.get_style_context().add_class("action-btn")
                x.connect("clicked", lambda b, p=path, c=chip: (self.attachments.remove(p), c.destroy()))
                chip.pack_start(x, False, False, 0)
                self.att_box.pack_start(chip, False, False, 0)
                chip.show_all()
        d.destroy()

    def _prefill_draft(self, m):
        self.to_entry.set_text(m["to_addrs"] or "")
        if (m["cc_addrs"] or "").strip():
            self.cc_entry.set_text(m["cc_addrs"])
            self._toggle_cc(None)
        subject = m["subject"] or ""
        self.subject_entry.set_text(subject)
        orig = m["body_text"] or mail_sync.html_to_text(m["body_html"] or "")
        self.body.get_buffer().set_text(orig)
        self.body.get_buffer().place_cursor(self.body.get_buffer().get_end_iter())
        self.set_title("Borrador")

    def _add_attachment_chip(self, path):
        import os as _os
        chip = Gtk.Box(spacing=6)
        chip.get_style_context().add_class("att-chip")
        lbl = Gtk.Label(label=_os.path.basename(path))
        lbl.get_style_context().add_class("att-name")
        chip.pack_start(lbl, False, False, 0)
        x = Gtk.Button(label="×")
        x.get_style_context().add_class("tool-btn")
        x.connect("clicked", lambda b, p=path, c=chip: (self.attachments.remove(p), c.destroy()))
        chip.pack_end(x, False, False, 0)
        self.att_box.pack_start(chip, False, False, 0)
        chip.show_all()

    def _prefill_reply(self, m, reply_all, forward):
        subject = m["subject"] or ""
        if forward:
            self.subject_entry.set_text(subject if subject.upper().startswith("RV:") else "RV: " + subject)
        else:
            self.subject_entry.set_text(subject if subject.upper().startswith("RE:") else "RE: " + subject)
            self.to_entry.set_text(m["from_addr"] or "")
            if reply_all:
                others = [a for a in re.split(r"\s*,\s*", (m["to_addrs"] or "") + "," + (m["cc_addrs"] or ""))
                          if a and a.lower() != self.account.email.lower()]
                if others:
                    self.cc_entry.set_text(", ".join(dict.fromkeys(others)))
                    self._toggle_cc(None)
        orig = m["body_text"] or mail_sync.html_to_text(m["body_html"] or "")
        when = time.strftime("%d/%m/%Y %H:%M", time.localtime(m["ts"] or time.time()))
        header = "\n\n________________________________\nDe: %s <%s>\nFecha: %s\nAsunto: %s\n\n" % (
            m["from_name"] or m["from_addr"], m["from_addr"], when, m["subject"] or "")
        self.body.get_buffer().set_text(header + orig)
        end = self.body.get_buffer().get_start_iter()
        self.body.get_buffer().place_cursor(end)
        if forward:
            atts = self.db.q("SELECT * FROM attachments WHERE message_id=?", (m["id"],))
            pend = []
            for a in atts:
                if a["path"] and os.path.exists(a["path"]):
                    self.attachments.append(a["path"])
                    self._add_attachment_chip(a["path"])
                else:
                    pend.append(a)
            for a in pend:
                def dl(att=a):
                    p = None
                    try:
                        folder = self.db.one("SELECT * FROM folders WHERE id=?", (m["folder_id"],))
                        p = self.backend.download_attachment(self.account, folder, m, att)
                    except Exception:
                        p = None
                    if p:
                        GLib.idle_add(self._fwd_attached, p)
                    else:
                        GLib.idle_add(self.status.set_text,
                                      "No se pudo adjuntar " + (att["filename"] or "un archivo"))
                threading.Thread(target=dl, daemon=True).start()

    def _fwd_attached(self, path):
        self.attachments.append(path)
        self._add_attachment_chip(path)

    def _build_html(self):
        buf = self.body.get_buffer()
        text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(), False)
        sig = (self.account.signature or "").strip()
        lines = text.split("\n")
        out = []
        in_list = False
        for line in lines:
            esc = line.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            if line.startswith("• "):
                if not in_list:
                    out.append("<ul>")
                    in_list = True
                out.append("<li>%s</li>" % esc[2:])
            else:
                if in_list:
                    out.append("</ul>")
                    in_list = False
                out.append(esc + "<br>")
        if in_list:
            out.append("</ul>")
        # aplicar b/i/u por rangos
        tagged = self._tagged_html()
        if tagged is not None:
            body_html = tagged
        else:
            body_html = "".join(out)
        if sig:
            sig_esc = sig.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            body_html += "<br>-- <br>%s" % sig_esc.replace("\n", "<br>")
        return "<div style=\"font-family:'Segoe UI',Calibri,Arial,sans-serif;font-size:14px\">%s</div>" % body_html

    def _tagged_html(self):
        buf = self.body.get_buffer()
        tags = [t for t in ("b", "i", "u")]
        it = buf.get_start_iter()
        parts = []
        in_list = False
        pending_nl = False
        link_open = None
        state = {"b": False, "i": False, "u": False}
        while True:
            ch = it.get_char()
            if not ch:
                break
            new = {t: it.has_tag(buf.get_tag_table().lookup(t)) for t in tags}
            cur_link = None
            for tag in it.get_tags():
                if getattr(tag, "_url", None):
                    cur_link = tag._url
            if cur_link != link_open:
                if link_open:
                    parts.append("</a>")
                if cur_link:
                    parts.append('<a href="%s">' % cur_link.replace("&", "&amp;").replace('"', "&quot;"))
                link_open = cur_link
            for t in tags:
                if new[t] and not state[t]:
                    parts.append("<%s>" % t)
                elif state[t] and not new[t]:
                    parts.append("</%s>" % t)
            state = new
            if ch == "\n":
                it2 = it.copy()
                has_next = it2.forward_char()
                nextch = it2.get_char() if has_next else ""
                if in_list:
                    parts.append("</li>")
                if nextch == "•":
                    pass  # sigue la lista
                else:
                    if in_list:
                        parts.append("</ul>")
                        in_list = False
                    parts.append("<br>")
            elif ch == "•" and it.get_offset() > 0 and buf.get_iter_at_offset(it.get_offset() - 1).get_char() == "\n":
                if not in_list:
                    parts.append("<ul>")
                    in_list = True
                parts.append("<li>• ")
            else:
                parts.append(ch.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
            if not it.forward_char():
                break
        if link_open:
            parts.append("</a>")
        if in_list:
            parts.append("</li></ul>")
        for t in reversed(tags):
            if state[t]:
                parts.append("</%s>" % t)
        return "".join(parts)

    def _build_message(self):
        from email.message import EmailMessage
        msg = EmailMessage()
        msg["From"] = self.account.email
        msg["To"] = self.to_entry.get_text().strip()
        cc = self.cc_entry.get_text().strip()
        if cc:
            msg["Cc"] = cc
        msg["Subject"] = self.subject_entry.get_text().strip()
        msg["Date"] = __import__("email.utils", fromlist=["formatdate"]).formatdate(localtime=True)
        domain = (self.account.email.split("@")[-1] or "localhost").strip() or "localhost"
        msg["Message-ID"] = "<%d.email@%s>" % (int(time.time() * 1000), domain)
        if self._reply_msgid:
            mid = self._reply_msgid
            if not mid.startswith("<"):
                mid = "<" + mid + ">"
            msg["In-Reply-To"] = mid
            msg["References"] = mid
        plain = self.body.get_buffer().get_text(self.body.get_buffer().get_start_iter(),
                                                self.body.get_buffer().get_end_iter(), False)
        sig = (self.account.signature or "").strip()
        if sig:
            plain += "\n-- \n" + sig
        msg.set_content(plain)
        msg.add_alternative(self._build_html(), subtype="html")
        for path in self.attachments:
            try:
                with open(path, "rb") as f:
                    data = f.read()
                import mimetypes
                ctype = mimetypes.guess_type(path)[0] or "application/octet-stream"
                main, sub = ctype.split("/", 1)
                msg.add_attachment(data, maintype=main, subtype=sub, filename=os.path.basename(path))
            except OSError:
                pass
        return msg

    def _recipients_ok(self):
        return bool(self.to_entry.get_text().strip()) and "@" in self.to_entry.get_text()

    def on_send(self, btn):
        if not self._recipients_ok():
            self.status.set_text("Escribe al menos un destinatario válido.")
            return
        self.status.set_text("Enviando…")
        btn.set_sensitive(False)
        msg = self._build_message()
        def work():
            err = None
            try:
                self.backend.send_message(self.account, msg)
            except Exception as e:
                err = str(e)
            GLib.idle_add(self._send_done, err)
        threading.Thread(target=work, daemon=True).start()

    def _send_done(self, err):
        if err:
            self.status.set_text("No se pudo enviar: " + err)
            self.send_btn.set_sensitive(True)
        else:
            if self._draft_origin is not None and self._draft_folder is not None:
                orig, folder = self._draft_origin, self._draft_folder
                def cleanup():
                    try:
                        self.backend.delete_message(self.account, folder, orig, permanent=True)
                    except Exception:
                        try:
                            self.db.run("DELETE FROM messages WHERE id=?", (orig["id"],))
                        except Exception:
                            pass
                threading.Thread(target=cleanup, daemon=True).start()
            if self.on_sent:
                self.on_sent()
            self.destroy()

    def on_save_draft(self, btn):
        msg = self._build_message()
        self.status.set_text("Guardando borrador…")
        def work():
            ok = False
            try:
                ok = self.backend.save_draft(self.account, msg.as_bytes())
            except Exception:
                ok = False
            GLib.idle_add(lambda: (self.status.set_text("Borrador guardado." if ok else
                                                        "No se pudo guardar el borrador."), False)[1])
        threading.Thread(target=work, daemon=True).start()

# ---------------- agregar cuenta ----------------
class AddAccountDialog(Gtk.Dialog):
    def __init__(self, parent, db, on_added):
        Gtk.Dialog.__init__(self, title="Agregar una cuenta", transient_for=parent, modal=True)
        self.set_default_size(440, -1)
        self.db = db
        self.on_added = on_added
        self.provider = None
        self.server = None
        self.verifier = None
        self.poll_id = None

        box = self.get_content_area()
        box.set_margin_start(22); box.set_margin_end(22)
        box.set_margin_top(18); box.set_margin_bottom(18)
        box.set_spacing(12)

        title = Gtk.Label(label="Agregar una cuenta")
        title.get_style_context().add_class("welcome-title")
        title.set_xalign(0)
        box.pack_start(title, False, False, 0)

        self.stack = Gtk.Stack()
        box.pack_start(self.stack, True, True, 0)

        # paso 1: proveedor
        p1 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        p1.set_margin_top(8)
        b_out = Gtk.Button(label="  Outlook.com / Hotmail")
        b_out.get_style_context().add_class("provider-btn")
        b_out.set_image(icon_image("envelope", 20, ACCENT))
        b_out.set_always_show_image(True)
        b_out.connect("clicked", lambda b: self._choose("outlook"))
        b_gm = Gtk.Button(label="  Gmail")
        b_gm.get_style_context().add_class("provider-btn")
        b_gm.set_image(icon_image("envelope", 20, "#D44638"))
        b_gm.set_always_show_image(True)
        b_gm.connect("clicked", lambda b: self._choose("gmail"))
        p1.pack_start(b_out, False, False, 0)
        p1.pack_start(b_gm, False, False, 0)
        note = Gtk.Label(label="El inicio de sesión se hace en la web oficial de Microsoft o Google. "
                               "Email no ve ni guarda tu contraseña.")
        note.set_line_wrap(True)
        note.set_xalign(0)
        note.get_style_context().add_class("welcome-sub")
        p1.pack_start(note, False, False, 0)
        self.stack.add_named(p1, "provider")

        # paso 2: email + login
        p2 = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        p2.set_margin_top(8)
        self.prov_lbl = Gtk.Label()
        self.prov_lbl.set_xalign(0)
        p2.pack_start(self.prov_lbl, False, False, 0)
        self.email_entry = Gtk.Entry()
        self.email_entry.set_placeholder_text("tu@direccion.com")
        self.email_entry.get_style_context().add_class("search-entry")
        p2.pack_start(self.email_entry, False, False, 0)
        self.login_btn = Gtk.Button(label="Iniciar sesión")
        self.login_btn.get_style_context().add_class("send-btn")
        self.login_btn.connect("clicked", self._start_oauth)
        p2.pack_start(self.login_btn, False, False, 0)
        self.gmail_alt = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        sep = Gtk.Label(label="— o, si lo prefieres —")
        sep.get_style_context().add_class("welcome-sub")
        self.gmail_alt.pack_start(sep, False, False, 0)
        self.apppass_entry = Gtk.Entry()
        self.apppass_entry.set_placeholder_text("Contraseña de aplicación de Google (16 letras)")
        self.apppass_entry.set_visibility(False)
        self.apppass_entry.get_style_context().add_class("search-entry")
        self.gmail_alt.pack_start(self.apppass_entry, False, False, 0)
        apppass_btn = Gtk.Button(label="Entrar con contraseña de aplicación")
        apppass_btn.get_style_context().add_class("action-btn")
        apppass_btn.connect("clicked", self._apppass_login)
        self.gmail_alt.pack_start(apppass_btn, False, False, 0)
        hint = Gtk.Label()
        hint.set_markup('<a href="https://myaccount.google.com/apppasswords">Crear una contraseña de aplicación en Google</a> '
                        '(requiere la verificación en dos pasos)')
        hint.set_xalign(0)
        hint.get_style_context().add_class("welcome-sub")
        self.gmail_alt.pack_start(hint, False, False, 0)
        p2.pack_start(self.gmail_alt, False, False, 0)
        self.wait_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        spin = Gtk.Spinner()
        spin.start()
        self.wait_box.pack_start(spin, False, False, 0)
        wl = Gtk.Label(label="Esperando la autorización en el navegador…")
        wl.set_line_wrap(True)
        self.wait_box.pack_start(wl, False, False, 0)
        self.wait_box.pack_start(Gtk.Label(label="Si el navegador muestra un error al final, copia la dirección "
                                                 "completa de la barra y pégala aquí:"), False, False, 0)
        self.paste_entry = Gtk.Entry()
        self.paste_entry.set_placeholder_text("http://localhost:…/?code=…")
        self.wait_box.pack_start(self.paste_entry, False, False, 0)
        paste_btn = Gtk.Button(label="Continuar con esta dirección")
        paste_btn.get_style_context().add_class("action-btn")
        paste_btn.connect("clicked", self._manual_code)
        self.wait_box.pack_start(paste_btn, False, False, 0)
        self.wait_box.set_no_show_all(True)
        p2.pack_start(self.wait_box, False, False, 0)
        self.err_lbl = Gtk.Label()
        self.err_lbl.get_style_context().add_class("error-bar-text")
        self.err_lbl.set_line_wrap(True)
        self.err_lbl.set_xalign(0)
        p2.pack_start(self.err_lbl, False, False, 0)
        self.stack.add_named(p2, "email")

        self.add_button("Cancelar", Gtk.ResponseType.CANCEL)
        self.connect("response", lambda d, r: d.destroy())
        self.show_all()
        self.gmail_alt.hide()

    def _choose(self, provider):
        self.provider = provider
        name = "Microsoft (Outlook.com / Hotmail)" if provider == "outlook" else "Google (Gmail)"
        self.prov_lbl.set_markup("<b>%s</b>" % name)
        self.login_btn.set_label("Iniciar sesión con %s" % ("Microsoft" if provider == "outlook" else "Google"))
        self.gmail_alt.set_visible(provider == "gmail")
        self.stack.set_visible_child_name("email")

    def _start_oauth(self, btn):
        email_addr = self.email_entry.get_text().strip()
        if "@" not in email_addr:
            self.err_lbl.set_text("Escribe tu dirección de correo.")
            return
        self.err_lbl.set_text("")
        self.server, url, self.verifier, self.state = oauth_flow.run_auth_flow(
            self.provider, email_addr, None)
        self.server.start()
        subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        self.wait_box.set_no_show_all(False)
        self.wait_box.show_all()
        self.poll_id = GLib.timeout_add(300, self._poll_server)

    def _poll_server(self):
        if self.server is None:
            return False
        if self.server.result is None:
            return True
        GLib.source_remove(self.poll_id)
        self.poll_id = None
        res = self.server.result
        if "error" in res and "code" not in res:
            self.wait_box.hide()
            self.err_lbl.set_text("No se pudo completar: " + res.get("error_description", res["error"]))
            return False
        code = res.get("code")
        self._exchange(code)
        return False

    def _manual_code(self, btn):
        pasted = self.paste_entry.get_text()
        if not pasted.strip():
            return
        def work():
            try:
                tokens = oauth_flow.complete_manual(self.provider, pasted, self.server.redirect_uri, self.verifier)
                GLib.idle_add(self._tokens_ok, tokens)
            except Exception as e:
                import mail_sync
                mail_sync.log("LOGIN ERROR %s: %s" % (self.provider, e))
                GLib.idle_add(lambda: self.err_lbl.set_text("No se pudo completar: " + str(e)))
        threading.Thread(target=work, daemon=True).start()

    def _exchange(self, code):
        def work():
            try:
                tokens = oauth_flow.exchange_code(self.provider, code, self.server.redirect_uri, self.verifier)
                GLib.idle_add(self._tokens_ok, tokens)
            except Exception as e:
                import mail_sync
                mail_sync.log("LOGIN ERROR %s: %s" % (self.provider, e))
                GLib.idle_add(lambda: (self.wait_box.hide(), self.err_lbl.set_text("Error: " + str(e))))
        threading.Thread(target=work, daemon=True).start()

    def _tokens_ok(self, tokens):
        email_addr = self.email_entry.get_text().strip()
        oauth_flow.token_store(email_addr, json.dumps(tokens))
        acc_id = self.db.add_account(self.provider, email_addr)
        import mail_sync
        mail_sync.log("LOGIN OK %s (%s)" % (email_addr, self.provider))
        self.on_added(acc_id)
        self.destroy()

    def _apppass_login(self, btn):
        email_addr = self.email_entry.get_text().strip()
        pw = self.apppass_entry.get_text().strip().replace(" ", "")
        if "@" not in email_addr or len(pw) != 16:
            self.err_lbl.set_text("Revisa la dirección y la contraseña de aplicación (16 letras).")
            return
        self.err_lbl.set_text("")
        btn.set_sensitive(False)
        def work():
            import imaplib, ssl
            err = None
            try:
                im = imaplib.IMAP4_SSL("imap.gmail.com", 993, ssl_context=ssl.create_default_context(), timeout=30)
                im.login(email_addr, pw)
                im.logout()
            except Exception as e:
                err = str(e)
            GLib.idle_add(lambda: self._apppass_done(email_addr, pw, err, btn))
        threading.Thread(target=work, daemon=True).start()

    def _apppass_done(self, email_addr, pw, err, btn):
        btn.set_sensitive(True)
        if err:
            self.err_lbl.set_text("Google rechazó el acceso: " + err)
            return
        oauth_flow.token_store(email_addr, json.dumps({"app_password": pw}))
        acc_id = self.db.add_account("gmailpass", email_addr)
        self.on_added(acc_id)
        self.destroy()

# ---------------- configuracion ----------------
class SettingsDialog(Gtk.Dialog):
    def __init__(self, parent, db, on_accounts_changed, on_check_updates):
        Gtk.Dialog.__init__(self, title="Configuración", transient_for=parent, modal=True)
        self.set_default_size(520, 480)
        self.db = db
        self.on_accounts_changed = on_accounts_changed
        self.on_check_updates = on_check_updates
        box = self.get_content_area()
        nb = Gtk.Notebook()
        nb.set_margin_start(14); nb.set_margin_end(14); nb.set_margin_top(12); nb.set_margin_bottom(8)
        box.pack_start(nb, True, True, 0)

        # cuentas
        acc_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        acc_box.set_margin_top(12); acc_box.set_margin_bottom(12)
        self.acc_list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        acc_box.pack_start(self.acc_list, False, False, 0)
        add_btn = Gtk.Button(label="+ Agregar una cuenta")
        add_btn.get_style_context().add_class("provider-btn")
        add_btn.connect("clicked", self._add_account)
        acc_box.pack_start(add_btn, False, False, 4)
        nb.append_page(acc_box, Gtk.Label(label="Cuentas"))

        # firma
        sig_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        sig_box.set_margin_top(12)
        self.sig_account = Gtk.ComboBoxText()
        sig_box.pack_start(self.sig_account, False, False, 0)
        self.sig_view = Gtk.TextView()
        self.sig_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        sig_scroll = Gtk.ScrolledWindow()
        sig_scroll.set_min_content_height(120)
        sig_scroll.add(self.sig_view)
        sig_box.pack_start(sig_scroll, False, False, 0)
        sig_save = Gtk.Button(label="Guardar firma")
        sig_save.get_style_context().add_class("provider-btn")
        sig_save.connect("clicked", self._save_signature)
        sig_box.pack_start(sig_save, False, False, 0)
        nb.append_page(sig_box, Gtk.Label(label="Firma"))

        # opciones
        opt_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        opt_box.set_margin_top(12)
        row = Gtk.Box(spacing=10)
        row.pack_start(Gtk.Label(label="Sincronizar cada (minutos):"), False, False, 0)
        self.sync_spin = Gtk.SpinButton.new_with_range(1, 30, 1)
        self.sync_spin.set_value(int(db.get_setting("sync_minutes", "2")))
        row.pack_start(self.sync_spin, False, False, 0)
        opt_box.pack_start(row, False, False, 0)
        self.sync_spin.connect("value-changed", lambda s: db.set_setting("sync_minutes", str(int(s.get_value()))))

        self.block_remote = Gtk.CheckButton(label="No cargar imágenes externas (máxima privacidad)")
        self.block_remote.set_active(db.get_setting("block_remote", "0") == "1")
        self.block_remote.connect("toggled", lambda b: db.set_setting("block_remote", "1" if b.get_active() else "0"))
        opt_box.pack_start(self.block_remote, False, False, 0)
        bl = Gtk.Label(label="Aun cargándolas, los píxeles de seguimiento y los enlaces rastreadores se bloquean siempre.")
        bl.set_xalign(0)
        bl.set_line_wrap(True)
        bl.get_style_context().add_class("dim-label")
        opt_box.pack_start(bl, False, False, 0)

        tr_lbl = Gtk.Label(label="Remitentes de confianza (con el bloqueo activo, se cargan sus imágenes):")
        tr_lbl.set_xalign(0)
        opt_box.pack_start(tr_lbl, False, False, 0)
        self.trust_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        opt_box.pack_start(self.trust_box, False, False, 0)
        nb.append_page(opt_box, Gtk.Label(label="Opciones"))

        # bloqueados
        bl_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        bl_box.set_margin_top(12)
        bl_lbl = Gtk.Label(label="Los correos de estos remitentes van directamente a «Correo no deseado»:")
        bl_lbl.set_xalign(0)
        bl_lbl.set_line_wrap(True)
        bl_lbl.get_style_context().add_class("welcome-sub")
        bl_box.pack_start(bl_lbl, False, False, 0)
        self.block_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        bl_scroll = Gtk.ScrolledWindow()
        bl_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        bl_scroll.add(self.block_box)
        bl_box.pack_start(bl_scroll, True, True, 0)
        nb.append_page(bl_box, Gtk.Label(label="Bloqueados"))

        # acerca de / actualizaciones
        about = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)
        about.set_margin_top(12)
        import updater
        ver = Gtk.Label(label="Email %s" % updater.current_version())
        ver.get_style_context().add_class("welcome-title")
        ver.set_xalign(0)
        about.pack_start(ver, False, False, 0)
        priv = Gtk.Label(label="Privacidad: Email no carga imágenes ni contenido remoto salvo que tú lo pidas, "
                               "elimina los píxeles de seguimiento y limpia los enlaces de parámetros rastreadores. "
                               "Tus credenciales viven en el llavero del sistema.")
        priv.set_line_wrap(True)
        priv.set_xalign(0)
        priv.get_style_context().add_class("welcome-sub")
        about.pack_start(priv, False, False, 0)
        self.upd_btn = Gtk.Button(label="Buscar actualizaciones")
        self.upd_btn.get_style_context().add_class("provider-btn")
        self.upd_lbl = Gtk.Label()
        self.upd_lbl.get_style_context().add_class("welcome-sub")
        self.upd_lbl.set_xalign(0)
        self.upd_btn.connect("clicked", lambda b: self.on_check_updates(self.upd_lbl))
        about.pack_start(self.upd_btn, False, False, 0)
        about.pack_start(self.upd_lbl, False, False, 0)
        nb.append_page(about, Gtk.Label(label="Acerca de"))

        self._refresh_accounts()
        self._refresh_trust()
        self._refresh_blocked()
        self.add_button("Cerrar", Gtk.ResponseType.CLOSE)
        self.connect("response", lambda d, r: d.destroy())
        self.show_all()

    def _refresh_accounts(self):
        for ch in list(self.acc_list.get_children()):
            self.acc_list.remove(ch)
        self.sig_account.remove_all()
        for acc in self.db.accounts():
            row = Gtk.Box(spacing=10)
            row.pack_start(avatar_widget(acc.email, 34), False, False, 0)
            info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
            nm = Gtk.Label(label=acc.email)
            nm.set_xalign(0)
            nm.get_style_context().add_class("nav-account")
            prov = {"outlook": "Outlook.com", "gmail": "Gmail (Google)", "gmailpass": "Gmail (contraseña de aplicación)"}.get(acc.provider, acc.provider)
            sub = Gtk.Label(label=prov + ("" if acc.state == "ok" else "  ·  necesita iniciar sesión"))
            sub.set_xalign(0)
            sub.get_style_context().add_class("reader-addr")
            info.pack_start(nm, False, False, 0)
            info.pack_start(sub, False, False, 0)
            row.pack_start(info, True, True, 0)
            rm = Gtk.Button(label="Quitar")
            rm.get_style_context().add_class("action-btn")
            rm.connect("clicked", self._remove_account, acc.id)
            row.pack_start(rm, False, False, 0)
            self.acc_list.pack_start(row, False, False, 0)
            self.sig_account.append(str(acc.id), acc.email)
        self.acc_list.show_all()
        if self.db.accounts():
            self.sig_account.set_active(0)
            self._load_signature()

    def _load_signature(self):
        aid = self.sig_account.get_active_id()
        if not aid:
            return
        acc = self.db.one("SELECT signature FROM accounts WHERE id=?", (aid,))
        self.sig_view.get_buffer().set_text(acc["signature"] or "")

    def _save_signature(self, btn):
        aid = self.sig_account.get_active_id()
        if not aid:
            return
        b = self.sig_view.get_buffer()
        self.db.run("UPDATE accounts SET signature=? WHERE id=?",
                    (b.get_text(b.get_start_iter(), b.get_end_iter(), False), aid))

    def _remove_account(self, btn, acc_id):
        d = Gtk.MessageDialog(transient_for=self, modal=True, message_type=Gtk.MessageType.QUESTION,
                              buttons=Gtk.ButtonsType.OK_CANCEL, text="Quitar esta cuenta")
        d.format_secondary_text("Se eliminarán sus mensajes guardados en este equipo. El correo en el servidor no se toca.")
        ok = d.run() == Gtk.ResponseType.OK
        d.destroy()
        if ok:
            self.db.remove_account(acc_id)
            self._refresh_accounts()
            self.on_accounts_changed()

    def _add_account(self, btn):
        AddAccountDialog(self, self.db, lambda acc_id: (self._refresh_accounts(), self.on_accounts_changed()))

    def _refresh_blocked(self):
        for ch in list(self.block_box.get_children()):
            self.block_box.remove(ch)
        any_item = False
        for acc in self.db.accounts():
            for addr in self.db.blocked_list(acc.id):
                any_item = True
                row = Gtk.Box(spacing=8)
                lbl = Gtk.Label(label=addr)
                lbl.set_xalign(0)
                row.pack_start(lbl, True, True, 0)
                rm = Gtk.Button(label="Desbloquear")
                rm.get_style_context().add_class("action-btn")
                rm.connect("clicked", lambda b, a=acc.id, ad=addr: (self.db.unblock(a, ad), self._refresh_blocked()))
                row.pack_start(rm, False, False, 0)
                self.block_box.pack_start(row, False, False, 0)
        if not any_item:
            none = Gtk.Label(label="Nadie bloqueado. Usa «⋯ → Bloquear remitente» al leer un correo.")
            none.get_style_context().add_class("welcome-sub")
            none.set_xalign(0)
            self.block_box.pack_start(none, False, False, 0)
        self.block_box.show_all()

    def _refresh_trust(self):
        for ch in list(self.trust_box.get_children()):
            self.trust_box.remove(ch)
        accs = self.db.accounts()
        any_item = False
        for acc in accs:
            for addr in self.db.trusted_list(acc.id):
                any_item = True
                row = Gtk.Box(spacing=8)
                lbl = Gtk.Label(label=addr)
                lbl.set_xalign(0)
                row.pack_start(lbl, True, True, 0)
                rm = Gtk.Button()
                rm.add(icon_image("close", 12, "#8A8886"))
                rm.get_style_context().add_class("action-btn")
                rm.connect("clicked", lambda b, a=acc.id, ad=addr: (self.db.untrust(a, ad), self._refresh_trust()))
                row.pack_start(rm, False, False, 0)
                self.trust_box.pack_start(row, False, False, 0)
        if not any_item:
            none = Gtk.Label(label="Ninguno todavía. Marca «Mostrar siempre» al leer un correo.")
            none.get_style_context().add_class("welcome-sub")
            none.set_xalign(0)
            self.trust_box.pack_start(none, False, False, 0)
        self.trust_box.show_all()
