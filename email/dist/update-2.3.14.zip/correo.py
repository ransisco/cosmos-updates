# -*- coding: utf-8 -*-
"""Correo - cliente de escritorio para Linux Mint con estetica del Correo de Windows.
Outlook.com/Hotmail y Gmail (OAuth2 XOAUTH2), sin rastreo: nada de contenido remoto
salvo peticion expresa, sin pixeles de seguimiento, enlaces limpios."""
import os, re, subprocess, sys, threading, time
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GLib, Gio, Pango

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mail_sync, htmlview, updater, oauth_flow
from mail_sync import CorreoDB, MailBackend
from correo_ui_base import (apply_css, icon_image, avatar_widget, ACCENT, TEXT_DIM)
from correo_dialogs import ComposeWindow, AddAccountDialog, SettingsDialog, human_size

DEMO = os.environ.get("CORREO_DEMO") == "1"

FOLDER_ICONS = {"inbox": "inbox", "drafts": "drafts", "sent": "sent",
                "archive": "archive", "junk": "junk", "trash": "trash"}
FOLDER_ORDER = {"inbox": 0, "drafts": 1, "sent": 2, "archive": 3, "junk": 4, "trash": 5}
CATEGORIES = [("Rojo", "#E81123"), ("Naranja", "#F7630C"), ("Amarillo", "#C19B00"),
              ("Verde", "#107C10"), ("Azul", "#0078D4"), ("Morado", "#5C2D91")]
def _ts_bucket(ts):
    import datetime as _dt
    if not ts:
        return "Anteriores"
    today = _dt.date.today()
    d = _dt.datetime.fromtimestamp(ts).date()
    delta = (today - d).days
    if delta <= 0:
        return "Hoy"
    if delta == 1:
        return "Ayer"
    if delta < 7:
        return "Esta semana"
    if d.year == today.year and d.month == today.month:
        return "Este mes"
    return "Anteriores"

def fmt_time(ts):
    lt = time.localtime(ts)
    now = time.localtime()
    if lt[:3] == now[:3]:
        return time.strftime("%H:%M", lt)
    if lt.tm_year == now.tm_year:
        return time.strftime("%d %b", lt).replace(" 0", " ")
    return time.strftime("%d/%m/%Y", lt)

class CorreoApp(Gtk.Application):
    def __init__(self):
        Gtk.Application.__init__(self, application_id="es.cosmos.correo",
                                 flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.db = None
        self.backend = None
        self.win = None

    def do_activate(self):
        apply_css()
        self.db = CorreoDB()
        if DEMO:
            import correo_demo
            correo_demo.seed(self.db)
        self.backend = MailBackend(self.db)
        self.backend.on_new_mail = self._on_new_mail
        self.backend.on_error = self._on_sync_error
        self.win = MainWindow(self)
        self.win.show_all()
        self.win.after_first_show()

    def _on_new_mail(self, account, count):
        def notify():
            n = Gio.Notification.new("Email")
            n.set_title(account.email)
            n.set_body("%d mensaje%s nuevo%s" % (count, "s" if count != 1 else "",
                                                 "s" if count != 1 else ""))
            self.send_notification("nuevo-correo", n)
        GLib.idle_add(notify)

    def _on_sync_error(self, account, msg):
        if self.win:
            GLib.idle_add(self.win.set_status, "Error en %s: %s" % (account.email, msg))

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        Gtk.ApplicationWindow.__init__(self, application=app, title="Email " + updater.current_version())
        self.app = app
        self.db = app.db
        self.backend = app.backend
        self.set_default_size(1240, 780)
        self.current_account = None
        self.current_folder = None
        self.current_msg = None
        self.nav_compact = False
        self.search_all = False
        self.list_filter = None
        self._list_gen = 0
        self._op_gen = 0
        self._show_gen = 0
        self._fetching_id = None
        self._fetch_missing = set()
        self._search_timer = None
        self._syncing = False
        self._image_cache = {}
        self._selected_row = None
        self._msg_rows = {}
        self._pending_select = None
        self._cursor_link = None
        self._list_limit = 300
        self._last_list_sig = None

        hb = Gtk.HeaderBar()
        hb.set_show_close_button(True)
        hb.get_style_context().add_class("top-bar")
        ham = Gtk.Button()
        ham.add(icon_image("hamburger", 13, "#FFFFFF"))
        ham.get_style_context().add_class("top-btn")
        ham.set_tooltip_text("Navegación")
        ham.connect("clicked", self.toggle_nav)
        hb.pack_start(ham)
        title = Gtk.Label(label="Email")
        title.get_style_context().add_class("top-title")
        hb.pack_start(title)
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text("Buscar")
        self.search_entry.get_style_context().add_class("top-search")
        self.search_entry.set_size_request(300, -1)
        self.search_entry.connect("search-changed", self._search_changed)
        hb.set_custom_title(self.search_entry)
        self.sync_btn = Gtk.Button()
        self.sync_stack = Gtk.Stack()
        self.sync_icon_img = icon_image("getmail", 14, "#0078D4")
        self.sync_spin = Gtk.Spinner()
        self.sync_spin.get_style_context().add_class("top-spinner")
        self.sync_stack.add_named(self.sync_icon_img, "icon")
        self.sync_stack.add_named(self.sync_spin, "spin")
        self.sync_btn.add(self.sync_stack)
        self.sync_btn.get_style_context().add_class("top-sync")
        self.sync_btn.set_tooltip_text("Sincronizar")
        self.sync_btn.connect("clicked", lambda b: self.sync_now())
        hb.pack_end(self.sync_btn)
        self.set_titlebar(hb)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.add(root)

        self.error_bar = Gtk.Box(spacing=10)
        self.error_bar.get_style_context().add_class("error-bar")
        self.error_lbl = Gtk.Label()
        self.error_lbl.get_style_context().add_class("error-bar-text")
        self.error_lbl.set_xalign(0)
        self.error_lbl.set_line_wrap(True)
        self.error_bar.pack_start(self.error_lbl, True, True, 0)
        relogin = Gtk.Button(label="Iniciar sesión de nuevo")
        relogin.get_style_context().add_class("action-btn")
        relogin.connect("clicked", lambda b: self.relogin())
        self.relogin_btn = relogin
        self.error_bar.pack_end(relogin, False, False, 0)
        self.error_bar.set_no_show_all(True)
        root.pack_start(self.error_bar, False, False, 0)

        cmd = Gtk.Box(spacing=2)
        cmd.get_style_context().add_class("command-bar")
        newb = Gtk.Button(label="Nuevo correo")
        newb.set_image(icon_image("plus", 13, "#323130"))
        newb.set_always_show_image(True)
        newb.get_style_context().add_class("cmd-btn")
        newb.get_style_context().add_class("cmd-new")
        newb.connect("clicked", self.compose_new)
        cmd.pack_start(newb, False, False, 0)
        root.pack_start(cmd, False, False, 0)

        main = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        root.pack_start(main, True, True, 0)

        # ---------- panel de navegacion ----------
        self.nav = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.nav.get_style_context().add_class("nav-pane")
        self.nav.set_size_request(200, -1)
        main.pack_start(self.nav, False, False, 0)

        nav_scroll = Gtk.ScrolledWindow()
        nav_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.nav_inner = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        nav_scroll.add(self.nav_inner)
        self.nav.pack_start(nav_scroll, True, True, 0)

        self.status_lbl = Gtk.Label(label="Listo")
        self.status_lbl.get_style_context().add_class("status-label")
        self.status_lbl.set_xalign(0)
        self.status_lbl.set_ellipsize(Pango.EllipsizeMode.END)
        status_bar = Gtk.Box()
        status_bar.get_style_context().add_class("status-bar")
        status_bar.pack_start(self.status_lbl, True, True, 0)
        root.pack_end(status_bar, False, False, 0)

        # ---------- lista de mensajes ----------
        self.list_pane = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.list_pane.get_style_context().add_class("list-pane")
        self.list_pane.set_size_request(380, -1)
        main.pack_start(self.list_pane, False, False, 0)

        tabs = Gtk.Box(spacing=0)
        tabs.set_margin_start(10); tabs.set_margin_end(8)
        tabs.set_margin_top(6); tabs.set_margin_bottom(2)
        filt = Gtk.MenuButton()
        fb = Gtk.Box(spacing=4)
        self.filter_lbl = Gtk.Label(label="Filtrar")
        fb.pack_start(self.filter_lbl, False, False, 0)
        fb.pack_start(icon_image("chevron-down", 10, "#605E5C"), False, False, 0)
        filt.add(fb)
        filt.get_style_context().add_class("pill-filter")
        filt.set_tooltip_text("Filtrar")
        self.filter_menu = Gtk.Menu()
        for lbl, key in (("Todos", None), ("No leídos", "unread"),
                         ("Destacados", "flagged"), ("Con archivos adjuntos", "attach")):
            mi = Gtk.MenuItem(label=lbl)
            mi.connect("activate", self._set_filter, key)
            self.filter_menu.append(mi)
        self.filter_menu.show_all()
        filt.set_popup(self.filter_menu)
        tabs.pack_end(filt, False, False, 0)
        self.list_pane.pack_start(tabs, False, False, 0)

        list_scroll = Gtk.ScrolledWindow()
        self._bulk_selecting = False
        self._sel_anchor = None
        self.msg_list = Gtk.ListBox()
        self.msg_list.set_selection_mode(Gtk.SelectionMode.MULTIPLE)
        self.msg_list.connect("button-press-event", self._on_list_button)
        self.msg_list.connect("row-selected", self.on_msg_selected)
        self.msg_list.connect("row-activated", self._on_row_activated)
        list_scroll.add(self.msg_list)
        self.list_pane.pack_start(list_scroll, True, True, 0)

        # ---------- panel de lectura ----------
        self.reader = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.reader.set_hexpand(True)
        main.pack_start(self.reader, True, True, 0)
        self.reader_stack = Gtk.Stack()
        self.reader.pack_start(self.reader_stack, True, True, 0)
        self.empty_box = self._build_empty()
        self.reader_stack.add_named(self.empty_box, "empty")
        self.reading_box = self._build_reading()
        self.reader_stack.add_named(self.reading_box, "reading")
        self.reader_stack.set_visible_child_name("empty")

        self.refresh_nav()
        self.connect("key-press-event", self._on_key_press)

    # ---------- estructura de lectura ----------
    def _build_empty(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=14)
        box.set_valign(Gtk.Align.CENTER)
        box.set_halign(Gtk.Align.CENTER)
        img = icon_image("envelope", 96, "#D2D0CE")
        box.pack_start(img, False, False, 0)
        lbl = Gtk.Label(label="Selecciona un elemento para leerlo")
        lbl.get_style_context().add_class("welcome-sub")
        box.pack_start(lbl, False, False, 0)
        sub = Gtk.Label(label="Nada se descarga de internet sin tu permiso: sin píxeles de seguimiento ni rastreadores.")
        sub.set_line_wrap(True)
        sub.set_max_width_chars(44)
        sub.set_justify(Gtk.Justification.CENTER)
        sub.get_style_context().add_class("welcome-sub")
        box.pack_start(sub, False, False, 0)
        return box

    def _build_reading(self):
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)

        head = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        head.set_margin_start(22); head.set_margin_end(16); head.set_margin_top(14); head.set_margin_bottom(8)
        box.pack_start(head, False, False, 0)

        subj_row = Gtk.Box(spacing=8)
        self.r_subject = Gtk.Label()
        self.r_subject.get_style_context().add_class("reader-subject")
        self.r_subject.set_xalign(0)
        self.r_subject.set_line_wrap(True)
        self.r_subject.set_selectable(True)
        subj_row.pack_start(self.r_subject, True, True, 0)
        actions = Gtk.Box(spacing=0)
        for icon, tip, fn in (("reply", "Responder", self.do_reply),
                              ("reply_all", "Responder a todos", self.do_reply_all),
                              ("forward", "Reenviar", self.do_forward)):
            b = Gtk.Button()
            b.add(icon_image(icon, 14))
            b.get_style_context().add_class("action-btn")
            b.set_tooltip_text(tip)
            b.connect("clicked", fn)
            actions.pack_start(b, False, False, 0)
        more = Gtk.MenuButton()
        more.add(icon_image("more", 14))
        more.get_style_context().add_class("action-btn")
        more.set_tooltip_text("Más acciones")
        self.more_menu = Gtk.Menu()
        mi_unread = Gtk.MenuItem(label="Marcar como no leído")
        mi_unread.connect("activate", self.do_mark_unread)
        self.more_menu.append(mi_unread)
        mi_flag = Gtk.MenuItem(label="Destacar")
        mi_flag.connect("activate", self.do_flag)
        self.more_menu.append(mi_flag)
        self.mi_urgent = Gtk.MenuItem(label="Marcar como urgente")
        self.mi_urgent.connect("activate", self.do_toggle_urgent)
        self.more_menu.append(self.mi_urgent)
        self.more_menu.append(Gtk.SeparatorMenuItem())
        self.mi_block = Gtk.MenuItem(label="Bloquear remitente")
        self.mi_block.connect("activate", self.do_block_sender)
        self.more_menu.append(self.mi_block)
        self.more_menu.show_all()
        more.set_popup(self.more_menu)
        actions.pack_start(more, False, False, 0)
        subj_row.pack_end(actions, False, False, 0)
        head.pack_start(subj_row, False, False, 0)

        from_row = Gtk.Box(spacing=12)
        self.r_avatar_slot = Gtk.Box()
        from_row.pack_start(self.r_avatar_slot, False, False, 0)
        who = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        self.r_from = Gtk.Label()
        self.r_from.get_style_context().add_class("reader-from")
        self.r_from.set_xalign(0)
        self.r_from.set_selectable(True)
        self.r_to = Gtk.Label()
        self.r_to.get_style_context().add_class("reader-addr")
        self.r_to.set_xalign(0)
        self.r_to.set_selectable(True)
        self.r_to.set_ellipsize(Pango.EllipsizeMode.END)
        who.pack_start(self.r_from, False, False, 0)
        who.pack_start(self.r_to, False, False, 0)
        from_row.pack_start(who, True, True, 0)
        self.r_date = Gtk.Label()
        self.r_date.get_style_context().add_class("reader-date")
        from_row.pack_end(self.r_date, False, False, 0)
        head.pack_start(from_row, False, False, 0)

        self.att_row = Gtk.Box(spacing=8)
        self.att_row.set_margin_start(22)
        self.att_row.set_margin_end(16)
        box.pack_start(self.att_row, False, False, 0)
        self.att_row.show_all()
        self.att_row.set_no_show_all(True)
        self.att_row.hide()

        self.infobar = Gtk.Box(spacing=6)
        self.infobar.get_style_context().add_class("infobar")
        self.info_lbl = Gtk.Label()
        self.info_lbl.get_style_context().add_class("infobar-text")
        self.info_lbl.set_xalign(0)
        self.info_lbl.set_ellipsize(Pango.EllipsizeMode.END)
        self.info_lbl.set_valign(Gtk.Align.CENTER)
        self.infobar.pack_start(self.info_lbl, True, True, 0)
        show_btn = Gtk.Button(label="Mostrar")
        show_btn.set_valign(Gtk.Align.CENTER)
        self.info_show_btn = show_btn
        show_btn.get_style_context().add_class("infobar-btn")
        show_btn.connect("clicked", self.load_remote_images)
        always_btn = Gtk.Button(label="Siempre")
        always_btn.set_valign(Gtk.Align.CENTER)
        self.info_always_btn = always_btn
        always_btn.get_style_context().add_class("infobar-btn")
        always_btn.connect("clicked", self.trust_sender)
        self.infobar.pack_end(always_btn, False, False, 0)
        self.infobar.pack_end(show_btn, False, False, 0)
        box.pack_start(self.infobar, False, False, 0)
        self.infobar.show_all()
        self.infobar.set_no_show_all(True)
        self.infobar.hide()

        sep = Gtk.Separator()
        box.pack_start(sep, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        self.body_view = Gtk.TextView()
        self.body_view.set_editable(False)
        self.body_view.set_cursor_visible(False)
        self.body_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.body_view.set_margin_start(22); self.body_view.set_margin_end(22)
        self.body_view.set_margin_top(14); self.body_view.set_margin_bottom(14)
        self.body_view.get_style_context().add_class("body-view")
        self.body_view.connect("event-after", self.on_body_event)
        self.body_view.connect("motion-notify-event", self.on_body_motion)
        self._render_width = 0
        self._resize_src = 0
        scroll.connect("size-allocate", self._on_body_resize)
        scroll.add(self.body_view)
        box.pack_start(scroll, True, True, 0)
        self.body_scroll = scroll
        return box

    # ---------- navegacion ----------
    def toggle_nav(self, btn):
        self.nav_compact = not self.nav_compact
        self.nav.set_size_request(48 if self.nav_compact else 200, -1)
        self.refresh_nav()

    def refresh_nav(self):
        for ch in list(self.nav_inner.get_children()):
            self.nav_inner.remove(ch)
        accounts = self.db.accounts()
        if not accounts:
            self.show_welcome()
            return
        if self.current_account not in [a.id for a in accounts]:
            self.current_account = accounts[0].id
        if len(accounts) > 1:
            self._nav_section("Cuentas")
            for acc in accounts:
                row = Gtk.Button()
                row.get_style_context().add_class("nav-row")
                if acc.id == self.current_account:
                    row.get_style_context().add_class("nav-row-selected")
                inner = Gtk.Box(spacing=8)
                inner.pack_start(avatar_widget(acc.email, 22), False, False, 0)
                if not self.nav_compact:
                    lbl = Gtk.Label(label=acc.email)
                    lbl.get_style_context().add_class("nav-account")
                    lbl.set_ellipsize(Pango.EllipsizeMode.END)
                    inner.pack_start(lbl, True, True, 0)
                    if acc.state != "ok":
                        inner.pack_end(icon_image("junk", 12, "#D83B01"), False, False, 0)
                row.add(inner)
                row.connect("clicked", self.on_account_clicked, acc.id)
                self.nav_inner.pack_start(row, False, False, 0)
        self._nav_section("Carpetas")
        folders = self.db.folders(self.current_account)
        folders.sort(key=lambda f: (FOLDER_ORDER.get(f["special"], 50), f["name"]))
        for f in folders:
            row = Gtk.Button()
            row.get_style_context().add_class("nav-row")
            if self.current_folder and f["id"] == self.current_folder:
                row.get_style_context().add_class("nav-row-selected")
            inner = Gtk.Box(spacing=8)
            inner.pack_start(icon_image(FOLDER_ICONS.get(f["special"], "envelope"), 14), False, False, 0)
            if not self.nav_compact:
                lbl = Gtk.Label(label=f["name"])
                lbl.get_style_context().add_class("nav-label")
                lbl.set_xalign(0)
                inner.pack_start(lbl, True, True, 0)
                if f["unseen"]:
                    cnt = Gtk.Label(label=str(f["unseen"]))
                    cnt.get_style_context().add_class("nav-count")
                    inner.pack_end(cnt, False, False, 0)
            row.add(inner)
            row.set_tooltip_text(f["name"])
            row.connect("clicked", self.on_folder_clicked, f["id"])
            self.nav_inner.pack_start(row, False, False, 0)
        # boton configuracion abajo
        bottom = Gtk.Box(spacing=4)
        bottom.set_margin_top(8)
        gear = Gtk.Button()
        gear.get_style_context().add_class("nav-settings")
        inner = Gtk.Box(spacing=8)
        inner.pack_start(icon_image("gear", 14, "#323130"), False, False, 0)
        if not self.nav_compact:
            lbl = Gtk.Label(label="Configuración")
            lbl.get_style_context().add_class("nav-label")
            inner.pack_start(lbl, False, False, 0)
        gear.add(inner)
        gear.connect("clicked", self.open_settings)
        self.nav_inner.pack_end(gear, False, False, 4)
        self.nav_inner.show_all()

    def _nav_section(self, text):
        if self.nav_compact:
            return
        lbl = Gtk.Label(label=text)
        lbl.get_style_context().add_class("nav-section")
        lbl.set_xalign(0)
        self.nav_inner.pack_start(lbl, False, False, 0)

    def show_welcome(self):
        for ch in list(self.reader_stack.get_children()):
            if ch not in (self.empty_box, self.reading_box):
                self.reader_stack.remove(ch)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        box.set_valign(Gtk.Align.CENTER)
        box.set_halign(Gtk.Align.CENTER)
        t = Gtk.Label(label="Email")
        t.get_style_context().add_class("welcome-title")
        box.pack_start(t, False, False, 0)
        s = Gtk.Label(label="Tu correo de Outlook y Gmail, sin rastreo: las imágenes se cargan solas,\n"
                            "pero los píxeles de seguimiento y los enlaces rastreadores se bloquean siempre.")
        s.get_style_context().add_class("welcome-sub")
        s.set_justify(Gtk.Justification.CENTER)
        box.pack_start(s, False, False, 0)
        add = Gtk.Button(label="Agregar una cuenta")
        add.get_style_context().add_class("new-mail")
        add.connect("clicked", self.add_account)
        box.pack_start(add, False, False, 0)
        self.reader_stack.add_named(box, "welcome")
        box.show_all()
        self.reader_stack.set_visible_child_name("welcome")

    # ---------- lista de mensajes ----------
    def _search_changed(self, entry):
        if self._search_timer:
            GLib.source_remove(self._search_timer)
        self._search_timer = GLib.timeout_add(220, self._search_fire)

    def _search_fire(self):
        self._search_timer = None
        self.refresh_list()
        return False

    def _list_signature(self):
        if not self.current_account:
            return None
        sig = []
        for f in self.db.folders(self.current_account):
            r = self.db.one("SELECT COUNT(*) c, COALESCE(MAX(ts),0) t, COALESCE(SUM(urgent),0) u FROM messages WHERE folder_id=?",
                            (f["id"],))
            sig.append((f["id"], f["unseen"], r["c"], r["t"], r["u"]))
        return tuple(sig)

    def _touch_sig(self):
        self._last_list_sig = self._list_signature()

    def _recount_unseen(self, account_id):
        for f in self.db.folders(account_id):
            self.db.run(
                'UPDATE folders SET unseen=(SELECT COUNT(*) FROM messages '
                'WHERE folder_id=? AND (flags & 1)=0) WHERE id=?', (f["id"], f["id"]))

    def _remove_rows(self, ids):
        ids = set(ids)
        for ch in list(self.msg_list.get_children()):
            if getattr(ch, "msg_id", None) in ids:
                self.msg_list.remove(ch)
                self._msg_rows.pop(ch.msg_id, None)
        # cabeceras de grupo que se quedan vacias
        prev = None
        for ch in list(self.msg_list.get_children()):
            is_head = "msg-group-row" in ch.get_style_context().list_classes()
            if is_head and prev is not None:
                self.msg_list.remove(prev)
            prev = ch if is_head else None
        if prev is not None:
            self.msg_list.remove(prev)
        # sin suficientes filas, el boton "Mostrar mas" ya no aplica
        n_rows = sum(1 for ch in self.msg_list.get_children() if getattr(ch, "msg_id", None))
        if n_rows < self._list_limit:
            for ch in list(self.msg_list.get_children()):
                if getattr(ch, "_is_more_row", False):
                    self.msg_list.remove(ch)
        sel = self._pending_select
        self._pending_select = None
        row = self._msg_rows.get(sel) if sel else None
        if row is None:
            row = next((r for r in self.msg_list.get_children() if getattr(r, "msg_id", None)), None)
        if row is not None:
            self.msg_list.select_row(row)
        self._touch_sig()

    def refresh_list(self):
        for ch in list(self.msg_list.get_children()):
            self.msg_list.remove(ch)
        self._msg_rows = {}
        if not self.current_account:
            return
        if not self.current_folder:
            f = self.db.folder_by_special(self.current_account, "inbox") or \
                (self.db.folders(self.current_account) or [None])[0]
            if not f:
                return
            self.current_folder = f["id"]
        folder = self.db.one("SELECT * FROM folders WHERE id=?", (self.current_folder,))
        q = self.search_entry.get_text().strip()
        like = "%" + q + "%"
        if q and self.search_all:
            rows = self.db.q("""SELECT * FROM messages WHERE account_id=? AND
                (subject LIKE ? OR from_name LIKE ? OR preview LIKE ? OR from_addr LIKE ? OR body_text LIKE ?)
                ORDER BY urgent DESC, ts DESC LIMIT ?""", (self.current_account, like, like, like, like, like, self._list_limit))
        elif q:
            rows = self.db.q("""SELECT * FROM messages WHERE folder_id=? AND
                (subject LIKE ? OR from_name LIKE ? OR preview LIKE ? OR from_addr LIKE ? OR body_text LIKE ?)
                ORDER BY urgent DESC, ts DESC LIMIT ?""", (self.current_folder, like, like, like, like, like, self._list_limit))
        else:
            rows = self.db.q("SELECT * FROM messages WHERE folder_id=? ORDER BY urgent DESC, ts DESC LIMIT ?",
                             (self.current_folder, self._list_limit))
        if self.list_filter == "unread":
            rows = [m for m in rows if not (m["flags"] & 1)]
        elif self.list_filter == "flagged":
            rows = [m for m in rows if m["flags"] & 2]
        elif self.list_filter == "attach":
            rows = [m for m in rows if m["has_attach"]]
        self._list_gen += 1
        self._touch_sig()
        self._render_batch(rows, q, 0, None, self._list_gen)

    def _render_batch(self, rows, q, start, last_bucket, gen):
        if gen != self._list_gen:
            return False
        cat_colors = dict(CATEGORIES)
        end = min(start + 30, len(rows))
        for i in range(start, end):
            m = rows[i]
            if not q:
                bucket = "Urgentes" if m["urgent"] else _ts_bucket(m["ts"])
                if bucket != last_bucket:
                    last_bucket = bucket
                    gh = Gtk.ListBoxRow()
                    gh.set_selectable(False)
                    gh.set_activatable(False)
                    gh.get_style_context().add_class("msg-group-row")
                    hl = Gtk.Label(label=bucket)
                    hl.get_style_context().add_class("group-header")
                    hl.set_xalign(0)
                    gh.add(hl)
                    self.msg_list.add(gh)
                    gh.show_all()
            row = Gtk.ListBoxRow()
            row.get_style_context().add_class("msg-row")
            unread = not (m["flags"] & 1)
            if unread:
                row.get_style_context().add_class("msg-row-unread")
            if m["urgent"]:
                row.get_style_context().add_class("msg-row-urgent")
            outer = Gtk.Box(spacing=10)
            outer.set_margin_start(8); outer.set_margin_end(10)
            outer.set_margin_top(6); outer.set_margin_bottom(6)
            outer.pack_start(avatar_widget(m["from_name"] or m["from_addr"], 34), False, False, 0)
            col = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
            line1 = Gtk.Box(spacing=6)
            sender = Gtk.Label(label=m["from_name"] or m["from_addr"])
            sender.get_style_context().add_class("msg-sender-unread" if unread else "msg-sender")
            sender.set_xalign(0)
            sender.set_ellipsize(Pango.EllipsizeMode.END)
            sender.set_max_width_chars(28)
            line1.pack_start(sender, True, True, 0)
            if m["flags"] & 2:
                fl = Gtk.Label(label="⚑")
                fl.get_style_context().add_class("msg-flagged")
                line1.pack_end(fl, False, False, 0)
            if m["has_attach"]:
                line1.pack_end(icon_image("clip", 13, "#8A8886"), False, False, 0)
            tl = Gtk.Label(label=fmt_time(m["ts"] or 0))
            tl.get_style_context().add_class("msg-time")
            line1.pack_end(tl, False, False, 0)
            col.pack_start(line1, False, False, 0)
            subj = Gtk.Label(label=m["subject"] or "(sin asunto)")
            subj.get_style_context().add_class("msg-subject-unread" if unread else "msg-subject")
            subj.set_xalign(0)
            subj.set_ellipsize(Pango.EllipsizeMode.END)
            col.pack_start(subj, False, False, 0)
            cats = [c for c in (m["categories"] or "").split(",") if c]
            if cats:
                cbox = Gtk.Box(spacing=4)
                for cn in cats[:3]:
                    cc = cat_colors.get(cn, "#605E5C")
                    cl = Gtk.Label()
                    cl.set_markup('<span size="x-small" background="%s" foreground="white"> %s </span>'
                                  % (cc, cn))
                    cbox.pack_start(cl, False, False, 0)
                col.pack_start(cbox, False, False, 0)
            prev = Gtk.Label(label=m["preview"] or "")
            prev.get_style_context().add_class("msg-preview")
            prev.set_xalign(0)
            prev.set_ellipsize(Pango.EllipsizeMode.END)
            col.pack_start(prev, False, False, 0)
            outer.pack_start(col, True, True, 0)
            row.add(outer)
            row.msg_id = m["id"]
            self.msg_list.add(row)
            row.show_all()
            self._msg_rows[m["id"]] = row
        if end < len(rows):
            GLib.idle_add(self._render_batch, rows, q, end, last_bucket, gen)
        else:
            sel = self._pending_select
            self._pending_select = None
            if not sel and self.current_msg and self.current_msg in self._msg_rows:
                sel = self.current_msg
            if not sel:
                for r in self.msg_list.get_children():
                    if getattr(r, "msg_id", None):
                        sel = r.msg_id
                        break
            if sel and sel in self._msg_rows:
                self.msg_list.select_row(self._msg_rows[sel])
            if len(rows) >= self._list_limit:
                more = Gtk.ListBoxRow()
                more.set_selectable(False)
                more._is_more_row = True
                mb = Gtk.Button(label="Mostrar más mensajes")
                mb.get_style_context().add_class("more-btn")
                mb.connect("clicked", self._show_more)
                more.add(mb)
                self.msg_list.add(more)
                more.show_all()
        return False

    def _show_more(self, btn):
        self._list_limit += 300
        self.refresh_list()

    # ---------- atajos de teclado ----------
    def _on_key_press(self, widget, event):
        key = event.keyval
        mods = event.state & Gtk.accelerator_get_default_mod_mask()
        ctrl = bool(mods & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(mods & Gdk.ModifierType.SHIFT_MASK)
        focus = self.get_focus()
        typing = isinstance(focus, (Gtk.Entry, Gtk.SpinButton)) or (isinstance(focus, Gtk.TextView) and focus.get_editable())
        if typing:
            if key == Gdk.KEY_Escape and (focus is self.search_entry or self.search_entry.is_ancestor(focus)):
                self.search_entry.set_text("")
                self.msg_list.grab_focus()
                return True
            return False
        if ctrl and key in (Gdk.KEY_n, Gdk.KEY_N):
            self.compose_new(None)
            return True
        if ctrl and key in (Gdk.KEY_r, Gdk.KEY_R):
            (self.do_reply_all if shift else self.do_reply)(None)
            return True
        if ctrl and key in (Gdk.KEY_l, Gdk.KEY_L):
            self.do_forward(None)
            return True
        if ctrl and key in (Gdk.KEY_f, Gdk.KEY_F):
            self.search_entry.grab_focus()
            return True
        if ctrl and key in (Gdk.KEY_a, Gdk.KEY_A):
            self._bulk_selecting = True
            n = 0
            for r in self.msg_list.get_children():
                if getattr(r, "msg_id", None):
                    self.msg_list.select_row(r)
                    n += 1
            self._bulk_selecting = False
            self._update_cmd_state()
            self.set_status(("%d mensajes seleccionados" % n) if n else "No hay mensajes que seleccionar")
            return True
        if key == Gdk.KEY_F5:
            self.sync_now()
            return True
        if key in (Gdk.KEY_Delete, Gdk.KEY_KP_Delete):
            (self.do_delete_permanent if shift else self.do_delete)(None)
            return True
        if key in (Gdk.KEY_m, Gdk.KEY_M) and not ctrl:
            self.do_toggle_read(None)
            return True
        if key in (Gdk.KEY_u, Gdk.KEY_U) and not ctrl:
            self.do_toggle_urgent(None)
            return True
        if key == Gdk.KEY_Escape and self.search_entry.get_text().strip():
            self.search_entry.set_text("")
            return True
        return False

    def _next_msg_id(self, gone):
        ids = [r.msg_id for r in self.msg_list.get_children() if getattr(r, "msg_id", None)]
        if gone not in ids:
            return None
        i = ids.index(gone)
        if i + 1 < len(ids):
            return ids[i + 1]
        return ids[i - 1] if i > 0 else None

    def do_toggle_read(self, b):
        m, f = self._current()
        if not m:
            return
        if m["flags"] & 1:
            self.do_mark_unread(None)
        else:
            self._mark_read(m)

    _FILTER_LABELS = {None: "Filtrar", "unread": "No leídos", "flagged": "Destacados",
                      "attach": "Con adjuntos"}

    def _set_filter(self, item, key):
        self.list_filter = key
        self.filter_lbl.set_text(self._FILTER_LABELS.get(key, "Filtrar"))
        self.refresh_list()

    def _update_cmd_state(self):
        if getattr(self, "mi_urgent", None) and self.current_msg:
            m = self.db.one("SELECT urgent FROM messages WHERE id=?", (self.current_msg,))
            self.mi_urgent.set_label("Quitar urgente" if (m and m["urgent"]) else "Marcar como urgente")

    def _cmd_btn(self, parent, icon, label, fn):
        b = Gtk.Button(label=label)
        b.set_image(icon_image(icon, 13))
        b.set_always_show_image(True)
        b.get_style_context().add_class("cmd-btn")
        b.connect("clicked", fn)
        b.set_sensitive(False)
        parent.pack_start(b, False, False, 0)
        return b

    # ---------- seleccion y lectura ----------
    def on_msg_selected(self, listbox, row):
        if row is None or self._bulk_selecting:
            return
        self._open_row(row)

    def _open_row(self, row):
        m = self.db.one("SELECT * FROM messages WHERE id=?", (row.msg_id,))
        if not m:
            return
        already = self.current_msg == m["id"]
        self.current_msg = m["id"]
        self._show_gen += 1
        show_gen = self._show_gen
        self._update_cmd_state()
        if m["body_text"] or m["body_html"]:
            self._show_message(m)
            if not (m["flags"] & 1) and not already:
                self._mark_read(m)
        else:
            self.set_status("Descargando mensaje…")
            if not already:
                # cabecera nueva y cuerpo vacío: nunca se mezclan dos mensajes
                skel = dict(m)
                skel["body_text"] = ""
                skel["body_html"] = None
                self._show_message(skel)
            mid = m["id"]
            # sin cuerpo no se reintenta en bucle: una descarga en curso o ya
            # fallida para este mensaje no lanza otro hilo
            if self._fetching_id == mid or mid in self._fetch_missing:
                return
            self._fetching_id = mid
            def work():
                full = None
                try:
                    folder = self.db.one("SELECT * FROM folders WHERE id=?", (m["folder_id"],))
                    acc = self._account(m["account_id"])
                    if not DEMO and acc:
                        try:
                            full = self.backend.fetch_message(acc, folder, m)
                        except Exception as e:
                            GLib.idle_add(self._fetch_status, mid, show_gen,
                                          "Error al descargar: " + str(e))
                    if not full:
                        full = self.db.one("SELECT * FROM messages WHERE id=?", (m["id"],))
                    if not full or not (full["body_text"] or full["body_html"]):
                        GLib.idle_add(self._fetch_missing.add, mid)
                finally:
                    self._fetching_id = None
                GLib.idle_add(self._show_fetched, mid, show_gen, full)
                GLib.idle_add(self._patch_row, mid)
                GLib.idle_add(self.refresh_nav)
                GLib.idle_add(self._touch_sig)
            threading.Thread(target=work, daemon=True).start()

    def do_toggle_urgent(self, b):
        ids = self._selected_msg_ids()
        if not ids and self.current_msg:
            ids = [self.current_msg]
        if not ids:
            return
        rows = [self.db.one("SELECT urgent FROM messages WHERE id=?", (i,)) for i in ids]
        new = 0 if all(r and r["urgent"] for r in rows) else 1
        for i in ids:
            self.db.run("UPDATE messages SET urgent=? WHERE id=?", (new, i))
        self._update_cmd_state()
        self.refresh_list()
        if new:
            self.set_status(("Marcado como urgente" if len(ids) == 1 else "%d marcados como urgentes" % len(ids)))
        else:
            self.set_status(("Ya no es urgente" if len(ids) == 1 else "%d ya no son urgentes" % len(ids)))

    def _on_list_button(self, widget, event):
        if event.type != Gdk.EventType.BUTTON_PRESS:
            return False
        _okbtn, _btn = event.get_button()
        if _okbtn and _btn == 3:
            row = widget.get_row_at_y(int(event.y))
            if row is None or not getattr(row, "msg_id", None):
                return False
            if not row.is_selected():
                self._bulk_selecting = True
                widget.unselect_all()
                widget.select_row(row)
                self._bulk_selecting = False
                self._sel_anchor = row.msg_id
            self._open_row(row)
            self._show_msg_menu(event)
            return True
        if not _okbtn or _btn != 1:
            return False
        mods = event.state & Gtk.accelerator_get_default_mod_mask()
        ctrl = bool(mods & Gdk.ModifierType.CONTROL_MASK)
        shift = bool(mods & Gdk.ModifierType.SHIFT_MASK)
        row = widget.get_row_at_y(int(event.y))
        if row is None or not getattr(row, "msg_id", None):
            return bool(ctrl or shift)
        if shift and self._sel_anchor in self._msg_rows:
            rows = [r for r in widget.get_children() if getattr(r, "msg_id", None)]
            try:
                i0 = rows.index(self._msg_rows[self._sel_anchor])
                i1 = rows.index(row)
            except ValueError:
                return True
            self._bulk_selecting = True
            if not ctrl:
                widget.unselect_all()
            lo, hi = sorted((i0, i1))
            for r in rows[lo:hi + 1]:
                widget.select_row(r)
            self._bulk_selecting = False
            self._update_cmd_state()
            self.set_status("%d mensajes seleccionados" % len(self._selected_msg_ids()))
            return True
        if ctrl:
            self._bulk_selecting = True
            if row.is_selected():
                widget.unselect_row(row)
            else:
                widget.select_row(row)
            self._bulk_selecting = False
            self._sel_anchor = row.msg_id
            self._update_cmd_state()
            n = len(self._selected_msg_ids())
            self.set_status(("%d mensajes seleccionados" % n) if n else "Listo")
            return True
        self._bulk_selecting = True
        widget.unselect_all()
        widget.select_row(row)
        self._bulk_selecting = False
        self._sel_anchor = row.msg_id
        self._open_row(row)
        return True

    def _show_msg_menu(self, event):
        m, f = self._current()
        if not m:
            return
        menu = Gtk.Menu()
        def item(label, fn, *args):
            mi = Gtk.MenuItem(label=label)
            mi.connect("activate", fn, *args)
            menu.append(mi)
            return mi
        item("Responder", self.do_reply)
        item("Responder a todos", self.do_reply_all)
        item("Reenviar", self.do_forward)
        menu.append(Gtk.SeparatorMenuItem())
        item("Archivar", self.do_archive)
        mi_move = Gtk.MenuItem(label="Mover a")
        sub = Gtk.Menu()
        self._fill_move_menu(sub)
        mi_move.set_submenu(sub)
        menu.append(mi_move)
        mi_cat = Gtk.MenuItem(label="Categorías")
        subc = Gtk.Menu()
        self._fill_cat_menu(subc)
        mi_cat.set_submenu(subc)
        menu.append(mi_cat)
        menu.append(Gtk.SeparatorMenuItem())
        item("Marcar como no leído", self.do_mark_unread)
        item("Destacar", self.do_flag)
        urg = self.db.one("SELECT urgent FROM messages WHERE id=?", (m["id"],))
        item("Quitar urgente" if (urg and urg["urgent"]) else "Marcar como urgente",
             self.do_toggle_urgent)
        menu.append(Gtk.SeparatorMenuItem())
        item("Bloquear", self.do_block_sender)
        item("Eliminar", self.do_delete)
        menu.show_all()
        menu.popup_at_pointer(event)

    def _selected_msg_ids(self):
        if not getattr(self, "msg_list", None):
            return []
        return [r.msg_id for r in self.msg_list.get_selected_rows() if getattr(r, "msg_id", None)]

    def _on_row_activated(self, listbox, row):
        # doble clic en Borradores: seguir editando el borrador
        if not getattr(row, "msg_id", None):
            return
        f = self.db.one("SELECT * FROM folders WHERE id=?", (self.current_folder,)) if self.current_folder else None
        if not f or f["special"] != "drafts":
            return
        m = self.db.one("SELECT * FROM messages WHERE id=?", (row.msg_id,))
        if m:
            ComposeWindow(self, self.backend, self.db, self._account(m["account_id"]),
                          draft=m, on_sent=self.sync_now)

    def _fetch_status(self, mid, gen, text):
        if gen == self._show_gen and self.current_msg == mid:
            self.set_status(text)

    def _show_fetched(self, mid, gen, full):
        # una descarga tardía nunca pisa el mensaje seleccionado después
        if gen != self._show_gen or self.current_msg != mid or not full:
            return
        self._show_message(full)
        row = self._msg_rows.get(mid)
        if row:
            self._restyle_row(row, mid)

    def _patch_row(self, mid):
        """Tras descargar un cuerpo, actualiza solo la fila afectada (asunto y
        vista previa); la lista no se reconstruye entera."""
        row = self._msg_rows.get(mid)
        m = self.db.one("SELECT * FROM messages WHERE id=?", (mid,))
        if not row or not m:
            return
        labels = []
        def walk(wdg):
            if isinstance(wdg, Gtk.Label):
                labels.append(wdg)
            if isinstance(wdg, Gtk.Container):
                for ch in wdg.get_children():
                    walk(ch)
        walk(row)
        for lbl in labels:
            cls = lbl.get_style_context().list_classes()
            if "msg-subject" in cls or "msg-subject-unread" in cls:
                lbl.set_text(m["subject"] or "(sin asunto)")
            elif "msg-preview" in cls:
                lbl.set_text(m["preview"] or "")

    def _account(self, acc_id):
        for a in self.db.accounts():
            if a.id == acc_id:
                return a
        return None

    def _show_message(self, m):
        if not m:
            return
        self.reader_stack.set_visible_child_name("reading")
        self.r_subject.set_text(m["subject"] or "(sin asunto)")
        fname = m["from_name"] or m["from_addr"]
        self.r_from.set_text(fname)
        to = ("Para: " + (m["to_addrs"] or "")) + (("   ·   " + m["from_addr"]) if m["from_addr"] else "")
        self.r_to.set_text(to)
        self.r_date.set_text(time.strftime("%a %d/%m/%Y %H:%M", time.localtime(m["ts"] or time.time())))
        self.mi_block.set_label("Bloquear a %s" % (m["from_addr"] or ""))
        for ch in list(self.r_avatar_slot.get_children()):
            self.r_avatar_slot.remove(ch)
        self.r_avatar_slot.add(avatar_widget(fname, 44))
        self.r_avatar_slot.show_all()

        # adjuntos
        for ch in list(self.att_row.get_children()):
            self.att_row.remove(ch)
        atts = self.db.q("SELECT * FROM attachments WHERE message_id=?", (m["id"],))
        if atts:
            for a in atts:
                chip = Gtk.Button()
                chip.get_style_context().add_class("att-chip")
                inner = Gtk.Box(spacing=6)
                inner.pack_start(icon_image("clip", 14), False, False, 0)
                nm = Gtk.Label(label=a["filename"])
                nm.get_style_context().add_class("att-name")
                inner.pack_start(nm, False, False, 0)
                sz = Gtk.Label(label=human_size(a["size"] or 0))
                sz.get_style_context().add_class("att-size")
                inner.pack_start(sz, False, False, 0)
                chip.add(inner)
                chip.connect("clicked", self.save_attachment, m["id"], a["id"])
                chip.show_all()
                self.att_row.pack_start(chip, False, False, 0)
            self.att_row.show()
        else:
            self.att_row.hide()

        # cuerpo: las imagenes externas se cargan solas, pero los rastreadores nunca
        block_all = self.db.get_setting("block_remote", "0") == "1"
        trusted = self.db.trusted(m["account_id"], (m["from_addr"] or "").lower())
        auto_load = (not block_all) or trusted
        width = max(300, self.body_view.get_allocated_width() - 60) or 560
        info = htmlview.render_message(self.body_view, m["body_text"], m["body_html"],
                                       load_images=auto_load, image_fetcher=self._image_fetcher,
                                       max_width=width)
        self._render_info = info
        self._render_width = width
        n_blocked = len(info.blocked_images)
        if n_blocked or info.tracking_pixels:
            parts = []
            if n_blocked and not auto_load:
                parts.append("%d imagen%s bloqueada%s" % (n_blocked, "es" if n_blocked != 1 else "",
                                                          "s" if n_blocked != 1 else ""))
            if info.tracking_pixels:
                parts.append("rastreo bloqueado (%d)" % info.tracking_pixels)
            if parts:
                self.info_lbl.set_text(" · ".join(parts))
                self.infobar.show()
                self.info_show_btn.set_visible(not auto_load and n_blocked > 0)
                self.info_always_btn.set_visible(not auto_load and n_blocked > 0)
            else:
                self.infobar.hide()
        else:
            self.infobar.hide()
        if auto_load and n_blocked:
            # faltan por descargar: en segundo plano y se re-renderiza (rastreadores nunca entran)
            self.load_remote_images(None)
        self.body_scroll.get_vadjustment().set_value(0)
        self.set_status("Listo")

    def _on_body_resize(self, widget, alloc):
        if not self.current_msg or not self._render_width:
            return
        width = max(300, alloc.width - 60)
        if abs(width - self._render_width) < 60:
            return
        if self._resize_src:
            GLib.source_remove(self._resize_src)
        self._resize_src = GLib.timeout_add(350, self._resize_rerender)

    def _resize_rerender(self):
        self._resize_src = 0
        if self.current_msg:
            self._show_message_reload(self.current_msg, True)
        return False

    def _image_fetcher(self, url, max_width):
        if url in self._image_cache:
            return self._image_cache[url]
        return None

    def load_remote_images(self, btn):
        if not self.current_msg:
            return
        m = self.db.one("SELECT * FROM messages WHERE id=?", (self.current_msg,))
        if not m:
            return
        srcs = [b["src"] for b in getattr(self, "_render_info", htmlview.RenderInfo()).blocked_images]
        if not srcs:
            return
        self.set_status("Cargando imágenes…")
        def work():
            for s in srcs:
                self._image_cache[s] = htmlview.fetch_image(s, max_width=900)
            while len(self._image_cache) > 60:  # caché acotada
                self._image_cache.pop(next(iter(self._image_cache)))
            GLib.idle_add(self._show_message_reload, m["id"], True)
        threading.Thread(target=work, daemon=True).start()

    def _show_message_reload(self, msg_id, trusted_once):
        if msg_id != self.current_msg:
            return
        m = self.db.one("SELECT * FROM messages WHERE id=?", (msg_id,))
        if not m:
            return
        cache = dict(self._image_cache)
        info = htmlview.render_message(self.body_view, m["body_text"], m["body_html"],
                                       load_images=True,
                                       image_fetcher=lambda u, w: cache.get(u),
                                       max_width=max(300, self.body_view.get_allocated_width() - 60) or 560)
        self._render_info = info
        self._render_width = max(300, self.body_view.get_allocated_width() - 60)
        if not info.blocked_images:
            if info.tracking_pixels:
                self.info_lbl.set_text("Rastreo bloqueado (%d)" % info.tracking_pixels)
                self.info_show_btn.hide()
                self.info_always_btn.hide()
                self.infobar.show()
            else:
                self.infobar.hide()
        self.set_status("Listo")

    def save_attachment(self, btn, msg_id, att_id):
        a = self.db.one("SELECT * FROM attachments WHERE id=?", (att_id,))
        m = self.db.one("SELECT * FROM messages WHERE id=?", (msg_id,))
        if not a or not m:
            return
        dlg = Gtk.FileChooserDialog("Guardar adjunto", self,
                                    Gtk.FileChooserAction.SAVE,
                                    ("Cancelar", Gtk.ResponseType.CANCEL,
                                     "Guardar", Gtk.ResponseType.ACCEPT))
        dlg.set_do_overwrite_confirmation(True)
        dlg.set_current_name(a["filename"] or "adjunto")
        dest = dlg.get_filename() if dlg.run() == Gtk.ResponseType.ACCEPT else None
        dlg.destroy()
        if not dest:
            return
        self.set_status("Guardando adjunto…")
        def work():
            try:
                if a["path"] and os.path.exists(a["path"]):
                    import shutil
                    shutil.copyfile(a["path"], dest)
                elif not DEMO:
                    folder = self.db.one("SELECT * FROM folders WHERE id=?", (m["folder_id"],))
                    acc = self._account(m["account_id"])
                    srcp = self.backend.download_attachment(acc, folder, m, a)
                    if not srcp:
                        GLib.idle_add(self.set_status, "No se pudo descargar el adjunto")
                        return
                    import shutil
                    shutil.copyfile(srcp, dest)
                else:
                    with open(dest, "wb") as f:
                        f.write(("Adjunto de demostraci\u00f3n: %s\n" % a["filename"]).encode("utf-8"))
                GLib.idle_add(self.set_status, "Adjunto guardado en " + dest)
            except Exception as e:
                GLib.idle_add(self.set_status, "Error al guardar el adjunto: " + str(e))
        threading.Thread(target=work, daemon=True).start()

    def trust_sender(self, btn):
        m = self.db.one("SELECT * FROM messages WHERE id=?", (self.current_msg,))
        if m and m["from_addr"]:
            self.db.trust(m["account_id"], m["from_addr"])
            self.load_remote_images(btn)

    def on_body_event(self, tv, event):
        ok, btn = event.get_button() if event.type == Gdk.EventType.BUTTON_RELEASE else (False, 0)
        if ok and btn == 1:
            x, y = tv.window_to_buffer_coords(Gtk.TextWindowType.TEXT, int(event.x), int(event.y))
            url = htmlview.link_at(tv, x, y)
            if url:
                if url.lower().startswith("mailto:"):
                    self.compose_new(None, to=url[7:])
                else:
                    subprocess.Popen(["xdg-open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def on_body_motion(self, tv, event):
        x, y = tv.window_to_buffer_coords(Gtk.TextWindowType.TEXT, int(event.x), int(event.y))
        url = htmlview.link_at(tv, x, y)
        win = tv.get_window(Gtk.TextWindowType.TEXT)
        if win:
            if url:
                if not self._cursor_link:
                    self._cursor_link = Gdk.Cursor.new_from_name(tv.get_display(), "pointer")
                win.set_cursor(self._cursor_link)
                tv.set_tooltip_text(url)
            else:
                win.set_cursor(None)
                tv.set_has_tooltip(False)

    def _restyle_row(self, row, msg_id):
        m = self.db.one("SELECT * FROM messages WHERE id=?", (msg_id,))
        if not m:
            return
        unread = not (m["flags"] & 1)
        ctx = row.get_style_context()
        if unread:
            ctx.add_class("msg-row-unread")
        else:
            ctx.remove_class("msg-row-unread")
        try:
            outer = row.get_child()
            col = outer.get_children()[1]
            line1 = col.get_children()[0]
            sender = line1.get_children()[0]
            subj = col.get_children()[1]
            for lbl, on_cls, off_cls in ((sender, "msg-sender-unread", "msg-sender"),
                                         (subj, "msg-subject-unread", "msg-subject")):
                lctx = lbl.get_style_context()
                if unread:
                    lctx.add_class(on_cls)
                    lctx.remove_class(off_cls)
                else:
                    lctx.remove_class(on_cls)
                    lctx.add_class(off_cls)
        except Exception:
            self.refresh_list()

    def _mark_read(self, m):
        self.db.run("UPDATE messages SET flags=flags|1 WHERE id=?", (m["id"],))
        folder = self.db.one("SELECT * FROM folders WHERE id=?", (m["folder_id"],))
        unseen = self.db.one("SELECT COUNT(*) c FROM messages WHERE folder_id=? AND (flags&1)=0",
                             (m["folder_id"],))["c"]
        self.db.run("UPDATE folders SET unseen=? WHERE id=?", (unseen, m["folder_id"]))
        row = self._msg_rows.get(m["id"])
        if row:
            self._restyle_row(row, m["id"])
        else:
            self.refresh_list()
        self.refresh_nav()
        self._touch_sig()
        if not DEMO:
            acc = self._account(m["account_id"])
            def work():
                try:
                    self.backend.set_flags(acc, folder, m["uid"], add=["\\Seen"])
                except Exception:
                    pass
            threading.Thread(target=work, daemon=True).start()

    # ---------- acciones ----------
    def _current(self):
        if not self.current_msg:
            return None, None
        m = self.db.one("SELECT * FROM messages WHERE id=?", (self.current_msg,))
        f = self.db.one("SELECT * FROM folders WHERE id=?", (m["folder_id"],)) if m else None
        return m, f

    def do_reply(self, b):
        m, _ = self._current()
        if m:
            ComposeWindow(self, self.backend, self.db, self._account(m["account_id"]),
                          reply_to=m, on_sent=self.sync_now)

    def do_reply_all(self, b):
        m, _ = self._current()
        if m:
            ComposeWindow(self, self.backend, self.db, self._account(m["account_id"]),
                          reply_to=m, reply_all=True, on_sent=self.sync_now)

    def do_forward(self, b):
        m, _ = self._current()
        if m:
            ComposeWindow(self, self.backend, self.db, self._account(m["account_id"]),
                          reply_to=m, forward=True, on_sent=self.sync_now)

    def _op_status(self, gen, text):
        # una operación antigua no pisa el estado de una acción posterior
        if gen == self._op_gen:
            self.set_status(text)

    def _op_failed(self, gen, keep_id, text):
        # si la operación remota falló, el mensaje sigue aquí: volver a él
        if gen != self._op_gen:
            return
        self._pending_select = keep_id
        self.set_status(text)

    def _load_msgs(self, ids):
        msgs = []
        for mid in ids:
            m = self.db.one("SELECT * FROM messages WHERE id=?", (mid,))
            if m:
                f = self.db.one("SELECT * FROM folders WHERE id=?", (m["folder_id"],))
                msgs.append((m, f))
        return msgs

    def do_delete(self, b):
        sel = self._selected_msg_ids()
        if len(sel) > 1 or (len(sel) == 1 and sel[0] != self.current_msg):
            self._delete_messages(self._load_msgs(sel), permanent=False)
            return
        m, f = self._current()
        if not m:
            self.set_status("Selecciona un mensaje antes de pulsar Supr")
            return
        self._delete_messages([(m, f)], permanent=False)

    def do_delete_permanent(self, b):
        sel = self._selected_msg_ids()
        if len(sel) > 1 or (len(sel) == 1 and sel[0] != self.current_msg):
            self._delete_messages(self._load_msgs(sel), permanent=True)
            return
        m, f = self._current()
        if not m:
            self.set_status("Selecciona un mensaje antes de pulsar Shift+Supr")
            return
        self._delete_messages([(m, f)], permanent=True)

    def _restore_message(self, row):
        cols = ("id", "account_id", "folder_id", "uid", "msgid", "ts", "from_name",
                "from_addr", "to_addrs", "cc_addrs", "subject", "preview", "flags",
                "has_attach", "size", "body_text", "body_html", "blocked", "categories", "urgent")
        self.db.run("INSERT OR REPLACE INTO messages(%s) VALUES(%s)" % (
            ",".join(cols), ",".join("?" for _ in cols)),
            tuple(row.get(c) for c in cols))

    def _delete_messages(self, msgs, permanent=False):
        # Borrado optimista: desaparecen al instante; la red va en segundo plano.
        if not msgs:
            return
        self._op_gen += 1
        gen = self._op_gen
        n = len(msgs)
        self.reader_stack.set_visible_child_name("empty")
        self._pending_select = self._next_msg_id(msgs[0][0]["id"])
        self.current_msg = None
        self._update_cmd_state()
        saved = [dict(m) for m, f in msgs]
        if DEMO:
            for m, f in msgs:
                trash = self.db.folder_by_special(m["account_id"], "trash")
                if not permanent and trash and f and f["special"] != "trash":
                    self.db.run("UPDATE messages SET folder_id=? WHERE id=?", (trash["id"], m["id"]))
                else:
                    self.db.run("DELETE FROM attachments WHERE message_id=?", (m["id"],))
                    self.db.run("DELETE FROM messages WHERE id=?", (m["id"],))
            self._remove_rows([m["id"] for m, f in msgs])
            self._recount_unseen(msgs[0][0]["account_id"])
            self.refresh_nav()
            self._op_status(gen, "Mensaje eliminado" if n == 1 else "%d mensajes eliminados" % n)
            return
        for m, f in msgs:
            trash = self.db.folder_by_special(m["account_id"], "trash")
            if not permanent and trash and f and f["special"] != "trash":
                self.db.run("DELETE FROM messages WHERE folder_id=? AND uid=? AND id!=?",
                            (trash["id"], m["uid"], m["id"]))
                self.db.run("UPDATE messages SET folder_id=? WHERE id=?", (trash["id"], m["id"]))
            else:
                self.db.run("DELETE FROM attachments WHERE message_id=?", (m["id"],))
                self.db.run("DELETE FROM messages WHERE id=?", (m["id"],))
        self._remove_rows([m["id"] for m, f in msgs])
        for aid in {m["account_id"] for m, f in msgs}:
            self._recount_unseen(aid)
        self.refresh_nav()
        self._op_status(gen, "Mensaje eliminado" if n == 1 else "%d mensajes eliminados" % n)
        def work():
            groups = {}
            for (m, f), row in zip(msgs, saved):
                groups.setdefault((m["account_id"], f["id"] if f else None), []).append((m, row))
            for (acc_id, fid), items in groups.items():
                try:
                    acc = self._account(acc_id)
                    f0 = self.db.one("SELECT * FROM folders WHERE id=?", (fid,))
                    self.backend.delete_messages_remote(acc, f0, [m for m, row in items], permanent=permanent)
                    for m, row in items:
                        self.db.run("DELETE FROM attachments WHERE message_id=?", (m["id"],))
                except Exception as e:
                    for m, row in items:
                        try:
                            self._restore_message(row)
                        except Exception:
                            pass
                    GLib.idle_add(self.refresh_list)
                    GLib.idle_add(self.refresh_nav)
                    GLib.idle_add(self.set_status, "Error al eliminar: " + str(e))
        threading.Thread(target=work, daemon=True).start()

    def do_archive(self, b):
        self._op_gen += 1
        gen = self._op_gen
        m, f = self._current()
        if not m:
            return
        self.set_status("Archivando…")
        self.reader_stack.set_visible_child_name("empty")
        self._pending_select = self._next_msg_id(m["id"])
        self.current_msg = None
        self._update_cmd_state()
        def work():
            ok = True
            if not DEMO:
                try:
                    acc = self._account(m["account_id"])
                    self.backend.archive_message(acc, f, m)
                except Exception as e:
                    ok = False
                    GLib.idle_add(self._op_failed, gen, m["id"], "Error al archivar: " + str(e))
            else:
                arch = self.db.folder_by_special(m["account_id"], "archive")
                if arch:
                    self.db.run("DELETE FROM messages WHERE folder_id=? AND uid=? AND id!=?",
                                (arch["id"], m["uid"], m["id"]))
                    self.db.run("UPDATE messages SET folder_id=? WHERE id=?", (arch["id"], m["id"]))
            GLib.idle_add(self.refresh_list)
            GLib.idle_add(self.refresh_nav)
            if ok:
                GLib.idle_add(self._op_status, gen, "Mensaje archivado")
        threading.Thread(target=work, daemon=True).start()

    def do_junk(self, b):
        m, f = self._current()
        if not m:
            return
        junk = self.db.folder_by_special(m["account_id"], "junk")
        if not junk:
            self.set_status("Esta cuenta no tiene carpeta de correo no deseado")
            return
        self._move_to_folder(m, f, junk, "Movido a Correo no deseado")

    def do_move_to(self, item, folder):
        m, f = self._current()
        if not m or not folder:
            return
        self._move_to_folder(m, f, folder, "Movido a " + folder["name"])

    def _move_to_folder(self, m, f, dest, ok_text):
        self._op_gen += 1
        gen = self._op_gen
        self.set_status("Moviendo…")
        self.reader_stack.set_visible_child_name("empty")
        gone = m["id"]
        self._pending_select = self._next_msg_id(gone)
        self.current_msg = None
        self._update_cmd_state()
        def work():
            if not DEMO:
                try:
                    acc = self._account(m["account_id"])
                    self.backend.move_message(acc, f, m["uid"], dest["remote"])
                except Exception as e:
                    GLib.idle_add(self._op_failed, gen, gone, "Error al mover: " + str(e))
                    GLib.idle_add(self.refresh_list)
                    GLib.idle_add(self.refresh_nav)
                    return
            self.db.run("DELETE FROM messages WHERE folder_id=? AND uid=? AND id!=?",
                        (dest["id"], m["uid"], gone))
            self.db.run("UPDATE messages SET folder_id=? WHERE id=?", (dest["id"], gone))
            GLib.idle_add(self.refresh_list)
            GLib.idle_add(self.refresh_nav)
            GLib.idle_add(self._op_status, gen, ok_text)
        threading.Thread(target=work, daemon=True).start()

    def _fill_move_menu(self, menu):
        m, f = self._current()
        if m:
            folders = self.db.folders(m["account_id"])
            folders = sorted(folders, key=lambda x: (FOLDER_ORDER.get(x["special"], 50), x["name"]))
            for fo in folders:
                if f and fo["id"] == f["id"]:
                    continue
                mi = Gtk.MenuItem(label=fo["name"])
                mi.connect("activate", self.do_move_to, fo)
                menu.append(mi)

    def _fill_cat_menu(self, menu):
        m, f = self._current()
        current = set()
        if m:
            current = set(c for c in (m["categories"] or "").split(",") if c)
        for name, colr in CATEGORIES:
            mi = Gtk.CheckMenuItem()
            bx = Gtk.Box(spacing=6)
            dot = Gtk.Label()
            dot.set_markup('<span foreground="%s">●</span>' % colr)
            bx.pack_start(dot, False, False, 0)
            bx.pack_start(Gtk.Label(label=name), False, False, 0)
            mi.add(bx)
            mi.set_active(name in current)
            mi.connect("toggled", self._toggle_category, name)
            menu.append(mi)

    def _toggle_category(self, item, name):
        m, f = self._current()
        if not m:
            return
        cats = set(c for c in (m["categories"] or "").split(",") if c)
        if item.get_active():
            cats.add(name)
        else:
            cats.discard(name)
        self.db.set_categories(m["id"], sorted(cats))
        self.refresh_list()

    def do_mark_unread(self, b):
        m, f = self._current()
        if not m:
            return
        self.db.run("UPDATE messages SET flags=flags&~1 WHERE id=?", (m["id"],))
        row = self._msg_rows.get(m["id"])
        if row:
            self._restyle_row(row, m["id"])
        else:
            self.refresh_list()
        self.refresh_nav()
        if not DEMO:
            acc = self._account(m["account_id"])
            threading.Thread(target=lambda: self._safe_flags(acc, f, m["uid"], remove=["\\Seen"]),
                             daemon=True).start()

    def do_flag(self, b):
        m, f = self._current()
        if not m:
            return
        on = not (m["flags"] & 2)
        if on:
            self.db.run("UPDATE messages SET flags=flags|2 WHERE id=?", (m["id"],))
        else:
            self.db.run("UPDATE messages SET flags=flags&~2 WHERE id=?", (m["id"],))
        self.refresh_list()
        if not DEMO:
            acc = self._account(m["account_id"])
            kw = {"add": ["\\Flagged"]} if on else {"remove": ["\\Flagged"]}
            threading.Thread(target=lambda: self._safe_flags(acc, f, m["uid"], **kw), daemon=True).start()

    def do_block_sender(self, item):
        m, f = self._current()
        if not m or not m["from_addr"]:
            return
        addr = m["from_addr"]
        self.db.block(m["account_id"], addr)
        self.set_status("Remitente bloqueado: " + addr + " · sus correos van a «Correo no deseado»")
        acc = self._account(m["account_id"])
        junk = self.db.folder_by_special(m["account_id"], "junk")
        rows = self.db.q("""SELECT * FROM messages WHERE account_id=? AND lower(from_addr)=?
                            AND folder_id != ?""",
                         (m["account_id"], addr.lower(), junk["id"] if junk else -1))
        def work():
            for r in rows:
                rf = self.db.one("SELECT * FROM folders WHERE id=?", (r["folder_id"],))
                if not DEMO and acc and junk and rf:
                    try:
                        self.backend.move_message(acc, rf, r["uid"], junk["remote"])
                    except Exception:
                        pass
                if junk:
                    self.db.run("DELETE FROM messages WHERE folder_id=? AND uid=? AND id!=?",
                                (junk["id"], r["uid"], r["id"]))
                    self.db.run("UPDATE messages SET folder_id=? WHERE id=?", (junk["id"], r["id"]))
            GLib.idle_add(self.refresh_list)
            GLib.idle_add(self.refresh_nav)
        threading.Thread(target=work, daemon=True).start()

    def _safe_flags(self, acc, f, uid, **kw):
        try:
            self.backend.set_flags(acc, f, uid, **kw)
        except Exception:
            pass

    # ---------- cuentas y ajustes ----------
    def on_account_clicked(self, btn, acc_id):
        self.current_account = acc_id
        self.current_folder = None
        self.current_msg = None
        self.refresh_nav()
        self.refresh_list()

    def on_folder_clicked(self, btn, folder_id):
        self.current_folder = folder_id
        self.current_msg = None
        self._update_cmd_state()
        self.refresh_nav()
        self.reader_stack.set_visible_child_name("empty")
        self.refresh_list()
        self.msg_list.grab_focus()

    def add_account(self, btn):
        AddAccountDialog(self, self.db, self._account_added)

    def _account_added(self, acc_id):
        self.current_account = acc_id
        self.current_folder = None
        self.refresh_nav()
        self.reader_stack.set_visible_child_name("empty")
        self.refresh_list()
        self.sync_now()

    def relogin(self):
        self.error_bar.hide()
        self.add_account(None)

    def open_settings(self, btn):
        SettingsDialog(self, self.db, self._accounts_changed, self.check_updates)

    def _accounts_changed(self):
        accounts = self.db.accounts()
        if not accounts:
            self.current_account = None
            self.current_folder = None
            self.refresh_nav()
            self.refresh_list()
            return
        if self.current_account not in [a.id for a in accounts]:
            self.current_account = accounts[0].id
            self.current_folder = None
        self.refresh_nav()
        self.refresh_list()

    # ---------- sincronizacion ----------
    def after_first_show(self):
        if self.db.accounts():
            self.sync_now()
        GLib.timeout_add_seconds(int(self.db.get_setting("sync_minutes", "2")) * 60, self._auto_sync)

    def _auto_sync(self):
        self.sync_now()
        GLib.timeout_add_seconds(int(self.db.get_setting("sync_minutes", "2")) * 60, self._auto_sync)
        return False

    def check_updates(self, lbl):
        lbl.set_text("Buscando…")
        def work():
            m = updater.check_for_update()
            if not m:
                GLib.idle_add(lbl.set_text, "Ya tienes la última versión.")
                return
            dest = updater.apply_update(m)
            if dest:
                GLib.idle_add(lbl.set_text, "Actualización %s instalada. Reinicia Email para empezar a usarla." % m["version"])
            else:
                GLib.idle_add(lbl.set_text, "No se pudo verificar la actualización (firma no válida).")
        threading.Thread(target=work, daemon=True).start()

    def sync_now(self):
        if self._syncing or DEMO:
            if DEMO:
                self.refresh_list()
                self.refresh_nav()
            return
        accounts = self.db.accounts()
        if not accounts:
            return
        self._syncing = True
        self._sync_ui(True)
        self.set_status("Sincronizando…")
        def work():
            any_err = None
            try:
                for acc in accounts:
                    try:
                        ok = self.backend.sync_account(acc)
                    except Exception as e:
                        ok = False
                        self.backend.last_errors[acc.id] = str(e)
                    if not ok:
                        any_err = (acc, self.backend.last_errors.get(acc.id, ""))
            finally:
                GLib.idle_add(self._sync_done, any_err)
        threading.Thread(target=work, daemon=True).start()

    def _sync_ui(self, on):
        if on:
            self.sync_stack.set_visible_child(self.sync_spin)
            self.sync_spin.start()
            self.sync_btn.set_sensitive(False)
        else:
            self.sync_spin.stop()
            self.sync_stack.set_visible_child(self.sync_icon_img)
            self.sync_btn.set_sensitive(True)

    def _sync_done(self, any_err):
        self._syncing = False
        self._sync_ui(False)
        sig = self._list_signature()
        if sig != self._last_list_sig:
            self._last_list_sig = sig
            self.refresh_nav()
            self.refresh_list()
        if any_err:
            acc, msg = any_err
            a = self._account(acc.id)
            if a and a.state == "login":
                self.error_lbl.set_text("La sesión de %s ha caducado (%s). Inicia sesión de nuevo." % (acc.email, msg or "sin sesión"))
                self.relogin_btn.show()
            else:
                self.error_lbl.set_text("No se pudo sincronizar %s: %s" % (acc.email, msg or "sin conexión"))
                self.relogin_btn.hide()
            self.error_lbl.show()
            self.error_bar.show()
            self.set_status("Error: " + (msg or "sin conexión"))
        else:
            self.error_bar.hide()
            self.set_status("Sincronizado · " + time.strftime("%H:%M"))

    def compose_new(self, btn, to=None):
        if not self.current_account:
            self.add_account(None)
            return
        w = ComposeWindow(self, self.backend, self.db, self._account(self.current_account),
                          on_sent=self.sync_now)
        if to:
            w.to_entry.set_text(to)

    def set_status(self, text):
        self.status_lbl.set_text(text)


def _migrate_dirs():
    """Primera ejecucion como Email: copia la configuracion/datos de 'correo' si existen."""
    import shutil
    home = os.path.expanduser("~")
    pairs = [((".config", "correo"), (".config", "email")),
             ((".local", "share", "correo"), (".local", "share", "email"))]
    for old, new in pairs:
        o = os.path.join(home, *old)
        n = os.path.join(home, *new)
        if os.path.isdir(o) and not os.path.exists(n):
            try:
                shutil.copytree(o, n)
            except OSError:
                pass

def main():
    _migrate_dirs()
    app = CorreoApp()
    app.run(sys.argv)

if __name__ == "__main__":
    main()
