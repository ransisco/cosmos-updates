# -*- coding: utf-8 -*-
"""Render de correo HTML en Gtk.TextView, pensado para privacidad:
nunca carga recursos remotos salvo peticion expresa, elimina pixeles de
seguimiento y limpia parametros rastreadores de los enlaces."""
import base64, io, re, urllib.parse, urllib.request
from html.parser import HTMLParser

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Gdk, GdkPixbuf, GLib, Pango

TRACK_PARAMS = {"utm_source","utm_medium","utm_campaign","utm_term","utm_content","utm_id",
    "utm_name","utm_cid","utm_reader","utm_referrer","utm_social","utm_social-type","utm_brand",
    "fbclid","gclid","gclsrc","dclid","gbraid","wbraid","msclkid","twclid","mc_cid","mc_eid",
    "igshid","spm","ref_src","_hsenc","_hsmi","hsCtaTracking","mkt_tok","vero_id","vero_conv",
    "wickedid","oly_enc_id","rb_clickid","s_cid","ss_email_id","campaign_id","subscriber_id",
    "email_id","nltr","trk","tracking","clickid","icid","sc_src","sc_channel","sc_campaign",
    "sc_content","sc_medium","sc_outcome","wt_mc","pk_campaign","pk_kwd","pk_source","matomo_campaign"}

def strip_tracking(url):
    try:
        if not url or url.startswith("mailto:") or url.startswith("data:") or url.startswith("cid:"):
            return url
        p = urllib.parse.urlparse(url)
        if not p.query:
            return url
        qs = [(k, v) for k, v in urllib.parse.parse_qsl(p.query, keep_blank_values=True)
              if k.lower() not in TRACK_PARAMS]
        new = urllib.parse.urlunparse(p._replace(query=urllib.parse.urlencode(qs)))
        return new
    except Exception:
        return url

# endpoints tipicos de seguimiento de apertura/clic (no se cargan nunca)
TRACKER_HOSTS = ("mailtrack", "mixmax", "google-analytics.com", "doubleclick",
                 "analytics.", "/collect", "t.paypal.com/ts", "t.salesforce",
                 "list-manage.com/track", "sendgrid", "/wf/open", "click.icptrack",
                 "mailgun", "postmark", "hubspot", "marketo", "braze", "iterable")
TRACKER_PATH_RE = re.compile(
    r"/(?:open|track|tracking|beacon|pixel|o|ts|e)(?:\.gif|\.png|\.jpg)?(?:[?/]|$)", re.I)

def is_tracker_url(url):
    u = (url or "").lower()
    if not u:
        return False
    for h in TRACKER_HOSTS:
        if h in u:
            return True
    try:
        p = urllib.parse.urlparse(u)
    except Exception:
        return False
    if TRACKER_PATH_RE.search(p.path or ""):
        return True
    if TRACKER_PATH_RE.search((p.path or "") + "?" + (p.query or "")):
        return True
    return False

def _style_dict(style):
    out = {}
    for part in (style or "").split(";"):
        if ":" in part:
            k, v = part.split(":", 1)
            out[k.strip().lower()] = v.strip()
    return out

def _px(v):
    m = re.match(r"(\d+(?:\.\d+)?)(px|pt)?", (v or "").strip())
    return float(m.group(1)) if m else None

class RenderInfo:
    def __init__(self):
        self.blocked_images = []   # dicts: {src, anchor, widget}
        self.tracking_pixels = 0
        self.inline_data = 0

class HtmlMailRenderer(HTMLParser):
    def __init__(self, textview, load_images=False, image_fetcher=None, max_width=620):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.tv = textview
        self.buf = textview.get_buffer()
        self.load_images = load_images
        self.image_fetcher = image_fetcher
        self.max_width = max_width
        self.info = RenderInfo()
        self.tag_stack = []
        self.skip_depth = 0
        self.list_stack = []
        self.link_stack = []
        self.heading_scale = 0.0
        self.pre = False
        self.blockquote = 0
        self.cell_bold = False
        self.center = 0
        self.right = 0
        self.colors = []
        self.sizes = []
        self.bold = 0
        self.italic = 0
        self.underline = 0
        self.strike = 0
        self.mono = 0
        self.links = []  # (start, end, url)
        self._marks = []
        self._pending_space = False

    # ---------- utilidades ----------
    def _offset(self):
        return self.buf.get_end_iter().get_offset()

    def _mark(self):
        return self.buf.create_mark(None, self.buf.get_end_iter(), True)

    def _insert(self, text):
        if not text:
            return
        tags = []
        b = self.buf
        if self.bold or self.cell_bold:
            tags.append(b.get_tag_table().lookup("b"))
        if self.italic:
            tags.append(b.get_tag_table().lookup("i"))
        if self.underline:
            tags.append(b.get_tag_table().lookup("u"))
        if self.strike:
            tags.append(b.get_tag_table().lookup("s"))
        if self.mono or self.pre:
            tags.append(b.get_tag_table().lookup("mono"))
        if self.heading_scale:
            key = "h%g" % self.heading_scale
            tags.append(b.get_tag_table().lookup(key))
        if self.blockquote:
            tags.append(b.get_tag_table().lookup("quote"))
        if self.colors:
            tname = "c" + self.colors[-1].lstrip("#")
            tags.append(self._color_tag(tname, self.colors[-1]))
        if self.link_stack:
            tags.append(b.get_tag_table().lookup("link"))
        tags = [t for t in tags if t]
        if self.pre:
            b.insert_with_tags(b.get_end_iter(), text, *tags) if tags else b.insert(b.get_end_iter(), text)
            return
        lead = re.match(r"^[ \t\r\n]+", text)
        if lead and self._offset() > 0:
            prev = b.get_text(b.get_iter_at_offset(self._offset() - 1), b.get_end_iter(), False)
            if prev not in (" ", "\n", "\ufffc"):
                b.insert(b.get_end_iter(), " ")
        text = re.sub(r"[ \t\r\n]+", " ", text)
        if not text or (text == " " and self._offset() == 0):
            return
        self._pending_space = text.endswith(" ")
        if tags:
            b.insert_with_tags(b.get_end_iter(), text, *tags)
        else:
            b.insert(b.get_end_iter(), text)

    def _color_tag(self, name, css_color):
        tt = self.buf.get_tag_table()
        t = tt.lookup(name)
        if not t:
            t = self.buf.create_tag(name, foreground=css_color if self._valid_color(css_color) else None)
            if not self._valid_color(css_color):
                t = tt.lookup("b") or t
        return t

    @staticmethod
    def _valid_color(c):
        if not c:
            return False
        c = c.strip()
        m = re.match(r"^#([0-9a-fA-F]{6})", c)
        if m:
            v = m.group(1)
            r, g, b = int(v[0:2], 16), int(v[2:4], 16), int(v[4:6], 16)
            if (0.299 * r + 0.587 * g + 0.114 * b) / 255.0 > 0.93:
                return False
        if c.lower() in ("white", "#fff"):
            return False
        return bool(re.match(r"^(#[0-9a-fA-F]{3,8}|rgb\(.*\)|[a-zA-Z]+)$", c))

    def _newline(self, n=1):
        cur = self.buf.get_end_iter()
        txt_start = 0
        existing = self.buf.get_text(self.buf.get_iter_at_offset(max(0, cur.get_offset() - 3)), cur, False)
        need = n - existing.count("\n")
        for _ in range(max(0, need)):
            self.buf.insert(self.buf.get_end_iter(), "\n")
        self._pending_space = False

    def _trim_nl(self):
        # quita saltos de linea extra al final
        it = self.buf.get_end_iter()
        while it.get_offset() > 0:
            prev = it.copy(); prev.backward_char()
            if prev.get_char() == "\n":
                self.buf.delete(prev, it)
                it = self.buf.get_end_iter()
            else:
                break

    # ---------- parser ----------
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        st = _style_dict(a.get("style"))
        disp = st.get("display", "").lower()
        vis = st.get("visibility", "").lower()
        if disp == "none" or vis == "hidden":
            self.skip_depth += 1
            self.tag_stack.append(("__skip", None))
            return
        if tag in ("meta", "link", "base", "input"):
            return  # elementos void: sin contenido ni cierre; no apilan
        if tag in ("script", "style", "head", "title", "noscript", "iframe",
                   "object", "embed", "form", "button", "select", "textarea", "svg"):
            self.skip_depth += 1
            self.tag_stack.append(("__skip", None))
            return
        self.tag_stack.append((tag, (a, st)))
        if tag in ("p", "div", "section", "article", "header", "footer", "table", "tr",
                   "h1", "h2", "h3", "h4", "h5", "h6", "blockquote", "ul", "ol", "pre", "hr", "body", "center", "td", "th", "caption"):
            self._newline(2 if tag in ("p", "table") else 1)
        if tag in ("b", "strong"):
            self.bold += 1
        elif tag in ("i", "em"):
            self.italic += 1
        elif tag == "u":
            self.underline += 1
        elif tag in ("s", "del", "strike"):
            self.strike += 1
        elif tag in ("code", "kbd", "tt"):
            self.mono += 1
        elif tag == "pre":
            self.pre = True
        elif tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            self.bold += 1
            self.heading_scale = {"h1": 1.7, "h2": 1.45, "h3": 1.25, "h4": 1.12, "h5": 1.05, "h6": 1.0}[tag]
        elif tag == "blockquote":
            self.blockquote += 1
        elif tag == "center":
            self.center += 1
        elif tag == "ul":
            self.list_stack.append(["ul", 0])
        elif tag == "ol":
            self.list_stack.append(["ol", 0])
        elif tag == "li":
            if self.list_stack:
                top = self.list_stack[-1]
                top[1] += 1
                bullet = ("%d. " % top[1]) if top[0] == "ol" else "\u2022 "
                self._newline(1)
                self._insert("  " * (len(self.list_stack) - 1) + bullet)
            else:
                self._newline(1)
                self._insert("\u2022 ")
        elif tag == "a":
            href = a.get("href", "")
            if href:
                self.link_stack.append((strip_tracking(href), self._mark()))
        elif tag == "img":
            self._img(a, st)
        elif tag == "hr":
            self._newline(1)
            self._insert("\u2500" * 40)
            self._newline(1)
        elif tag == "br":
            self.buf.insert(self.buf.get_end_iter(), "\n")
            self._pending_space = False
        elif tag == "th":
            self.cell_bold = True
        elif tag in ("td", "th"):
            pass
        elif tag == "span" or tag == "font":
            col = st.get("color") or (a.get("color") if tag == "font" else None)
            if col:
                self.colors.append(col)
            else:
                self.colors.append(None)
        if st.get("color") and tag not in ("span", "font"):
            self.colors.append(st["color"])
        align = (st.get("text-align") or a.get("align") or "").lower()
        if align == "center":
            self.center += 1
        elif align == "right":
            self.right += 1

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if not self.tag_stack:
            return
        # pop hasta el tag correspondiente
        popped = []
        while self.tag_stack:
            t, saved = self.tag_stack.pop()
            popped.append((t, saved))
            if t == tag or (t == "__skip" and tag in ("script", "style", "head", "title",
                                                      "noscript", "iframe", "object", "embed", "form",
                                                      "button", "select", "textarea", "svg")):
                break
        for t, saved in popped:
            if t == "__skip":
                self.skip_depth = max(0, self.skip_depth - 1)
                continue
            if t in ("b", "strong"):
                self.bold = max(0, self.bold - 1)
            elif t in ("i", "em"):
                self.italic = max(0, self.italic - 1)
            elif t == "u":
                self.underline = max(0, self.underline - 1)
            elif t in ("s", "del", "strike"):
                self.strike = max(0, self.strike - 1)
            elif t in ("code", "kbd", "tt"):
                self.mono = max(0, self.mono - 1)
            elif t == "pre":
                self.pre = False
            elif t in ("h1", "h2", "h3", "h4", "h5", "h6"):
                self.bold = max(0, self.bold - 1)
                self.heading_scale = 0.0
                self._newline(1)
            elif t == "blockquote":
                self.blockquote = max(0, self.blockquote - 1)
            elif t == "center":
                self.center = max(0, self.center - 1)
            elif t in ("ul", "ol"):
                if self.list_stack:
                    self.list_stack.pop()
                self._newline(1)
            elif t == "a":
                if self.link_stack:
                    url, mark = self.link_stack.pop()
                    self.links.append((self.buf.get_iter_at_mark(mark).get_offset(), self._offset(), url))
            elif t in ("td", "th"):
                self.cell_bold = False
                self._insert("   ")
            elif t == "tr":
                self._newline(1)
            elif t in ("span", "font"):
                if self.colors:
                    self.colors.pop()
            if saved and saved[1].get("color") and t not in ("span", "font"):
                if self.colors:
                    self.colors.pop()
            if saved:
                align = (saved[1].get("text-align") or saved[0].get("align") or "").lower()
                if align == "center":
                    self.center = max(0, self.center - 1)
                elif align == "right":
                    self.right = max(0, self.right - 1)
            if t in ("p", "div", "table", "section", "article"):
                self._newline(1 if t != "p" and t != "table" else 2)

    def handle_data(self, data):
        if self.skip_depth:
            return
        self._insert(data)

    def _img(self, a, st):
        src = a.get("src", "")
        if not src:
            return
        w = _px(a.get("width") or st.get("width"))
        h = _px(a.get("height") or st.get("height"))
        if (w is not None and w <= 2) or (h is not None and h <= 2):
            self.info.tracking_pixels += 1
            return
        if src.startswith("data:"):
            self._inline_data_img(src)
            return
        if src.startswith("cid:"):
            return  # adjunta en linea: sin resolver aqui
        if src.startswith(("http://", "https://")):
            src = strip_tracking(src)
        if src.startswith(("http://", "https://")) and is_tracker_url(src):
            self.info.tracking_pixels += 1
            return
        if self.load_images and self.image_fetcher:
            pb = self.image_fetcher(src, self.max_width)
            if pb and pb.get_width() <= 2 and pb.get_height() <= 2:
                self.info.tracking_pixels += 1
                return
            if pb:
                target = self.max_width
                if w is not None and w > 2:
                    target = min(int(w), self.max_width)
                if pb.get_width() > target:
                    pb = scale_pixbuf(pb, target)
                anchor = self.buf.create_child_anchor(self.buf.get_end_iter())
                img = Gtk.Image.new_from_pixbuf(pb)
                img.set_halign(Gtk.Align.START)
                img.set_margin_top(6)
                img.set_margin_bottom(6)
                self.tv.add_child_at_anchor(img, anchor)
                img.show()
                self.buf.insert(self.buf.get_end_iter(), "\n")
                return
        # bloqueada: placeholder
        anchor = self.buf.create_child_anchor(self.buf.get_end_iter())
        box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        box.get_style_context().add_class("img-placeholder")
        lbl = Gtk.Label(label="\U0001F5BC  Imagen externa bloqueada")
        lbl.get_style_context().add_class("img-placeholder-label")
        box.pack_start(lbl, False, False, 8)
        box.set_margin_top(4)
        box.set_margin_bottom(4)
        self.tv.add_child_at_anchor(box, anchor)
        box.show_all()
        self.buf.insert(self.buf.get_end_iter(), "\n")
        self.info.blocked_images.append({"src": src, "anchor": anchor, "widget": box})

    def _inline_data_img(self, src):
        m = re.match(r"data:(image/[a-zA-Z0-9.+-]+);base64,(.*)", src, re.S)
        if not m:
            return
        try:
            raw = base64.b64decode(re.sub(r"\s+", "", m.group(2)))
            if len(raw) > 4 * 1024 * 1024:
                return
            loader = GdkPixbuf.PixbufLoader.new_with_mime_type(m.group(1))
            loader.write(raw)
            loader.close()
            pb = loader.get_pixbuf()
            if not pb:
                return
            pb = scale_pixbuf(pb, self.max_width)
            anchor = self.buf.create_child_anchor(self.buf.get_end_iter())
            img = Gtk.Image.new_from_pixbuf(pb)
            img.set_halign(Gtk.Align.START)
            self.tv.add_child_at_anchor(img, anchor)
            img.show()
            self.info.inline_data += 1
        except Exception:
            pass

    def finish(self):
        self._trim_nl()
        # justificacion por parrafos centrados/derecha: aproximacion global
        if self.center and not self.left_text():
            pass
        return self.info

    def left_text(self):
        return False

def scale_pixbuf(pb, max_width):
    w, h = pb.get_width(), pb.get_height()
    if w <= max_width:
        return pb
    nh = max(1, int(h * max_width / w))
    return pb.scale_simple(max_width, nh, GdkPixbuf.InterpType.BILINEAR)

def fetch_image(url, max_width=620, timeout=15):
    try:
        if not url.lower().startswith(("http://", "https://")):
            return None
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 Email/2.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            ctype = (r.headers.get("Content-Type") or "").split(";")[0].strip().lower()
            if not ctype.startswith("image/"):
                return None
            data = r.read(6 * 1024 * 1024)
        loader = GdkPixbuf.PixbufLoader()
        loader.write(data)
        loader.close()
        pb = loader.get_pixbuf()
        return scale_pixbuf(pb, max_width) if pb else None
    except Exception:
        return None

def setup_tags(buf):
    buf.create_tag("b", weight=Pango.Weight.BOLD)
    buf.create_tag("i", style=Pango.Style.ITALIC)
    buf.create_tag("u", underline=Pango.Underline.SINGLE)
    buf.create_tag("s", strikethrough=True)
    buf.create_tag("mono", family="monospace")
    buf.create_tag("quote", left_margin=18, foreground="#5a5a5a", style=Pango.Style.ITALIC)
    buf.create_tag("link", foreground="#0067b8", underline=Pango.Underline.SINGLE)
    for scale, name in ((1.7, "h1.7"), (1.45, "h1.45"), (1.25, "h1.25"), (1.12, "h1.12"), (1.05, "h1.05")):
        buf.create_tag(name, scale=scale)

LINK_RE = re.compile(r"(https?://[^\s<>'\"()\[\]]+)")

def render_message(textview, body_text, body_html, load_images=False, image_fetcher=None, max_width=620):
    """Renderiza texto o HTML; devuelve RenderInfo."""
    buf = textview.get_buffer()
    buf.set_text("")
    setup_tags(buf)
    if body_html:
        r = HtmlMailRenderer(textview, load_images=load_images, image_fetcher=image_fetcher,
                             max_width=max_width)
        try:
            r.feed(body_html)
            r.close()
        except Exception:
            pass
        info = r.finish()
        _apply_links(buf, r.links)
        return info
    info = RenderInfo()
    text = body_text or ""
    pos = 0
    links = []
    for m in LINK_RE.finditer(text):
        if m.start() > pos:
            buf.insert(buf.get_end_iter(), text[pos:m.start()])
        url = strip_tracking(m.group(1))
        start = buf.get_end_iter().get_offset()
        buf.insert_with_tags(buf.get_end_iter(), m.group(1), buf.get_tag_table().lookup("link"))
        links.append((start, buf.get_end_iter().get_offset(), url))
        pos = m.end()
    if pos < len(text):
        buf.insert(buf.get_end_iter(), text[pos:])
    _apply_links(buf, links)
    return info

def _apply_links(buf, links):
    for start, end, url in links:
        tag = buf.create_tag(None, foreground="#0067b8", underline=Pango.Underline.SINGLE)
        tag.set_data = None
        tag._url = url
        buf.apply_tag(tag, buf.get_iter_at_offset(start), buf.get_iter_at_offset(end))

def link_at(textview, x, y):
    ok, it = textview.get_iter_at_location(x, y)
    if not ok:
        return None
    for tag in it.get_tags():
        url = getattr(tag, "_url", None)
        if url:
            return url
    return None
