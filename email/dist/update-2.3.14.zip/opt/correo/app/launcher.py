# -*- coding: utf-8 -*-
# Compatibilidad: la app se llama ahora Email. Redirige al lanzador nuevo.
import os, sys
os.execv(sys.executable, [sys.executable, "/opt/email/app/launcher.py"] + sys.argv[1:])
