#!/bin/sh
# Compatibilidad: la app se llama ahora Email. Redirige al lanzador nuevo.
exec /opt/email/app/run.sh "$@"
