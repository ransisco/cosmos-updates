#!/bin/sh
exec python3 /opt/email/app/launcher.py "$@"
