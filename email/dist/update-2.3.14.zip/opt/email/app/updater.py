# -*- coding: utf-8 -*-
"""Auto-actualizacion firmada contra el repo publico de GitHub (ransisco/cosmos-updates).
manifest.json: {version, url, sha256, notes, sig}
sig = RSA-SHA256 (PKCS1v15) en base64 sobre "correo\\n<version>\\n<sha256>\\n<url>\\n"."""
import base64, hashlib, json, os, shutil, subprocess, tempfile, urllib.request, zipfile

APP_ID = "email"
MANIFEST_URL = "https://raw.githubusercontent.com/ransisco/cosmos-updates/main/email/manifest.json"
UPDATES_DIR = os.path.join(os.path.expanduser("~"), ".local", "share", "email", "updates")
BASE_DIR = "/opt/email/app"

def _pub_key_path():
    here = os.path.dirname(os.path.abspath(__file__))
    p = os.path.join(here, "update_pub.pem")
    if os.path.exists(p):
        return p
    return "/opt/email/app/update_pub.pem"

def current_version():
    here = os.path.dirname(os.path.abspath(__file__))
    try:
        with open(os.path.join(here, "version.txt")) as f:
            return f.read().strip()
    except OSError:
        return "0.0.0"

def _ver_tuple(v):
    return tuple(int(x) for x in re_split(v))

def re_split(v):
    return [x for x in v.replace("-", ".").split(".") if x.isdigit()][:4] or ["0"]

def fetch_manifest(timeout=20):
    req = urllib.request.Request(MANIFEST_URL + "?t=" + str(int(__import__("time").time())),
                                 headers={"User-Agent": "correo-updater"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())

def verify_signature(manifest):
    payload = ("%s\n%s\n%s\n%s\n" % (APP_ID, manifest["version"], manifest["sha256"], manifest["url"])).encode()
    sig = base64.b64decode(manifest["sig"])
    with tempfile.NamedTemporaryFile(delete=False, suffix=".sig") as sf:
        sf.write(sig)
        sig_path = sf.name
    with tempfile.NamedTemporaryFile(delete=False) as pf:
        pf.write(payload)
        payload_path = pf.name
    try:
        p = subprocess.run(["openssl", "dgst", "-sha256", "-verify", _pub_key_path(),
                            "-signature", sig_path, payload_path],
                           capture_output=True, timeout=30)
        return p.returncode == 0
    finally:
        os.remove(sig_path)
        os.remove(payload_path)

def check_for_update():
    """Devuelve dict con info de actualizacion o None si no hay/error."""
    try:
        m = fetch_manifest()
        if _ver_tuple(m["version"]) <= _ver_tuple(current_version()):
            return None
        return m
    except Exception:
        return None

def apply_update(manifest):
    """Descarga, verifica sha256 y firma, extrae a updates/<version>. Devuelve dir o None."""
    url = manifest["url"]
    req = urllib.request.Request(url + ("&" if "?" in url else "?") + "t=" + str(int(__import__("time").time())),
                                 headers={"User-Agent": "correo-updater"})
    with urllib.request.urlopen(req, timeout=120) as r:
        data = r.read()
    if hashlib.sha256(data).hexdigest() != manifest["sha256"].lower():
        return None
    if not verify_signature(manifest):
        return None
    dest = os.path.join(UPDATES_DIR, manifest["version"])
    tmp = dest + ".tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    os.makedirs(tmp, exist_ok=True)
    zpath = os.path.join(tmp, "update.zip")
    with open(zpath, "wb") as f:
        f.write(data)
    try:
        with zipfile.ZipFile(zpath) as z:
            z.extractall(tmp)
        os.remove(zpath)
        shutil.rmtree(dest, ignore_errors=True)
        os.rename(tmp, dest)
        prev = os.path.join(UPDATES_DIR, "prev")
        cur = os.path.join(UPDATES_DIR, "current")
        if os.path.islink(cur) or os.path.exists(cur):
            old = os.path.realpath(cur)
            if os.path.isdir(old) and old != dest:
                try:
                    if os.path.islink(prev) or os.path.exists(prev):
                        os.remove(prev)
                    os.symlink(old, prev)
                except OSError:
                    pass
        if os.path.islink(cur) or os.path.exists(cur):
            os.remove(cur)
        os.symlink(dest, cur)
        return dest
    except Exception:
        shutil.rmtree(tmp, ignore_errors=True)
        return None

def _dir_version(d):
    try:
        with open(os.path.join(d, "version.txt")) as f:
            return _ver_tuple(f.read().strip())
    except OSError:
        return _ver_tuple("0")

def latest_code_dir():
    """Directorio de codigo mas reciente valido (actualizacion descargada o base del deb).
    Una actualizacion solo prevalece si su version es estrictamente mayor que la
    de la base instalada; asi un deb mas nuevo nunca queda enmascarado por una
    actualizacion antigua. Acepta zip con archivos en la raiz (formato 1.x) o
    bajo opt/email/app."""
    base_ver = _dir_version(BASE_DIR)
    cur = os.path.join(UPDATES_DIR, "current")
    if os.path.islink(cur):
        dest = os.path.realpath(cur)
        for cand in (dest,
                     os.path.join(dest, "opt", "email", "app"),
                     os.path.join(dest, "opt", "correo", "app")):
            if os.path.exists(os.path.join(cand, "correo.py")) and os.path.exists(os.path.join(cand, "version.txt")):
                if _dir_version(cand) > base_ver:
                    return cand
                break
    return BASE_DIR

def restart_app():
    """Reinicia Email ejecutando el lanzador instalado (que resolvera la version nueva)."""
    import sys
    for launcher in ("/opt/email/app/launcher.py", "/opt/correo/app/launcher.py"):
        if os.path.exists(launcher):
            os.execv(sys.executable, [sys.executable, launcher] + sys.argv[1:])
    # sin lanzador instalado (desarrollo): relanza el propio proceso
    os.execv(sys.executable, [sys.executable] + sys.argv)
