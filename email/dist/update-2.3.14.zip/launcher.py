# -*- coding: utf-8 -*-
"""Lanzador: elige la version mas reciente del codigo y la ejecuta."""
import os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import updater
code = updater.latest_code_dir()
os.chdir(code)
os.execv(sys.executable, [sys.executable, os.path.join(code, "correo.py")] + sys.argv[1:])
